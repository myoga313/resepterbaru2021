---
description: "Bumbu Kue lebaran semprit selai strawberry | Resep Membuat Kue lebaran semprit selai strawberry Yang Bikin Ngiler"
title: "Bumbu Kue lebaran semprit selai strawberry | Resep Membuat Kue lebaran semprit selai strawberry Yang Bikin Ngiler"
slug: 154-bumbu-kue-lebaran-semprit-selai-strawberry-resep-membuat-kue-lebaran-semprit-selai-strawberry-yang-bikin-ngiler
date: 2020-12-02T17:15:41.863Z
image: https://img-global.cpcdn.com/recipes/e1efd6a031f216c1/751x532cq70/kue-lebaran-semprit-selai-strawberry-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/e1efd6a031f216c1/751x532cq70/kue-lebaran-semprit-selai-strawberry-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/e1efd6a031f216c1/751x532cq70/kue-lebaran-semprit-selai-strawberry-foto-resep-utama.jpg
author: Nell Higgins
ratingvalue: 3.5
reviewcount: 9
recipeingredient:
- "100 gr butter"
- "50 gr blueband"
- "125 gr skm putih"
- "250 gr tepung maizena"
- " Topping "
- " Strawberry filling  strawberry jam"
- " Chocochip"
- " Selai rasa buah lain nya"
recipeinstructions:
- "Masukan butter, margarin, skm di dalam bowl.. mixer hingga tercampur rata"
- "Masukan tepung maizena, mixer hingga tercampur rata (atau bs pakai spatula aja)"
- "Masukn adonan ke dalam pipping bag. Siapkan spuit. Kalau gk ada spuit bs bikin model thumbsprint aja."
- "Isi tengahnya pakai selai atau chocochip"
- "Oven di suhu 150° -+ 20-35 menit sampai matang kecoklatan (oven sudah dipanaskan sebelumnya)"
- "Stelah matang, dinginkan di cooling rack. Masukan k dalam toples kalau sudah dingin."
categories:
- Resep
tags:
- kue
- lebaran
- semprit

katakunci: kue lebaran semprit 
nutrition: 193 calories
recipecuisine: Indonesian
preptime: "PT32M"
cooktime: "PT42M"
recipeyield: "3"
recipecategory: Dessert

---


![Kue lebaran semprit selai strawberry](https://img-global.cpcdn.com/recipes/e1efd6a031f216c1/751x532cq70/kue-lebaran-semprit-selai-strawberry-foto-resep-utama.jpg)


kue lebaran semprit selai strawberry ini merupakan kuliner nusantara yang ekslusif dan perlu untuk kita coba. Cita rasanya yang lezat membuat siapa pun menantikan kehadirannya di meja makan.
Anda sedang mencari inspirasi resep kue lebaran semprit selai strawberry untuk jualan atau dikonsumsi sendiri yang Enak Banget? Cara Buatnya memang susah-susah gampang. misalnya keliru mengolah maka hasilnya akan hambar dan bahkan tidak sedap. Padahal kue lebaran semprit selai strawberry yang enak harusnya sih memiliki aroma dan rasa yang dapat memancing selera kita.

Ada beberapa hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari kue lebaran semprit selai strawberry, mulai dari jenis bahan, selanjutnya pemilihan bahan segar, hingga cara membuat dan menghidangkannya. Tak perlu pusing jika hendak menyiapkan kue lebaran semprit selai strawberry enak di rumah, karena asal sudah tahu triknya maka hidangan ini bisa menjadi suguhan spesial.




Nah, kali ini kita coba, yuk, buat kue lebaran semprit selai strawberry sendiri di rumah. Tetap dengan bahan yang sederhana, sajian ini bisa memberi manfaat dalam membantu menjaga kesehatan tubuhmu sekeluarga. Anda dapat membuat Kue lebaran semprit selai strawberry memakai 8 jenis bahan dan 6 tahap pembuatan. Berikut ini langkah-langkah dalam menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam menyiapkan Kue lebaran semprit selai strawberry:

1. Gunakan 100 gr butter
1. Ambil 50 gr blueband
1. Siapkan 125 gr skm putih
1. Gunakan 250 gr tepung maizena
1. Sediakan  Topping :
1. Siapkan  Strawberry filling / strawberry jam
1. Siapkan  Chocochip
1. Siapkan  Selai rasa buah lain nya




<!--inarticleads2-->

##### Cara menyiapkan Kue lebaran semprit selai strawberry:

1. Masukan butter, margarin, skm di dalam bowl.. mixer hingga tercampur rata
1. Masukan tepung maizena, mixer hingga tercampur rata (atau bs pakai spatula aja)
1. Masukn adonan ke dalam pipping bag. Siapkan spuit. Kalau gk ada spuit bs bikin model thumbsprint aja.
1. Isi tengahnya pakai selai atau chocochip
1. Oven di suhu 150° -+ 20-35 menit sampai matang kecoklatan (oven sudah dipanaskan sebelumnya)
1. Stelah matang, dinginkan di cooling rack. Masukan k dalam toples kalau sudah dingin.




Bagaimana? Mudah bukan? Itulah cara menyiapkan kue lebaran semprit selai strawberry yang bisa Anda praktikkan di rumah. Selamat mencoba!
