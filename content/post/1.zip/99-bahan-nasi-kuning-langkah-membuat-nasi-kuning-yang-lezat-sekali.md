---
description: "Bahan Nasi kuning | Langkah Membuat Nasi kuning Yang Lezat Sekali"
title: "Bahan Nasi kuning | Langkah Membuat Nasi kuning Yang Lezat Sekali"
slug: 99-bahan-nasi-kuning-langkah-membuat-nasi-kuning-yang-lezat-sekali
date: 2021-01-22T10:54:44.965Z
image: https://img-global.cpcdn.com/recipes/0ce78f2dade268d6/751x532cq70/nasi-kuning-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/0ce78f2dade268d6/751x532cq70/nasi-kuning-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/0ce78f2dade268d6/751x532cq70/nasi-kuning-foto-resep-utama.jpg
author: Esther Diaz
ratingvalue: 4
reviewcount: 12
recipeingredient:
- " beras"
- " santan kara"
- " air"
- " kunyit bubuk"
- " serai geprek"
- " lb daun salam"
- " Garam"
- " Gula"
- " Bumbu halus "
- " bawang putih"
- " bawang merah"
- " jahe"
recipeinstructions:
- "Tumis bumbu halus hingga harum. Tambahkan serai dan daun salam. Tumis."
- "Tambahkan kunyit bubuk, air, garam, gula, dan santan ke dalam tumisan bumbu. Tes rasa. Jika pas, matikan api."
- "Cuci beras, tuanglan air bumbu ke beras yg sudah dicuci."
- "Masak hingga matang seperti masak nasi biasa pakai rice cooker."
- "Aduk aduk jika nasi sudah matang."
categories:
- Resep
tags:
- nasi
- kuning

katakunci: nasi kuning 
nutrition: 268 calories
recipecuisine: Indonesian
preptime: "PT22M"
cooktime: "PT60M"
recipeyield: "4"
recipecategory: Dessert

---


![Nasi kuning](https://img-global.cpcdn.com/recipes/0ce78f2dade268d6/751x532cq70/nasi-kuning-foto-resep-utama.jpg)


nasi kuning ini yaitu santapan tanah air yang enak dan wajib untuk kita coba. Cita rasanya yang lezat membuat siapa pun menantikan kehadirannya di meja makan.
Bunda lagi mencari ide resep nasi kuning untuk jualan atau dikonsumsi sendiri yang Enak dan Simpel? Cara Bikinnya memang tidak terlalu sulit namun tidak gampang juga. apabila keliru mengolah maka hasilnya tidak akan memuaskan dan bahkan tidak sedap. Padahal nasi kuning yang enak seharusnya mempunyai aroma dan rasa yang bisa memancing selera kita.



Ada beberapa hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari nasi kuning, mulai dari jenis bahan, lalu pemilihan bahan segar sampai cara membuat dan menghidangkannya. Tidak usah pusing kalau mau menyiapkan nasi kuning enak di rumah, karena asal sudah tahu triknya maka hidangan ini dapat menjadi sajian spesial.


Nah, kali ini kita coba, yuk, kreasikan nasi kuning sendiri di rumah. Tetap berbahan yang sederhana, sajian ini dapat memberi manfaat dalam membantu menjaga kesehatan tubuhmu sekeluarga. Anda bisa menyiapkan Nasi kuning memakai 12 jenis bahan dan 5 tahap pembuatan. Berikut ini cara untuk menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam pembuatan Nasi kuning:

1. Ambil  beras
1. Sediakan  santan kara
1. Gunakan  air
1. Gunakan  kunyit bubuk
1. Siapkan  serai geprek
1. Siapkan  lb daun salam
1. Gunakan  Garam
1. Ambil  Gula
1. Gunakan  Bumbu halus :
1. Siapkan  bawang putih
1. Ambil  bawang merah
1. Sediakan  jahe




<!--inarticleads2-->

##### Langkah-langkah membuat Nasi kuning:

1. Tumis bumbu halus hingga harum. Tambahkan serai dan daun salam. Tumis.
1. Tambahkan kunyit bubuk, air, garam, gula, dan santan ke dalam tumisan bumbu. Tes rasa. Jika pas, matikan api.
1. Cuci beras, tuanglan air bumbu ke beras yg sudah dicuci.
1. Masak hingga matang seperti masak nasi biasa pakai rice cooker.
1. Aduk aduk jika nasi sudah matang.




Gimana nih? Mudah bukan? Itulah cara membuat nasi kuning yang bisa Anda lakukan di rumah. Selamat mencoba!
