---
description: "Resep masakan Ayam Goreng Daun Jeruk | Langkah Membuat Ayam Goreng Daun Jeruk Yang Bisa Manjain Lidah"
title: "Resep masakan Ayam Goreng Daun Jeruk | Langkah Membuat Ayam Goreng Daun Jeruk Yang Bisa Manjain Lidah"
slug: 276-resep-masakan-ayam-goreng-daun-jeruk-langkah-membuat-ayam-goreng-daun-jeruk-yang-bisa-manjain-lidah
date: 2020-12-02T14:23:36.883Z
image: https://img-global.cpcdn.com/recipes/55e3f0f13952c2f5/751x532cq70/ayam-goreng-daun-jeruk-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/55e3f0f13952c2f5/751x532cq70/ayam-goreng-daun-jeruk-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/55e3f0f13952c2f5/751x532cq70/ayam-goreng-daun-jeruk-foto-resep-utama.jpg
author: Alejandro Porter
ratingvalue: 4.3
reviewcount: 6
recipeingredient:
- " Ayam Broiler 12kg"
- " Air"
- " Garam"
- " Kaldu ayam bubuk"
- " Bumbu halus "
- " bawang putih"
- " Kemiri"
- " kunyit"
- " ketumbar biji"
- " daun Jeruk"
- " Bumbu rempah "
- " serai"
- " lengkuas"
- " Jahe"
recipeinstructions:
- "Potong ayam sesuai selera, sisihkan. Siapkan bumbu halus dan bumbu rempah, sisihkan."
- "Campur air, garam dan bumbu halus. Masak hingga mendidih, masukkan ayam potong dan bumbu rempah. Masak hingga ayam matang dan air menyusut. Masak dengan api kecil agar bumbu meresap dan daging empuk."
- "Pindahkan kedalam wadah tertutup dan simpan kedalam kulkas jika ayam sudah dingin. (Siap digoreng besok, dan bisa juga langsung digoreng)"
- "Goreng hingga kecoklatan, angkat dan tiriskan. Ayam goreng siap disajikan"
categories:
- Resep
tags:
- ayam
- goreng
- daun

katakunci: ayam goreng daun 
nutrition: 275 calories
recipecuisine: Indonesian
preptime: "PT17M"
cooktime: "PT45M"
recipeyield: "4"
recipecategory: Dessert

---


![Ayam Goreng Daun Jeruk](https://img-global.cpcdn.com/recipes/55e3f0f13952c2f5/751x532cq70/ayam-goreng-daun-jeruk-foto-resep-utama.jpg)


ayam goreng daun jeruk ini merupakan suguhan nusantara yang unik dan wajib untuk kita coba. Cita rasanya yang mantap membuat siapa pun menantikan kehadirannya di meja makan.
Anda sedang mencari inspirasi resep ayam goreng daun jeruk untuk jualan atau dikonsumsi sendiri yang Menggugah Selera? Cara membuatnya memang tidak terlalu sulit namun tidak gampang juga. kalau salah mengolah maka hasilnya tidak akan memuaskan dan bahkan tidak sedap. Padahal ayam goreng daun jeruk yang enak seharusnya punya aroma dan rasa yang dapat memancing selera kita.

Ada beberapa hal yang sedikit banyak mempengaruhi kualitas rasa dari ayam goreng daun jeruk, pertama dari jenis bahan, selanjutnya pemilihan bahan segar, sampai cara membuat dan menyajikannya. Tidak usah pusing jika mau menyiapkan ayam goreng daun jeruk enak di rumah, karena asal sudah tahu triknya maka hidangan ini mampu jadi sajian spesial.




Berikut ini ada beberapa tips dan trik praktis dalam mengolah ayam goreng daun jeruk yang siap dikreasikan. Anda bisa menyiapkan Ayam Goreng Daun Jeruk memakai 14 bahan dan 4 tahap pembuatan. Berikut ini langkah-langkah dalam menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam pembuatan Ayam Goreng Daun Jeruk:

1. Gunakan  Ayam Broiler (1.2kg)
1. Siapkan  Air
1. Gunakan  Garam
1. Ambil  Kaldu ayam bubuk
1. Ambil  Bumbu halus :
1. Gunakan  bawang putih
1. Sediakan  Kemiri
1. Gunakan  kunyit
1. Ambil  ketumbar biji
1. Ambil  daun Jeruk
1. Gunakan  Bumbu rempah :
1. Siapkan  serai
1. Siapkan  lengkuas
1. Gunakan  Jahe




<!--inarticleads2-->

##### Langkah-langkah membuat Ayam Goreng Daun Jeruk:

1. Potong ayam sesuai selera, sisihkan. Siapkan bumbu halus dan bumbu rempah, sisihkan.
1. Campur air, garam dan bumbu halus. Masak hingga mendidih, masukkan ayam potong dan bumbu rempah. Masak hingga ayam matang dan air menyusut. Masak dengan api kecil agar bumbu meresap dan daging empuk.
1. Pindahkan kedalam wadah tertutup dan simpan kedalam kulkas jika ayam sudah dingin. (Siap digoreng besok, dan bisa juga langsung digoreng)
1. Goreng hingga kecoklatan, angkat dan tiriskan. Ayam goreng siap disajikan




Terima kasih telah membaca resep yang kami tampilkan di halaman ini. Besar harapan kami, olahan Ayam Goreng Daun Jeruk yang mudah di atas dapat membantu Anda menyiapkan makanan yang enak untuk keluarga/teman maupun menjadi inspirasi dalam berbisnis kuliner. Selamat mencoba!
