---
description: "Olahan Donat Menal Menul With Metode Autolysis | Bahan Membuat Donat Menal Menul With Metode Autolysis Yang Menggugah Selera"
title: "Olahan Donat Menal Menul With Metode Autolysis | Bahan Membuat Donat Menal Menul With Metode Autolysis Yang Menggugah Selera"
slug: 201-olahan-donat-menal-menul-with-metode-autolysis-bahan-membuat-donat-menal-menul-with-metode-autolysis-yang-menggugah-selera
date: 2020-11-22T04:35:46.600Z
image: https://img-global.cpcdn.com/recipes/40910a8e4de06afe/751x532cq70/donat-menal-menul-with-metode-autolysis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/40910a8e4de06afe/751x532cq70/donat-menal-menul-with-metode-autolysis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/40910a8e4de06afe/751x532cq70/donat-menal-menul-with-metode-autolysis-foto-resep-utama.jpg
author: Jorge Carlson
ratingvalue: 3.6
reviewcount: 9
recipeingredient:
- " Bahan A "
- " tepung cakra"
- " susu bubuk full cream"
- " air"
- " gula pasir"
- " kuning telur"
- " garam halus"
- " Bahan B "
- " air  takaran 1 sendok obat sirup"
- " ragi instan fernipam"
- " mentega royal palmia"
recipeinstructions:
- "Siapkan bahan 2,,lalu Masukkan kuning telur,gula pasir pd baskom"
- "Kocok lepas hingga rata lalu masukkan air aduk sampai merata, lalu masukkan tepung terigu,susu bubuk, dan garam,,aduk sampai tercampur,lalu uleni sebentar,lalu buat bulatan"
- "Tutup adonan diamkan selama 6-8jam,,tp saya ini selama 6 jam ngadon selesai pas jam 12mlm,,jd pas saya cek saat subuh ternyata sudah lentur ya mom,,sambil menunggu juga siapkan coklat leleh nya/glazenya,,jika sudah lentur Tandanya sudah bisa di beri Bahan B"
- "Kemudian tambahkan air pd ragi,,aduk hingga menjadi pasta ya,"
- "Lalu oles² ke adonan yg sudah lentur tadi aduk sampai ½ Kalis lalu masukkan mentega dan kembali uleni sampai kalis"
- "Kalis elastis seperti gambar,,lalu ambil adonan timbang 30-40gr bulatan, letakkan pd loyang yang sudah di alasi plastik,,atau baking paper taburi dengan tepung terigu agar tidak menempel,, lakukan sampai habis adonan,lalu bolongkan adonan dengan spuit kuker,,"
- "Lalu diamkan hingga 30-60menit tp ini di menit ke 45 saya sudah mengembang jd sudah bisa di goreng,, panaskan minyak goreng tes dengan sumpit bila sudah berbuih sudah bisa di masukkan ke dalam wajan.. kemudian ubah ke api kecil,lalu masukkan donat dengan posisi yg atas ada di bawah minyak goreng,putar tengahnya dengan sumpit, kemudian balik dan angkat, tiriskan."
- "Lalu dinginkan untuk diberi coklat leleh/glaze,selera aja ya.. [ Note : ingat moms proses membalik donat hanya satu kali saja,jd ga perlu bolak-balik,,Lalu angkat, Tiriskan,karena akan menghilangkan efek white ring nya pd donat ],, lakukan sampai habis..dan siap untuk dinikmati selamat mencoba semoga bermanfaat 👌🙏😊"
categories:
- Resep
tags:
- donat
- menal
- menul

katakunci: donat menal menul 
nutrition: 290 calories
recipecuisine: Indonesian
preptime: "PT15M"
cooktime: "PT55M"
recipeyield: "1"
recipecategory: Dinner

---


![Donat Menal Menul With Metode Autolysis](https://img-global.cpcdn.com/recipes/40910a8e4de06afe/751x532cq70/donat-menal-menul-with-metode-autolysis-foto-resep-utama.jpg)


donat menal menul with metode autolysis ini yaitu kuliner nusantara yang enak dan harus untuk kita coba. Cita rasanya yang lezat membuat siapa pun menantikan kehadirannya di meja makan.
Sedang mencari ide resep donat menal menul with metode autolysis untuk jualan atau dikonsumsi sendiri yang Bisa Manjain Lidah? Cara Bikinnya memang tidak susah dan tidak juga mudah. jikalau keliru mengolah maka hasilnya Tidak Memuaskan dan bahkan tidak sedap. Padahal donat menal menul with metode autolysis yang enak harusnya sih punya aroma dan rasa yang bisa memancing selera kita.

Ada beberapa hal yang sedikit banyak mempengaruhi kualitas rasa dari donat menal menul with metode autolysis, mulai dari jenis bahan, lalu pemilihan bahan segar, sampai cara membuat dan menghidangkannya. Tidak usah pusing kalau ingin menyiapkan donat menal menul with metode autolysis yang enak di rumah, karena asal sudah tahu triknya maka hidangan ini mampu menjadi sajian istimewa.




Di bawah ini ada beberapa tips dan trik praktis untuk membuat donat menal menul with metode autolysis yang siap dikreasikan. Anda bisa menyiapkan Donat Menal Menul With Metode Autolysis memakai 11 bahan dan 8 langkah pembuatan. Berikut ini langkah-langkah dalam menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk pembuatan Donat Menal Menul With Metode Autolysis:

1. Ambil  Bahan A :
1. Sediakan  tepung cakra
1. Siapkan  susu bubuk full cream
1. Siapkan  air
1. Siapkan  gula pasir
1. Ambil  kuning telur
1. Sediakan  garam halus
1. Ambil  Bahan B :
1. Sediakan  air / takaran 1 sendok obat sirup
1. Gunakan  ragi instan fernipam
1. Siapkan  mentega royal palmia




<!--inarticleads2-->

##### Langkah-langkah membuat Donat Menal Menul With Metode Autolysis:

1. Siapkan bahan 2,,lalu Masukkan kuning telur,gula pasir pd baskom
1. Kocok lepas hingga rata lalu masukkan air aduk sampai merata, lalu masukkan tepung terigu,susu bubuk, dan garam,,aduk sampai tercampur,lalu uleni sebentar,lalu buat bulatan
1. Tutup adonan diamkan selama 6-8jam,,tp saya ini selama 6 jam ngadon selesai pas jam 12mlm,,jd pas saya cek saat subuh ternyata sudah lentur ya mom,,sambil menunggu juga siapkan coklat leleh nya/glazenya,,jika sudah lentur Tandanya sudah bisa di beri Bahan B
1. Kemudian tambahkan air pd ragi,,aduk hingga menjadi pasta ya,
1. Lalu oles² ke adonan yg sudah lentur tadi aduk sampai ½ Kalis lalu masukkan mentega dan kembali uleni sampai kalis
1. Kalis elastis seperti gambar,,lalu ambil adonan timbang 30-40gr bulatan, letakkan pd loyang yang sudah di alasi plastik,,atau baking paper taburi dengan tepung terigu agar tidak menempel,, lakukan sampai habis adonan,lalu bolongkan adonan dengan spuit kuker,,
1. Lalu diamkan hingga 30-60menit tp ini di menit ke 45 saya sudah mengembang jd sudah bisa di goreng,, panaskan minyak goreng tes dengan sumpit bila sudah berbuih sudah bisa di masukkan ke dalam wajan.. kemudian ubah ke api kecil,lalu masukkan donat dengan posisi yg atas ada di bawah minyak goreng,putar tengahnya dengan sumpit, kemudian balik dan angkat, tiriskan.
1. Lalu dinginkan untuk diberi coklat leleh/glaze,selera aja ya.. [ Note : ingat moms proses membalik donat hanya satu kali saja,jd ga perlu bolak-balik,,Lalu angkat, Tiriskan,karena akan menghilangkan efek white ring nya pd donat ],, lakukan sampai habis..dan siap untuk dinikmati selamat mencoba semoga bermanfaat 👌🙏😊




Terima kasih telah menggunakan resep yang tim kami tampilkan di halaman ini. Besar harapan kami, olahan Donat Menal Menul With Metode Autolysis yang mudah di atas dapat membantu Anda menyiapkan hidangan yang enak untuk keluarga/teman maupun menjadi inspirasi untuk berjualan makanan. Selamat mencoba!
