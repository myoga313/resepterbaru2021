---
description: "Resep Donat kentang | Langkah Membuat Donat kentang Yang Enak Dan Lezat"
title: "Resep Donat kentang | Langkah Membuat Donat kentang Yang Enak Dan Lezat"
slug: 190-resep-donat-kentang-langkah-membuat-donat-kentang-yang-enak-dan-lezat
date: 2020-11-05T20:55:00.989Z
image: https://img-global.cpcdn.com/recipes/817f1b1ee51c8e84/751x532cq70/donat-kentang-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/817f1b1ee51c8e84/751x532cq70/donat-kentang-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/817f1b1ee51c8e84/751x532cq70/donat-kentang-foto-resep-utama.jpg
author: Marc Holland
ratingvalue: 3.3
reviewcount: 10
recipeingredient:
- " terigu segitiga"
- " kentang dikukus dn dihaluskan"
- " gula pasir"
- " telur"
- " mentega"
- " garam"
- " ragi"
- " susu cair dingin"
- " Utk toping"
- " gula halus"
- " Dcc"
- " Messis"
recipeinstructions:
- "Masukkan tepung terigu, ragi, kuning telur, gula kemudian aduk masukkan susu sedikit demi sedikit mixer smpai kalis"
- "Diamkan adonan selama 15 menit kemudian dibentuk, setelah itu diamkan selama 15 mnt smpai ngembang"
- "Siapkn minyak panas kemudian goreng donat smpai matang api kecil"
- "Beri toping sesuai selera kemudian dihidangkan"
categories:
- Resep
tags:
- donat
- kentang

katakunci: donat kentang 
nutrition: 141 calories
recipecuisine: Indonesian
preptime: "PT32M"
cooktime: "PT39M"
recipeyield: "4"
recipecategory: Lunch

---


![Donat kentang](https://img-global.cpcdn.com/recipes/817f1b1ee51c8e84/751x532cq70/donat-kentang-foto-resep-utama.jpg)


donat kentang ini yaitu suguhan tanah air yang mantap dan harus untuk kita coba. Cita rasanya yang mantap membuat siapa pun menantikan kehadirannya di meja makan.
Bunda lagi mencari ide resep donat kentang untuk jualan atau dikonsumsi sendiri yang Lezat Sekali? Cara Memasaknya memang susah-susah gampang. sekiranya keliru mengolah maka hasilnya akan hambar dan justru cenderung tidak enak. Padahal donat kentang yang enak seharusnya memiliki aroma dan cita rasa yang bisa memancing selera kita.

Banyak hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari donat kentang, mulai dari jenis bahan, kemudian pemilihan bahan segar, sampai cara membuat dan menghidangkannya. Tak perlu pusing jika ingin menyiapkan donat kentang enak di rumah, karena asal sudah tahu triknya maka hidangan ini dapat jadi sajian istimewa.




Berikut ini ada beberapa cara mudah dan praktis yang dapat diterapkan untuk mengolah donat kentang yang siap dikreasikan. Anda dapat membuat Donat kentang menggunakan 12 jenis bahan dan 4 tahap pembuatan. Berikut ini cara dalam menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk menyiapkan Donat kentang:

1. Siapkan  terigu segitiga
1. Sediakan  kentang dikukus dn dihaluskan
1. Ambil  gula pasir
1. Gunakan  telur
1. Gunakan  mentega
1. Ambil  garam
1. Gunakan  ragi
1. Ambil  susu cair dingin
1. Siapkan  Utk toping
1. Gunakan  gula halus
1. Siapkan  Dcc
1. Siapkan  Messis




<!--inarticleads2-->

##### Cara membuat Donat kentang:

1. Masukkan tepung terigu, ragi, kuning telur, gula kemudian aduk masukkan susu sedikit demi sedikit mixer smpai kalis
1. Diamkan adonan selama 15 menit kemudian dibentuk, setelah itu diamkan selama 15 mnt smpai ngembang
1. Siapkn minyak panas kemudian goreng donat smpai matang api kecil
1. Beri toping sesuai selera kemudian dihidangkan




Gimana nih? Gampang kan? Itulah cara membuat donat kentang yang bisa Anda praktikkan di rumah. Selamat mencoba!
