---
description: "Bahan Donat Crispy | Cara Bikin Donat Crispy Yang Sedap"
title: "Bahan Donat Crispy | Cara Bikin Donat Crispy Yang Sedap"
slug: 175-bahan-donat-crispy-cara-bikin-donat-crispy-yang-sedap
date: 2020-11-29T22:38:54.260Z
image: https://img-global.cpcdn.com/recipes/240b3eb9aff5056f/751x532cq70/donat-crispy-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/240b3eb9aff5056f/751x532cq70/donat-crispy-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/240b3eb9aff5056f/751x532cq70/donat-crispy-foto-resep-utama.jpg
author: Jacob Conner
ratingvalue: 3.6
reviewcount: 5
recipeingredient:
- " Bahan kering "
- "  400 gr tepung cakra"
- "  100 gr tepung maizena"
- "  1 bks 27 gr susu dancow bubuk"
- "  5gr 12 sdt bread improver opsional"
- " Bahan cair "
- "  150 gr 6 sdm gula pasir masukkan sebagian ke bahan kering"
- "  5 gr 12 bks ragi"
- "  120 ml air hangat"
- " 250 gr 2 btr ukuran sedang Kentang rebuskukus"
- " 2 butir telur"
- "  50 gr 2 sdm mentega putih bisa diganti margarine"
- "  8 gr 12 sdt garam"
recipeinstructions:
- "Siapkan bahan2nya."
- "Masukkan semua bahan kering dalam wadah yg cukup besar, aduk asal tercampur."
- "Campurkan sebagian gula pasir, ragi dan air hangat, aduk rata, biarkan hingga larut dan berbuih (kurleb 15 menit). Jika anda menggunakan ragi lama atau ragi sisa, ketika campuran sudah tidak berbuih, ganti ragi anda (buih menandakan ragi anda masih aktif). Masukkan sisa gula pasir ke bahan kering."
- "Haluskan kentang (saya : parut menggunakan parutan keju), tambahkan telur, aduk asal rata dengan whisk."
- "Campurkan bahan kering dengan air ragi. Aduk asal rata. Masukkan campuran kentang dan telur, uleni hingga kalis."
- "Tambahkan mentega dan garam, uleni lagi hingga kalis elastis."
- "Diamkan adonan hingga mengembang 2x lipat (kurleb 45-60 menit), tutup dengan kain lembab yang bersih."
- "Kempeskan adonan, bagi menjadi 32 bagian (saya lupa menimbangnya(. Bulat2kan adonan (jika anda punya cetakan donat, silakan pakai) hingga adonan habis (saat anda selesai membulatkan, adonan awal sudah mengembang lagi)."
- "Panaskan minyak, buat lubang pada tengah adonan yg agak besar (nanti akan mengecil saat adonan semakin besar saat digoreng), masukkan dalam minyak yang sudah panas, goreng dengan api sedang cenderung kecil hingga kecokelatan. Banyak tips yg mengatakan anda cukup 1x membalik agar tidak terlalu menyerap minyak,, saya coba menggoreng dengan beberapa kali balik, perbedaannya tidak terlalu banyak menurut saya."
- "Tiriskan adonan, akan lebih baik jika digantung."
- "Sajikan sesuai selera anda....happy cooking.."
categories:
- Resep
tags:
- donat
- crispy

katakunci: donat crispy 
nutrition: 185 calories
recipecuisine: Indonesian
preptime: "PT34M"
cooktime: "PT50M"
recipeyield: "2"
recipecategory: Dinner

---


![Donat Crispy](https://img-global.cpcdn.com/recipes/240b3eb9aff5056f/751x532cq70/donat-crispy-foto-resep-utama.jpg)


donat crispy ini merupakan hidangan nusantara yang khas dan wajib untuk kita coba. Cita rasanya yang enak membuat siapa pun menantikan kehadirannya di meja makan.
Lagi mencari inspirasi resep donat crispy untuk jualan atau dikonsumsi sendiri yang Sempurna? Cara Buatnya memang tidak susah dan tidak juga mudah. andaikata keliru mengolah maka hasilnya Tidak Memuaskan dan bahkan tidak sedap. Padahal donat crispy yang enak seharusnya punya aroma dan rasa yang mampu memancing selera kita.

Banyak hal yang sedikit banyak mempengaruhi kualitas rasa dari donat crispy, pertama dari jenis bahan, kemudian pemilihan bahan segar, hingga cara mengolah dan menghidangkannya. Tidak usah pusing kalau ingin menyiapkan donat crispy enak di rumah, karena asal sudah tahu triknya maka hidangan ini mampu jadi suguhan istimewa.




Berikut ini ada beberapa tips dan trik praktis untuk membuat donat crispy yang siap dikreasikan. Anda bisa membuat Donat Crispy memakai 13 jenis bahan dan 11 langkah pembuatan. Berikut ini cara dalam menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk menyiapkan Donat Crispy:

1. Gunakan  Bahan kering :
1. Siapkan  ☆ 400 gr tepung cakra
1. Siapkan  ☆ 100 gr tepung maizena
1. Siapkan  ☆ 1 bks (27 gr) susu dancow bubuk
1. Ambil  ☆ 5gr (1/2 sdt) bread improver (opsional)
1. Sediakan  Bahan cair :
1. Ambil  ♡ 150 gr (6 sdm) gula pasir (masukkan sebagian ke bahan kering)
1. Gunakan  ♡ 5 gr (1/2 bks) ragi
1. Siapkan  ♡ 120 ml air hangat
1. Ambil  ▪︎250 gr (2 btr ukuran sedang) Kentang, rebus/kukus
1. Siapkan  ▪︎2 butir telur
1. Siapkan  ~ 50 gr (2 sdm) mentega putih (bisa diganti margarine)
1. Gunakan  ~ 8 gr (1/2 sdt) garam




<!--inarticleads2-->

##### Cara menyiapkan Donat Crispy:

1. Siapkan bahan2nya.
1. Masukkan semua bahan kering dalam wadah yg cukup besar, aduk asal tercampur.
1. Campurkan sebagian gula pasir, ragi dan air hangat, aduk rata, biarkan hingga larut dan berbuih (kurleb 15 menit). Jika anda menggunakan ragi lama atau ragi sisa, ketika campuran sudah tidak berbuih, ganti ragi anda (buih menandakan ragi anda masih aktif). Masukkan sisa gula pasir ke bahan kering.
1. Haluskan kentang (saya : parut menggunakan parutan keju), tambahkan telur, aduk asal rata dengan whisk.
1. Campurkan bahan kering dengan air ragi. Aduk asal rata. Masukkan campuran kentang dan telur, uleni hingga kalis.
1. Tambahkan mentega dan garam, uleni lagi hingga kalis elastis.
1. Diamkan adonan hingga mengembang 2x lipat (kurleb 45-60 menit), tutup dengan kain lembab yang bersih.
1. Kempeskan adonan, bagi menjadi 32 bagian (saya lupa menimbangnya(. Bulat2kan adonan (jika anda punya cetakan donat, silakan pakai) hingga adonan habis (saat anda selesai membulatkan, adonan awal sudah mengembang lagi).
1. Panaskan minyak, buat lubang pada tengah adonan yg agak besar (nanti akan mengecil saat adonan semakin besar saat digoreng), masukkan dalam minyak yang sudah panas, goreng dengan api sedang cenderung kecil hingga kecokelatan. Banyak tips yg mengatakan anda cukup 1x membalik agar tidak terlalu menyerap minyak,, saya coba menggoreng dengan beberapa kali balik, perbedaannya tidak terlalu banyak menurut saya.
1. Tiriskan adonan, akan lebih baik jika digantung.
1. Sajikan sesuai selera anda....happy cooking..




Terima kasih telah menggunakan resep yang tim kami tampilkan di sini. Harapan kami, olahan Donat Crispy yang mudah di atas dapat membantu Anda menyiapkan hidangan yang sedap untuk keluarga/teman ataupun menjadi inspirasi bagi Anda yang berkeinginan untuk berjualan makanan. Semoga bermanfaat dan selamat mencoba!
