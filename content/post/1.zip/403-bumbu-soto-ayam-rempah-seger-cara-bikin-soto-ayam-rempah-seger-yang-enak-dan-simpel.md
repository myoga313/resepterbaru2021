---
description: "Bumbu Soto ayam rempah seger | Cara Bikin Soto ayam rempah seger Yang Enak dan Simpel"
title: "Bumbu Soto ayam rempah seger | Cara Bikin Soto ayam rempah seger Yang Enak dan Simpel"
slug: 403-bumbu-soto-ayam-rempah-seger-cara-bikin-soto-ayam-rempah-seger-yang-enak-dan-simpel
date: 2020-08-06T08:04:05.177Z
image: https://img-global.cpcdn.com/recipes/5ac0920269bd4ba1/751x532cq70/soto-ayam-rempah-seger-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/5ac0920269bd4ba1/751x532cq70/soto-ayam-rempah-seger-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/5ac0920269bd4ba1/751x532cq70/soto-ayam-rempah-seger-foto-resep-utama.jpg
author: Adeline Elliott
ratingvalue: 3.3
reviewcount: 3
recipeingredient:
- "250 gr dada ayam"
- "2 liter air"
- "1 batang serai geprek"
- "1 ruas laos geprek"
- "3 lembar daun jeruk purut"
- "2 lembar daun salam"
- "Secukupnya garam"
- "Secukupnya kaldu jamur"
- "2 helai daun bawang potongpotong"
- "2 buah tomat kecil potongpotong"
- " Bumbu Halus"
- "1 bungkus kecil bumbu soto isinya jinten mericacengkeh dsb"
- "4 siung bawang putih"
- "6 siung bawang merah"
- "1/2 ruas kunyit bakar"
- "1/2 ruas jahe"
- " Pelengkap"
- " Toge rebus"
- " Ayam suwir"
- "Irisan seledri"
- " Keripik kentang"
- " Bawang goreng"
- " Sambel cabe rawit  1 bawang putih direbus kemudian diuleg"
- " Kecap manis"
recipeinstructions:
- "Cuci bersih dada ayam kemudian rebus hingga empuk."
- "Tumis bumbu halus, masukkan daun salam, daun jeruk, laos, dan serai aduk hingga harum. Masukkan daun bawang tumis-tumis. Kemudian masukkan ke dalam rebusan ayam."
- "Bumbui garam dan kaldu jamur, sesekali aduk. Ambil dada ayam dari dalam kuah (tunggu dingin ayamnya baru di suwir-suwir)"
- "Masukkan potongan tomat, tunggu matang kemudian matikan api."
- "Sajikan soto dengan nasi, ayam suwir, toge rebus, keripik kentang, irisan seledri, bawang goreng, kecap dan sambel. Hmmmm segeeerrrr"
categories:
- Resep
tags:
- soto
- ayam
- rempah

katakunci: soto ayam rempah 
nutrition: 190 calories
recipecuisine: Indonesian
preptime: "PT14M"
cooktime: "PT41M"
recipeyield: "3"
recipecategory: Dinner

---


![Soto ayam rempah seger](https://img-global.cpcdn.com/recipes/5ac0920269bd4ba1/751x532cq70/soto-ayam-rempah-seger-foto-resep-utama.jpg)


soto ayam rempah seger ini merupakan kuliner nusantara yang spesial dan wajib untuk kita coba. Cita rasanya yang enak membuat siapa pun menantikan kehadirannya di meja makan.
Anda sedang mencari ide resep soto ayam rempah seger untuk jualan atau dikonsumsi sendiri yang Enak Dan Lezat? Cara Bikinnya memang susah-susah gampang. semisal salah mengolah maka hasilnya tidak akan memuaskan dan bahkan tidak sedap. Padahal soto ayam rempah seger yang enak harusnya sih memiliki aroma dan cita rasa yang bisa memancing selera kita.

Ada beberapa hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari soto ayam rempah seger, mulai dari jenis bahan, lalu pemilihan bahan segar, sampai cara membuat dan menghidangkannya. Tidak usah pusing kalau ingin menyiapkan soto ayam rempah seger enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini mampu menjadi sajian istimewa.




Nah, kali ini kita coba, yuk, kreasikan soto ayam rempah seger sendiri di rumah. Tetap berbahan sederhana, sajian ini bisa memberi manfaat untuk membantu menjaga kesehatan tubuh kita. Anda dapat menyiapkan Soto ayam rempah seger menggunakan 24 jenis bahan dan 5 tahap pembuatan. Berikut ini langkah-langkah dalam menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam menyiapkan Soto ayam rempah seger:

1. Siapkan 250 gr dada ayam
1. Ambil 2 liter air
1. Sediakan 1 batang serai geprek
1. Sediakan 1 ruas laos geprek
1. Siapkan 3 lembar daun jeruk purut
1. Sediakan 2 lembar daun salam
1. Gunakan Secukupnya garam
1. Sediakan Secukupnya kaldu jamur
1. Gunakan 2 helai daun bawang potong-potong
1. Gunakan 2 buah tomat kecil potong-potong
1. Siapkan  Bumbu Halus:
1. Sediakan 1 bungkus kecil bumbu soto (isinya jinten, merica,cengkeh, dsb)
1. Siapkan 4 siung bawang putih
1. Gunakan 6 siung bawang merah
1. Sediakan 1/2 ruas kunyit bakar
1. Ambil 1/2 ruas jahe
1. Siapkan  Pelengkap:
1. Sediakan  Toge rebus
1. Ambil  Ayam suwir
1. Siapkan Irisan seledri
1. Gunakan  Keripik kentang
1. Sediakan  Bawang goreng
1. Ambil  Sambel (cabe rawit + 1 bawang putih direbus kemudian diuleg)
1. Ambil  Kecap manis




<!--inarticleads2-->

##### Langkah-langkah membuat Soto ayam rempah seger:

1. Cuci bersih dada ayam kemudian rebus hingga empuk.
1. Tumis bumbu halus, masukkan daun salam, daun jeruk, laos, dan serai aduk hingga harum. Masukkan daun bawang tumis-tumis. Kemudian masukkan ke dalam rebusan ayam.
1. Bumbui garam dan kaldu jamur, sesekali aduk. Ambil dada ayam dari dalam kuah (tunggu dingin ayamnya baru di suwir-suwir)
1. Masukkan potongan tomat, tunggu matang kemudian matikan api.
1. Sajikan soto dengan nasi, ayam suwir, toge rebus, keripik kentang, irisan seledri, bawang goreng, kecap dan sambel. Hmmmm segeeerrrr




Gimana nih? Mudah bukan? Itulah cara menyiapkan soto ayam rempah seger yang bisa Anda praktikkan di rumah. Semoga bermanfaat dan selamat mencoba!
