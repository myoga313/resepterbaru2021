---
description: "Bahan Nasi kuning | Cara Mengolah Nasi kuning Yang Lezat Sekali"
title: "Bahan Nasi kuning | Cara Mengolah Nasi kuning Yang Lezat Sekali"
slug: 100-bahan-nasi-kuning-cara-mengolah-nasi-kuning-yang-lezat-sekali
date: 2020-08-13T06:46:50.304Z
image: https://img-global.cpcdn.com/recipes/0ce78f2dade268d6/751x532cq70/nasi-kuning-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/0ce78f2dade268d6/751x532cq70/nasi-kuning-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/0ce78f2dade268d6/751x532cq70/nasi-kuning-foto-resep-utama.jpg
author: Eddie Medina
ratingvalue: 3
reviewcount: 15
recipeingredient:
- " beras"
- " santan kara"
- " air"
- " kunyit bubuk"
- " serai geprek"
- " lb daun salam"
- " Garam"
- " Gula"
- " Bumbu halus "
- " bawang putih"
- " bawang merah"
- " jahe"
recipeinstructions:
- "Tumis bumbu halus hingga harum. Tambahkan serai dan daun salam. Tumis."
- "Tambahkan kunyit bubuk, air, garam, gula, dan santan ke dalam tumisan bumbu. Tes rasa. Jika pas, matikan api."
- "Cuci beras, tuanglan air bumbu ke beras yg sudah dicuci."
- "Masak hingga matang seperti masak nasi biasa pakai rice cooker."
- "Aduk aduk jika nasi sudah matang."
categories:
- Resep
tags:
- nasi
- kuning

katakunci: nasi kuning 
nutrition: 169 calories
recipecuisine: Indonesian
preptime: "PT35M"
cooktime: "PT56M"
recipeyield: "2"
recipecategory: Dinner

---


![Nasi kuning](https://img-global.cpcdn.com/recipes/0ce78f2dade268d6/751x532cq70/nasi-kuning-foto-resep-utama.jpg)


nasi kuning ini yakni hidangan tanah air yang istimewa dan harus untuk kita coba. Cita rasanya yang mantap membuat siapa pun menantikan kehadirannya di meja makan.
Bunda Sedang mencari ide resep nasi kuning untuk jualan atau dikonsumsi sendiri yang Bikin Ngiler? Cara menyiapkannya memang tidak terlalu sulit namun tidak gampang juga. misalnya keliru mengolah maka hasilnya Tidak Memuaskan dan justru cenderung tidak enak. Padahal nasi kuning yang enak selayaknya mempunyai aroma dan rasa yang dapat memancing selera kita.



Banyak hal yang sedikit banyak mempengaruhi kualitas rasa dari nasi kuning, pertama dari jenis bahan, kedua pemilihan bahan segar hingga cara membuat dan menyajikannya. Tidak usah pusing kalau ingin menyiapkan nasi kuning yang enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini bisa jadi suguhan spesial.


Nah, kali ini kita coba, yuk, variasikan nasi kuning sendiri di rumah. Tetap dengan bahan yang sederhana, hidangan ini dapat memberi manfaat untuk membantu menjaga kesehatan tubuh kita. Anda bisa menyiapkan Nasi kuning menggunakan 12 jenis bahan dan 5 tahap pembuatan. Berikut ini langkah-langkah dalam menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam menyiapkan Nasi kuning:

1. Gunakan  beras
1. Ambil  santan kara
1. Sediakan  air
1. Gunakan  kunyit bubuk
1. Gunakan  serai geprek
1. Gunakan  lb daun salam
1. Siapkan  Garam
1. Siapkan  Gula
1. Ambil  Bumbu halus :
1. Gunakan  bawang putih
1. Gunakan  bawang merah
1. Gunakan  jahe




<!--inarticleads2-->

##### Cara menyiapkan Nasi kuning:

1. Tumis bumbu halus hingga harum. Tambahkan serai dan daun salam. Tumis.
1. Tambahkan kunyit bubuk, air, garam, gula, dan santan ke dalam tumisan bumbu. Tes rasa. Jika pas, matikan api.
1. Cuci beras, tuanglan air bumbu ke beras yg sudah dicuci.
1. Masak hingga matang seperti masak nasi biasa pakai rice cooker.
1. Aduk aduk jika nasi sudah matang.




Bagaimana? Mudah bukan? Itulah cara menyiapkan nasi kuning yang bisa Anda praktikkan di rumah. Selamat mencoba!
