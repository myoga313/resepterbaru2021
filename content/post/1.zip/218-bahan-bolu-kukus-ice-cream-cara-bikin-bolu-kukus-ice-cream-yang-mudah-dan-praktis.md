---
description: "Bahan Bolu Kukus Ice Cream | Cara Bikin Bolu Kukus Ice Cream Yang Mudah Dan Praktis"
title: "Bahan Bolu Kukus Ice Cream | Cara Bikin Bolu Kukus Ice Cream Yang Mudah Dan Praktis"
slug: 218-bahan-bolu-kukus-ice-cream-cara-bikin-bolu-kukus-ice-cream-yang-mudah-dan-praktis
date: 2021-01-13T23:57:36.776Z
image: https://img-global.cpcdn.com/recipes/774d62e18a9891a9/751x532cq70/bolu-kukus-ice-cream-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/774d62e18a9891a9/751x532cq70/bolu-kukus-ice-cream-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/774d62e18a9891a9/751x532cq70/bolu-kukus-ice-cream-foto-resep-utama.jpg
author: Marguerite Garner
ratingvalue: 3.5
reviewcount: 14
recipeingredient:
- " tepung terigu"
- " santan"
- " minyak goreng"
- " bubuk coklat"
- " Pasta sesuai selerastrawberry coklat pandan pewarna kuning"
- " Kacang tanah sangrai cincang kasar"
recipeinstructions:
- "Panaskan kukusan. Alasi tutup dengan kain bersih. (Sy pakai klakat) Lapisi cetakan cone dengan baking paper."
- "Mixer telur, gula pasir dan sp dengan kecepatan tinggi sampai mengembang, putih dan berjejak."
- "Masukkan tepung terigu, aduk balik dengan spatula hingga rata."
- "Masukkan santan dan minyak, aduk balik perlahan dengan spatula."
- "Bagi jadi beberapa adonan. Beri setiap Adonan dengan warna pasta yg diinginkan. Masukkan tiap adonan ke dalam piping bag."
- "Tuang dalam cetakan secara berurutan: setiap warna adonan yg diinginkan"
- "Kukus dengan api sedang cenderung kecil selama 15 menit. Angkat dan dinginkan. Bolu jangan dilepas dulu dari baking paper, karena akan diberi topping."
- "Setelah dingin, permukaan atas bolu diberi topping coklat blok yang dilelehkan (bisa gunakan piping bag supaya rapi). Lalu taburi kacang sangrai."
- "Setelah topping kering, lepaskan baking paper, dan sajikan."
categories:
- Resep
tags:
- bolu
- kukus
- ice

katakunci: bolu kukus ice 
nutrition: 193 calories
recipecuisine: Indonesian
preptime: "PT37M"
cooktime: "PT33M"
recipeyield: "4"
recipecategory: Lunch

---


![Bolu Kukus Ice Cream](https://img-global.cpcdn.com/recipes/774d62e18a9891a9/751x532cq70/bolu-kukus-ice-cream-foto-resep-utama.jpg)


bolu kukus ice cream ini ialah hidangan nusantara yang nikmat dan wajib untuk kita coba. Cita rasanya yang mantap membuat siapa pun menantikan kehadirannya di meja makan.
Bunda Sedang mencari inspirasi resep bolu kukus ice cream untuk jualan atau dikonsumsi sendiri yang Enak Banget? Cara Bikinnya memang tidak terlalu sulit namun tidak gampang juga. seandainya salah mengolah maka hasilnya tidak akan memuaskan dan bahkan tidak sedap. Padahal bolu kukus ice cream yang enak harusnya sih mempunyai aroma dan rasa yang dapat memancing selera kita.

Ada beberapa hal yang sedikit banyak mempengaruhi kualitas rasa dari bolu kukus ice cream, mulai dari jenis bahan, lalu pemilihan bahan segar, sampai cara mengolah dan menghidangkannya. Tak perlu pusing jika ingin menyiapkan bolu kukus ice cream yang enak di rumah, karena asal sudah tahu triknya maka hidangan ini bisa menjadi sajian istimewa.




Nah, kali ini kita coba, yuk, kreasikan bolu kukus ice cream sendiri di rumah. Tetap dengan bahan yang sederhana, sajian ini bisa memberi manfaat dalam membantu menjaga kesehatan tubuhmu sekeluarga. Anda dapat membuat Bolu Kukus Ice Cream menggunakan 6 bahan dan 9 langkah pembuatan. Berikut ini langkah-langkah dalam menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam pembuatan Bolu Kukus Ice Cream:

1. Gunakan  tepung terigu
1. Sediakan  santan
1. Ambil  minyak goreng
1. Siapkan  bubuk coklat
1. Ambil  Pasta sesuai selera(strawberry, coklat, pandan, pewarna kuning)
1. Siapkan  Kacang tanah (sangrai, cincang kasar)




<!--inarticleads2-->

##### Cara menyiapkan Bolu Kukus Ice Cream:

1. Panaskan kukusan. Alasi tutup dengan kain bersih. (Sy pakai klakat) Lapisi cetakan cone dengan baking paper.
1. Mixer telur, gula pasir dan sp dengan kecepatan tinggi sampai mengembang, putih dan berjejak.
1. Masukkan tepung terigu, aduk balik dengan spatula hingga rata.
1. Masukkan santan dan minyak, aduk balik perlahan dengan spatula.
1. Bagi jadi beberapa adonan. Beri setiap Adonan dengan warna pasta yg diinginkan. Masukkan tiap adonan ke dalam piping bag.
1. Tuang dalam cetakan secara berurutan: setiap warna adonan yg diinginkan
1. Kukus dengan api sedang cenderung kecil selama 15 menit. Angkat dan dinginkan. Bolu jangan dilepas dulu dari baking paper, karena akan diberi topping.
1. Setelah dingin, permukaan atas bolu diberi topping coklat blok yang dilelehkan (bisa gunakan piping bag supaya rapi). Lalu taburi kacang sangrai.
1. Setelah topping kering, lepaskan baking paper, dan sajikan.




Bagaimana? Mudah bukan? Itulah cara menyiapkan bolu kukus ice cream yang bisa Anda praktikkan di rumah. Selamat mencoba!
