---
description: "Resep masakan Bubur Sum-sum Hijau | Langkah Membuat Bubur Sum-sum Hijau Yang Menggugah Selera"
title: "Resep masakan Bubur Sum-sum Hijau | Langkah Membuat Bubur Sum-sum Hijau Yang Menggugah Selera"
slug: 23-resep-masakan-bubur-sum-sum-hijau-langkah-membuat-bubur-sum-sum-hijau-yang-menggugah-selera
date: 2020-09-26T20:02:36.944Z
image: https://img-global.cpcdn.com/recipes/b01b3ba56fa6ae4e/751x532cq70/bubur-sum-sum-hijau-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/b01b3ba56fa6ae4e/751x532cq70/bubur-sum-sum-hijau-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/b01b3ba56fa6ae4e/751x532cq70/bubur-sum-sum-hijau-foto-resep-utama.jpg
author: Jim Hernandez
ratingvalue: 3
reviewcount: 9
recipeingredient:
- " sdm 100 gr tepung beras"
- " santan kara uk 65 ml"
- " daun pandan me 23 tetes perasa pandan warna hijau"
- " garam"
- " air"
- " Kinca sirup gula "
- " gula merah"
- " air100 ml"
- " daun pandan me 1 tetes perasa pandan"
- " garam"
recipeinstructions:
- "Siapkan bahan2. Campur 800 ml air dengan santan kara dan perasa pandan, aduk rata. Sisihkan santan 300 ml dan tuangkan ke tepung beras sedikit2 sambil diaduk agar tidak bergerindil. Sisihkan."
- "Masak 500 ml santan sampai hampir mendidih, kecilkan api. Tuang cairan tepung beras ke dalam santan sambil diaduk sampai santan habis dan adonan meletup- letup. Matikan api, sisihkan."
- "Masak gula merah dengan air, daun pandan dan sejumput garam sampai mendidih. Matikan api. Dinginkan lalu saring."
- "Sajikan bubur dengan kincanya."
categories:
- Resep
tags:
- bubur
- sumsum
- hijau

katakunci: bubur sumsum hijau 
nutrition: 222 calories
recipecuisine: Indonesian
preptime: "PT24M"
cooktime: "PT55M"
recipeyield: "2"
recipecategory: Dinner

---


![Bubur Sum-sum Hijau](https://img-global.cpcdn.com/recipes/b01b3ba56fa6ae4e/751x532cq70/bubur-sum-sum-hijau-foto-resep-utama.jpg)


bubur sum-sum hijau ini yaitu kuliner nusantara yang spesial dan perlu untuk kita coba. Cita rasanya yang lezat membuat siapa pun menantikan kehadirannya di meja makan.
Kamu Sedang mencari inspirasi resep bubur sum-sum hijau untuk jualan atau dikonsumsi sendiri yang Lezat? Cara menyiapkannya memang susah-susah gampang. apabila keliru mengolah maka hasilnya Tidak Memuaskan dan justru cenderung tidak enak. Padahal bubur sum-sum hijau yang enak seharusnya punya aroma dan cita rasa yang bisa memancing selera kita.

Banyak hal yang sedikit banyak mempengaruhi kualitas rasa dari bubur sum-sum hijau, mulai dari jenis bahan, lalu pemilihan bahan segar, hingga cara membuat dan menyajikannya. Tak perlu pusing kalau ingin menyiapkan bubur sum-sum hijau enak di rumah, karena asal sudah tahu triknya maka hidangan ini mampu menjadi suguhan spesial.




Berikut ini ada beberapa cara mudah dan praktis yang dapat diterapkan untuk mengolah bubur sum-sum hijau yang siap dikreasikan. Anda dapat menyiapkan Bubur Sum-sum Hijau memakai 10 jenis bahan dan 4 langkah pembuatan. Berikut ini cara untuk membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk menyiapkan Bubur Sum-sum Hijau:

1. Sediakan  sdm/ 100 gr tepung beras
1. Ambil  santan kara uk 65 ml
1. Ambil  daun pandan (me: 2-3 tetes perasa pandan warna hijau)
1. Sediakan  garam
1. Sediakan  air
1. Ambil  Kinca (sirup gula) :
1. Sediakan  gula merah
1. Siapkan  air/100 ml
1. Gunakan  daun pandan (me: 1 tetes perasa pandan)
1. Sediakan  garam




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Bubur Sum-sum Hijau:

1. Siapkan bahan2. Campur 800 ml air dengan santan kara dan perasa pandan, aduk rata. Sisihkan santan 300 ml dan tuangkan ke tepung beras sedikit2 sambil diaduk agar tidak bergerindil. Sisihkan.
1. Masak 500 ml santan sampai hampir mendidih, kecilkan api. Tuang cairan tepung beras ke dalam santan sambil diaduk sampai santan habis dan adonan meletup- letup. Matikan api, sisihkan.
1. Masak gula merah dengan air, daun pandan dan sejumput garam sampai mendidih. Matikan api. Dinginkan lalu saring.
1. Sajikan bubur dengan kincanya.




Terima kasih telah membaca resep yang tim kami tampilkan di sini. Besar harapan kami, olahan Bubur Sum-sum Hijau yang mudah di atas dapat membantu Anda menyiapkan hidangan yang lezat untuk keluarga/teman ataupun menjadi inspirasi bagi Anda yang berkeinginan untuk berjualan makanan. Selamat mencoba!
