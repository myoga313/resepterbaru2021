---
description: "Resep masakan Ayam Kecap ala Warung Gajebo | Cara Bikin Ayam Kecap ala Warung Gajebo Yang Bisa Manjain Lidah"
title: "Resep masakan Ayam Kecap ala Warung Gajebo | Cara Bikin Ayam Kecap ala Warung Gajebo Yang Bisa Manjain Lidah"
slug: 380-resep-masakan-ayam-kecap-ala-warung-gajebo-cara-bikin-ayam-kecap-ala-warung-gajebo-yang-bisa-manjain-lidah
date: 2020-12-12T01:45:36.370Z
image: https://img-global.cpcdn.com/recipes/221ac3487504aae4/751x532cq70/ayam-kecap-ala-warung-gajebo-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/221ac3487504aae4/751x532cq70/ayam-kecap-ala-warung-gajebo-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/221ac3487504aae4/751x532cq70/ayam-kecap-ala-warung-gajebo-foto-resep-utama.jpg
author: Chase Hughes
ratingvalue: 4.8
reviewcount: 11
recipeingredient:
- "2-3 potong ayam goreng tepung"
- "1/4 butir kubis"
- "1 buah terong"
- " Bumbu"
- "4 siung bawang putih"
- "10 buah cabai keriting merah"
- "5 buah cabai rawit"
- "1/2 sdt kaldu jamur"
- "Secukupnya lada bubuk"
- "Secukupnya kecap"
- "Secukupnya gula pasir"
- "Secukupnya air"
recipeinstructions:
- "Geprek ayam goreng tepung (saya beli jadi; bisa pakai ayam olive, mcd, kfc atau apapun—kalau mau bikin sendiri pun nggak masalah. Yg penting sudah berbumbu)"
- "Potong terong menjadi potongan bulat tipis (disini saya ganti terong dengan jamur champignon). Potong kubis. Sisihkan."
- "Uleg kasar bawang putih &amp; cabai. Lalu tumis hingga harum."
- "Setelah bumbu harum, tambahkan sedikit air. Masukan terong. Tambahkan kaldu, gula, lada, dan kecap. Aduk rata."
- "Masukkan ayam yang sudah digeprek dan kubis. Aduk rata. Koreksi rasa. Siap disajikan."
categories:
- Resep
tags:
- ayam
- kecap
- ala

katakunci: ayam kecap ala 
nutrition: 142 calories
recipecuisine: Indonesian
preptime: "PT31M"
cooktime: "PT56M"
recipeyield: "1"
recipecategory: Dinner

---


![Ayam Kecap ala Warung Gajebo](https://img-global.cpcdn.com/recipes/221ac3487504aae4/751x532cq70/ayam-kecap-ala-warung-gajebo-foto-resep-utama.jpg)


ayam kecap ala warung gajebo ini merupakan kuliner tanah air yang lezat dan harus untuk kita coba. Cita rasanya yang lezat membuat siapa pun menantikan kehadirannya di meja makan.
Kamu Sedang mencari ide resep ayam kecap ala warung gajebo untuk jualan atau dikonsumsi sendiri yang Sedap? Cara menyiapkannya memang tidak susah dan tidak juga mudah. Jika salah mengolah maka hasilnya Tidak Memuaskan dan bahkan tidak sedap. Padahal ayam kecap ala warung gajebo yang enak seharusnya mempunyai aroma dan rasa yang bisa memancing selera kita.



Ada beberapa hal yang sedikit banyak mempengaruhi kualitas rasa dari ayam kecap ala warung gajebo, mulai dari jenis bahan, kedua pemilihan bahan segar sampai cara membuat dan menghidangkannya. Tak perlu pusing kalau ingin menyiapkan ayam kecap ala warung gajebo enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini mampu menjadi sajian istimewa.


Nah, kali ini kita coba, yuk, ciptakan ayam kecap ala warung gajebo sendiri di rumah. Tetap dengan bahan sederhana, sajian ini dapat memberi manfaat dalam membantu menjaga kesehatan tubuh kita. Anda dapat membuat Ayam Kecap ala Warung Gajebo memakai 12 bahan dan 5 langkah pembuatan. Berikut ini langkah-langkah dalam membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk menyiapkan Ayam Kecap ala Warung Gajebo:

1. Siapkan 2-3 potong ayam goreng tepung
1. Sediakan 1/4 butir kubis
1. Sediakan 1 buah terong
1. Gunakan  Bumbu
1. Ambil 4 siung bawang putih
1. Siapkan 10 buah cabai keriting merah
1. Sediakan 5 buah cabai rawit
1. Siapkan 1/2 sdt kaldu jamur
1. Sediakan Secukupnya lada bubuk
1. Siapkan Secukupnya kecap
1. Ambil Secukupnya gula pasir
1. Sediakan Secukupnya air




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Ayam Kecap ala Warung Gajebo:

1. Geprek ayam goreng tepung (saya beli jadi; bisa pakai ayam olive, mcd, kfc atau apapun—kalau mau bikin sendiri pun nggak masalah. Yg penting sudah berbumbu)
1. Potong terong menjadi potongan bulat tipis (disini saya ganti terong dengan jamur champignon). Potong kubis. Sisihkan.
1. Uleg kasar bawang putih &amp; cabai. Lalu tumis hingga harum.
1. Setelah bumbu harum, tambahkan sedikit air. Masukan terong. Tambahkan kaldu, gula, lada, dan kecap. Aduk rata.
1. Masukkan ayam yang sudah digeprek dan kubis. Aduk rata. Koreksi rasa. Siap disajikan.




Gimana nih? Mudah bukan? Itulah cara menyiapkan ayam kecap ala warung gajebo yang bisa Anda praktikkan di rumah. Selamat mencoba!
