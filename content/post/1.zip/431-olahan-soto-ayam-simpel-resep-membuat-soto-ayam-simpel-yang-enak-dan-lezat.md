---
description: "Olahan Soto Ayam Simpel | Resep Membuat Soto Ayam Simpel Yang Enak Dan Lezat"
title: "Olahan Soto Ayam Simpel | Resep Membuat Soto Ayam Simpel Yang Enak Dan Lezat"
slug: 431-olahan-soto-ayam-simpel-resep-membuat-soto-ayam-simpel-yang-enak-dan-lezat
date: 2021-01-07T23:38:30.944Z
image: https://img-global.cpcdn.com/recipes/dc865cf2333ac35e/751x532cq70/soto-ayam-simpel-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/dc865cf2333ac35e/751x532cq70/soto-ayam-simpel-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/dc865cf2333ac35e/751x532cq70/soto-ayam-simpel-foto-resep-utama.jpg
author: Vera Lopez
ratingvalue: 3.4
reviewcount: 10
recipeingredient:
- " ayam potongan dadapaha"
- " Bumbu halus"
- " Kunyit ukuran kelingking"
- " Bawang merah 6 siung ukuran sedangbesar"
- " Bawang putih 2 siung ukuran besar"
- " jahe 1cm"
- " Kemiri"
- " Merica"
- " Ketumbar"
- " Pala bubuk"
- " Serai 2 batang 1 batang untuk rebus ayam 1batang untuk menumis"
- " Daun Salam 4 lembar 2 rebus ayam 2menumis"
- " Daun jeruk purut"
- " lengkuas geprekiris"
- " Bawang merah goreng kemasan"
- " Daun bawang dan seledri"
- " Gula garam penyedap"
- " Pelengkapnya"
- " Cabe 6 dan 1btr kemiri untuk sambal"
- " Kecap"
- " Cukajeruk nipis"
- " Kecambah kecil"
- " Seledri iris halus"
recipeinstructions:
- "Potong ayam dan rebus ayam untuk membuang kotoran lemak pada ayam dgn menambahkan satu btg serai, 2 lembar daun salam, 1 sdt garam"
- "Setelah mendidih dan ayam dirasa empuk, angkat dan tiriskan. Cabut tulang ayam untuk kaldu pada kuah soto. Sisihkan daging ayam untuk digoreng basah."
- "Haluskan bumbu. Setelah halus, tumis bumbu halus dengan 2 SDM minyak goreng hingga wangi. Tambahkan 2 daun salam, 2 lembar jeruk purut, lengkuas, 1 btg serai. Jangan sampai gosong, tambahkan air 1.5 L dan masukan tulang ayam. Rebus hingga matang. Tambahkan gula, garam, penyedap rasa sesuai selera."
- "Setelah mendidih dan rasa sesuai selera, tambahkan irisan daun bawang, seledri dan bawang goreng."
- "Matikan kompor. Baluri daging ayam dengan garam. Goreng basah daging ayam. Setelah cukup angkat tiriskan."
- "Sajikan nasi bersama daging ayam yang sudah digoreng."
categories:
- Resep
tags:
- soto
- ayam
- simpel

katakunci: soto ayam simpel 
nutrition: 142 calories
recipecuisine: Indonesian
preptime: "PT26M"
cooktime: "PT34M"
recipeyield: "4"
recipecategory: Dessert

---


![Soto Ayam Simpel](https://img-global.cpcdn.com/recipes/dc865cf2333ac35e/751x532cq70/soto-ayam-simpel-foto-resep-utama.jpg)


soto ayam simpel ini merupakan sajian nusantara yang mantap dan perlu untuk kita coba. Cita rasanya yang nikmat membuat siapa pun menantikan kehadirannya di meja makan.
Sedang mencari inspirasi resep soto ayam simpel untuk jualan atau dikonsumsi sendiri yang Lezat Sekali? Cara Memasaknya memang susah-susah gampang. bila salah mengolah maka hasilnya Tidak Memuaskan dan bahkan tidak sedap. Padahal soto ayam simpel yang enak seharusnya memiliki aroma dan cita rasa yang dapat memancing selera kita.



Ada beberapa hal yang sedikit banyak mempengaruhi kualitas rasa dari soto ayam simpel, mulai dari jenis bahan, kemudian pemilihan bahan segar sampai cara membuat dan menghidangkannya. Tak perlu pusing kalau mau menyiapkan soto ayam simpel enak di rumah, karena asal sudah tahu triknya maka hidangan ini bisa menjadi suguhan spesial.


Berikut ini ada beberapa tips dan trik praktis untuk membuat soto ayam simpel yang siap dikreasikan. Anda bisa membuat Soto Ayam Simpel menggunakan 23 jenis bahan dan 6 tahap pembuatan. Berikut ini langkah-langkah untuk menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk pembuatan Soto Ayam Simpel:

1. Gunakan  ayam (potongan dada/paha)
1. Siapkan  Bumbu halus:
1. Sediakan  Kunyit ukuran kelingking
1. Sediakan  Bawang merah 6 siung (ukuran sedang/besar)
1. Sediakan  Bawang putih 2 siung ukuran besar
1. Sediakan  jahe 1cm
1. Ambil  Kemiri
1. Ambil  Merica
1. Ambil  Ketumbar
1. Sediakan  Pala bubuk
1. Gunakan  Serai 2 batang (1 batang untuk rebus ayam, 1batang untuk menumis
1. Gunakan  Daun Salam 4 lembar (2 rebus ayam, 2menumis)
1. Siapkan  Daun jeruk purut
1. Sediakan  lengkuas geprek/iris
1. Gunakan  Bawang merah goreng kemasan
1. Ambil  Daun bawang dan seledri
1. Sediakan  Gula, garam, penyedap
1. Ambil  Pelengkapnya:
1. Siapkan  Cabe 6 dan 1btr kemiri untuk sambal
1. Sediakan  Kecap
1. Siapkan  Cuka/jeruk nipis
1. Ambil  Kecambah kecil
1. Gunakan  Seledri iris halus




<!--inarticleads2-->

##### Langkah-langkah membuat Soto Ayam Simpel:

1. Potong ayam dan rebus ayam untuk membuang kotoran lemak pada ayam dgn menambahkan satu btg serai, 2 lembar daun salam, 1 sdt garam
1. Setelah mendidih dan ayam dirasa empuk, angkat dan tiriskan. Cabut tulang ayam untuk kaldu pada kuah soto. Sisihkan daging ayam untuk digoreng basah.
1. Haluskan bumbu. Setelah halus, tumis bumbu halus dengan 2 SDM minyak goreng hingga wangi. Tambahkan 2 daun salam, 2 lembar jeruk purut, lengkuas, 1 btg serai. Jangan sampai gosong, tambahkan air 1.5 L dan masukan tulang ayam. Rebus hingga matang. Tambahkan gula, garam, penyedap rasa sesuai selera.
1. Setelah mendidih dan rasa sesuai selera, tambahkan irisan daun bawang, seledri dan bawang goreng.
1. Matikan kompor. Baluri daging ayam dengan garam. Goreng basah daging ayam. Setelah cukup angkat tiriskan.
1. Sajikan nasi bersama daging ayam yang sudah digoreng.




Gimana nih? Mudah bukan? Itulah cara membuat soto ayam simpel yang bisa Anda praktikkan di rumah. Selamat mencoba!
