---
description: "Bumbu Donat Gembul Ekonomis Tanpa Telur (Eggless) | Bahan Membuat Donat Gembul Ekonomis Tanpa Telur (Eggless) Yang Enak dan Simpel"
title: "Bumbu Donat Gembul Ekonomis Tanpa Telur (Eggless) | Bahan Membuat Donat Gembul Ekonomis Tanpa Telur (Eggless) Yang Enak dan Simpel"
slug: 166-bumbu-donat-gembul-ekonomis-tanpa-telur-eggless-bahan-membuat-donat-gembul-ekonomis-tanpa-telur-eggless-yang-enak-dan-simpel
date: 2020-10-06T02:15:28.147Z
image: https://img-global.cpcdn.com/recipes/8ec3a12772777525/751x532cq70/donat-gembul-ekonomis-tanpa-telur-eggless-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/8ec3a12772777525/751x532cq70/donat-gembul-ekonomis-tanpa-telur-eggless-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/8ec3a12772777525/751x532cq70/donat-gembul-ekonomis-tanpa-telur-eggless-foto-resep-utama.jpg
author: Duane Santiago
ratingvalue: 3.9
reviewcount: 10
recipeingredient:
- "25 Sdm Tepung Terigu"
- "3 Sdm Gula Pasir"
- "3 Sdm Susu Bubuk Me SKM"
- "4 Sdm Margarin"
- "1 Sdt Ragi Instan"
- "1 Gelas Belimbing Air Hangat"
- "Secukupnya Garam"
- " Topping Optional "
- " Meses Coklat"
- " Keju Parut"
- " Cream"
recipeinstructions:
- "Campurkan gula dan ragi instan dalam gelas, tambahkan air hangat kuku hingga 1 gelas penuh (jangan air panas yaa, punya saya tidak penuh karena ukuran gelas lebih besar dari gelas belimbing). Aduk rata, lalu diamkan selama 10-15 menit hingga berbuih."
- "Setelah 10-15 menit, air ragi akan berbuih banyak dan tinggi. Jika tidak berbuih, artinya ragi tidak aktif, ganti ragi dan ulangi langkah pertama kembali."
- "Tuang air ragi ke dalam tepung terigu sedikit demi sedikit, aduk terus hingga tercampur merata dan air habis."
- "Tambahkan susu, mentega dan garam, uleni adonan hingga kalis elastis. (Punya saya tidak sampai elastis tapi lumayan kalis, karena yang ngulenin suami jadi dimaklumi) 😁 Istirahatkan adonan selama 45-50 menit. Tutup atas wadah dengan lap bersih ya, adonan nanti akan mengembang 2x lipat."
- "Setelah mengembang, pukul-pukul adonan dan uleni sebentar saja untuk mengeluarkan udara di dalamnya."
- "Ambil adonan secukupnya, bulatkan lalu pipihkan dan beri lubang di tengahnya. Lakukan hingga adonan habis. Selagi proses ini, adonan yang dibentuk pertama akan mengembang kembali nantinya."
- "Panaskan minyak, goreng adonan yang sudah kembali mengembang dengan api sedang. Balik sekali saja, agar tidak terlalu berminyak. Jika sudah matang, angkat lalu tiriskan. Saya baru ngeh kalau ada white ring-nya 😁"
- "Oleskan cream di bagian atas donat untuk melekatkan topping, jika tidak ada bisa diganti dengan margarin + skm yang diaduk rata. Sajikan selagi hangat. Donat gembul ini renyah waktu digigit, tapi lembut di dalam. Love banget lah pokoknya. 💕"
categories:
- Resep
tags:
- donat
- gembul
- ekonomis

katakunci: donat gembul ekonomis 
nutrition: 136 calories
recipecuisine: Indonesian
preptime: "PT30M"
cooktime: "PT42M"
recipeyield: "3"
recipecategory: Dessert

---


![Donat Gembul Ekonomis Tanpa Telur (Eggless)](https://img-global.cpcdn.com/recipes/8ec3a12772777525/751x532cq70/donat-gembul-ekonomis-tanpa-telur-eggless-foto-resep-utama.jpg)


donat gembul ekonomis tanpa telur (eggless) ini ialah sajian tanah air yang ekslusif dan wajib untuk kita coba. Cita rasanya yang nikmat membuat siapa pun menantikan kehadirannya di meja makan.
Bunda Sedang mencari ide resep donat gembul ekonomis tanpa telur (eggless) untuk jualan atau dikonsumsi sendiri yang Enak dan Simpel? Cara menyiapkannya memang susah-susah gampang. kalau keliru mengolah maka hasilnya akan hambar dan justru cenderung tidak enak. Padahal donat gembul ekonomis tanpa telur (eggless) yang enak harusnya sih punya aroma dan cita rasa yang mampu memancing selera kita.

Ada beberapa hal yang sedikit banyak mempengaruhi kualitas rasa dari donat gembul ekonomis tanpa telur (eggless), mulai dari jenis bahan, kemudian pemilihan bahan segar, sampai cara membuat dan menghidangkannya. Tidak usah pusing jika ingin menyiapkan donat gembul ekonomis tanpa telur (eggless) enak di rumah, karena asal sudah tahu triknya maka hidangan ini mampu menjadi suguhan spesial.




Nah, kali ini kita coba, yuk, siapkan donat gembul ekonomis tanpa telur (eggless) sendiri di rumah. Tetap dengan bahan yang sederhana, sajian ini bisa memberi manfaat dalam membantu menjaga kesehatan tubuhmu sekeluarga. Anda bisa membuat Donat Gembul Ekonomis Tanpa Telur (Eggless) memakai 11 jenis bahan dan 8 langkah pembuatan. Berikut ini langkah-langkah untuk menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk pembuatan Donat Gembul Ekonomis Tanpa Telur (Eggless):

1. Sediakan 25 Sdm Tepung Terigu
1. Ambil 3 Sdm Gula Pasir
1. Siapkan 3 Sdm Susu Bubuk (Me: SKM)
1. Ambil 4 Sdm Margarin
1. Ambil 1 Sdt Ragi Instan
1. Sediakan 1 Gelas Belimbing Air Hangat
1. Gunakan Secukupnya Garam
1. Gunakan  Topping (Optional) :
1. Siapkan  Meses Coklat
1. Gunakan  Keju Parut
1. Siapkan  Cream




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Donat Gembul Ekonomis Tanpa Telur (Eggless):

1. Campurkan gula dan ragi instan dalam gelas, tambahkan air hangat kuku hingga 1 gelas penuh (jangan air panas yaa, punya saya tidak penuh karena ukuran gelas lebih besar dari gelas belimbing). Aduk rata, lalu diamkan selama 10-15 menit hingga berbuih.
1. Setelah 10-15 menit, air ragi akan berbuih banyak dan tinggi. Jika tidak berbuih, artinya ragi tidak aktif, ganti ragi dan ulangi langkah pertama kembali.
1. Tuang air ragi ke dalam tepung terigu sedikit demi sedikit, aduk terus hingga tercampur merata dan air habis.
1. Tambahkan susu, mentega dan garam, uleni adonan hingga kalis elastis. (Punya saya tidak sampai elastis tapi lumayan kalis, karena yang ngulenin suami jadi dimaklumi) 😁 Istirahatkan adonan selama 45-50 menit. Tutup atas wadah dengan lap bersih ya, adonan nanti akan mengembang 2x lipat.
1. Setelah mengembang, pukul-pukul adonan dan uleni sebentar saja untuk mengeluarkan udara di dalamnya.
1. Ambil adonan secukupnya, bulatkan lalu pipihkan dan beri lubang di tengahnya. Lakukan hingga adonan habis. Selagi proses ini, adonan yang dibentuk pertama akan mengembang kembali nantinya.
1. Panaskan minyak, goreng adonan yang sudah kembali mengembang dengan api sedang. Balik sekali saja, agar tidak terlalu berminyak. Jika sudah matang, angkat lalu tiriskan. Saya baru ngeh kalau ada white ring-nya 😁
1. Oleskan cream di bagian atas donat untuk melekatkan topping, jika tidak ada bisa diganti dengan margarin + skm yang diaduk rata. Sajikan selagi hangat. Donat gembul ini renyah waktu digigit, tapi lembut di dalam. Love banget lah pokoknya. 💕




Bagaimana? Mudah bukan? Itulah cara menyiapkan donat gembul ekonomis tanpa telur (eggless) yang bisa Anda lakukan di rumah. Semoga bermanfaat dan selamat mencoba!
