---
description: "Resep Donat sp toping sugar castor cinnamon | Langkah Membuat Donat sp toping sugar castor cinnamon Yang Lezat"
title: "Resep Donat sp toping sugar castor cinnamon | Langkah Membuat Donat sp toping sugar castor cinnamon Yang Lezat"
slug: 186-resep-donat-sp-toping-sugar-castor-cinnamon-langkah-membuat-donat-sp-toping-sugar-castor-cinnamon-yang-lezat
date: 2021-01-09T00:56:31.536Z
image: https://img-global.cpcdn.com/recipes/5345872be6fb0a47/751x532cq70/donat-sp-toping-sugar-castor-cinnamon-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/5345872be6fb0a47/751x532cq70/donat-sp-toping-sugar-castor-cinnamon-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/5345872be6fb0a47/751x532cq70/donat-sp-toping-sugar-castor-cinnamon-foto-resep-utama.jpg
author: Beatrice Conner
ratingvalue: 3.8
reviewcount: 14
recipeingredient:
- " Bahan bahan"
- "300 gram tepung terigu serbaguna"
- "1 sdt ragi instan"
- "3 sdm gula pasir"
- "160 ml susu cair"
- "1 sdm margarine"
- "1/4 sdt garam"
- "3/4 sdt SPovalet"
- " Bahan taburan"
- "5 sdm gula pasir di blender tdk terlalu halus"
- "1 sdt bubuk cinnamon"
recipeinstructions:
- "Campur jadi satu tepung terigu, ragi dan gula, aduk aduk, tuang sedikit demi sedikit susu cair sampai adonan setengah kalis, lalu pindahkan ke meja kerja dan beri margarine serta SP, uleni kembali sampai kalis elastis. (sy uleni hanya 5 menit saja yg penting adonan sdh lembut dan bulatkan)"
- "Letakkan kembali ke wadah lalu tutup dng kain serbet atau plastik warp, rehatkan 30 menit. Lalu timbang dng ukuran 39 gram, dan bulatkan dan pipihkan. Rehatkan 10 mnt lalu ambil spuit, tekan di tengah2 donat untk buat bulatan. Lakukan sampai habis"
- "Panaskan minyak dalam wajan, setelah itu goreng donat, biarkan sisi bawah berwarna kecoklatan lalu baru balek, setelah berwarna coklat angkat dan tiriskan."
- "Siapkan gula castor dan bubuk cinnamon aduk rata. Lalu gulingkan donat sambil ditekan tekan supaya menempel. Lakukan untk semua donat. Donat sp ini empuk dan teksurnya padat.. Enak banget.."
categories:
- Resep
tags:
- donat
- sp
- toping

katakunci: donat sp toping 
nutrition: 260 calories
recipecuisine: Indonesian
preptime: "PT29M"
cooktime: "PT54M"
recipeyield: "4"
recipecategory: Lunch

---


![Donat sp toping sugar castor cinnamon](https://img-global.cpcdn.com/recipes/5345872be6fb0a47/751x532cq70/donat-sp-toping-sugar-castor-cinnamon-foto-resep-utama.jpg)


donat sp toping sugar castor cinnamon ini ialah makanan tanah air yang unik dan perlu untuk kita coba. Cita rasanya yang enak membuat siapa pun menantikan kehadirannya di meja makan.
Anda sedang mencari ide resep donat sp toping sugar castor cinnamon untuk jualan atau dikonsumsi sendiri yang Paling Enak? Cara menyiapkannya memang susah-susah gampang. andaikan keliru mengolah maka hasilnya tidak akan memuaskan dan justru cenderung tidak enak. Padahal donat sp toping sugar castor cinnamon yang enak selayaknya mempunyai aroma dan cita rasa yang bisa memancing selera kita.



Banyak hal yang sedikit banyak mempengaruhi kualitas rasa dari donat sp toping sugar castor cinnamon, pertama dari jenis bahan, kedua pemilihan bahan segar sampai cara membuat dan menghidangkannya. Tidak usah pusing kalau hendak menyiapkan donat sp toping sugar castor cinnamon yang enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini mampu jadi sajian istimewa.


Nah, kali ini kita coba, yuk, kreasikan donat sp toping sugar castor cinnamon sendiri di rumah. Tetap berbahan yang sederhana, hidangan ini bisa memberi manfaat untuk membantu menjaga kesehatan tubuh kita. Anda bisa membuat Donat sp toping sugar castor cinnamon memakai 11 bahan dan 4 tahap pembuatan. Berikut ini cara untuk membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam pembuatan Donat sp toping sugar castor cinnamon:

1. Sediakan  ☘️Bahan bahan
1. Siapkan 300 gram tepung terigu serbaguna
1. Gunakan 1 sdt ragi instan
1. Ambil 3 sdm gula pasir
1. Gunakan 160 ml susu cair
1. Ambil 1 sdm margarine
1. Gunakan 1/4 sdt garam
1. Ambil 3/4 sdt SP/ovalet
1. Ambil  ☘️Bahan taburan
1. Gunakan 5 sdm gula pasir di blender tdk terlalu halus
1. Gunakan 1 sdt bubuk cinnamon




<!--inarticleads2-->

##### Cara menyiapkan Donat sp toping sugar castor cinnamon:

1. Campur jadi satu tepung terigu, ragi dan gula, aduk aduk, tuang sedikit demi sedikit susu cair sampai adonan setengah kalis, lalu pindahkan ke meja kerja dan beri margarine serta SP, uleni kembali sampai kalis elastis. (sy uleni hanya 5 menit saja yg penting adonan sdh lembut dan bulatkan)
1. Letakkan kembali ke wadah lalu tutup dng kain serbet atau plastik warp, rehatkan 30 menit. Lalu timbang dng ukuran 39 gram, dan bulatkan dan pipihkan. Rehatkan 10 mnt lalu ambil spuit, tekan di tengah2 donat untk buat bulatan. Lakukan sampai habis
1. Panaskan minyak dalam wajan, setelah itu goreng donat, biarkan sisi bawah berwarna kecoklatan lalu baru balek, setelah berwarna coklat angkat dan tiriskan.
1. Siapkan gula castor dan bubuk cinnamon aduk rata. Lalu gulingkan donat sambil ditekan tekan supaya menempel. Lakukan untk semua donat. Donat sp ini empuk dan teksurnya padat.. Enak banget..




Terima kasih telah menggunakan resep yang tim kami tampilkan di sini. Besar harapan kami, olahan Donat sp toping sugar castor cinnamon yang mudah di atas dapat membantu Anda menyiapkan hidangan yang lezat untuk keluarga/teman ataupun menjadi ide untuk berjualan makanan. Selamat mencoba!
