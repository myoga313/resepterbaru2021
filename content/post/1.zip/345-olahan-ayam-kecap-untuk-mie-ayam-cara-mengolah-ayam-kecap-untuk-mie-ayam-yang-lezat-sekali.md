---
description: "Olahan Ayam Kecap (untuk mie ayam) | Cara Mengolah Ayam Kecap (untuk mie ayam) Yang Lezat Sekali"
title: "Olahan Ayam Kecap (untuk mie ayam) | Cara Mengolah Ayam Kecap (untuk mie ayam) Yang Lezat Sekali"
slug: 345-olahan-ayam-kecap-untuk-mie-ayam-cara-mengolah-ayam-kecap-untuk-mie-ayam-yang-lezat-sekali
date: 2021-01-23T21:03:15.144Z
image: https://img-global.cpcdn.com/recipes/002cdf4c7cb078ce/751x532cq70/ayam-kecap-untuk-mie-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/002cdf4c7cb078ce/751x532cq70/ayam-kecap-untuk-mie-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/002cdf4c7cb078ce/751x532cq70/ayam-kecap-untuk-mie-ayam-foto-resep-utama.jpg
author: Martin Mendez
ratingvalue: 4.9
reviewcount: 11
recipeingredient:
- "500 gram daging ayam potong dadu"
- "1 batang daun bawang iris me skip"
- " Bumbu Halus"
- "6 bh bawang merah"
- "4 bh bawang putih"
- "3 bh kemiri"
- "1/2 sdt ketumbar bubuk"
- "1/2 sdt merica bubuk"
- "17 ruas kunyit"
- " Bumbu Cemplung"
- "1 btg serai geprek"
- "1 ruas lengkuas geprek"
- "2 lbr daun salam"
- "3-4 lbr daun jeruk"
- "Secukupnya kecap manis"
- "50 ml air asam jawa"
- "Secukupnya garam dan kaldu bubuk"
- "400 ml air"
- " Minyak utk menumis"
recipeinstructions:
- "Siapkan ayam. Kucuri dengan jeruk nipis (me:jeruk cui) utk mengurangi amisnya lalu cuci kembali. (jangan salfok tulangnya ya, itu nnti utk kaldu kuah mie ayam hehe)"
- "Ulek semua bumbu halus, dan siapkan bumbu cemplung."
- "Tumis bumbu halus dengan sedikit minyak diwajan, lalu masukkan bumbu cemplung (serai, lengkuas, daun salam, dan daun jeruk) tumis hingga wangi."
- "Setelah itu masukkan ayam, aduk rata hingga ayam berubah warna. Masukkan air asam jawa, kecap manis, garam, dan kaldu bubuk. Lalu tuang air. Masak hingga air menyusut."
- "Tes rasa, bila sdh pas matikan kompor. Ayam kecap pun siap di sajikan utk pelengkap mie ayam..😍"
categories:
- Resep
tags:
- ayam
- kecap
- untuk

katakunci: ayam kecap untuk 
nutrition: 159 calories
recipecuisine: Indonesian
preptime: "PT21M"
cooktime: "PT39M"
recipeyield: "4"
recipecategory: Lunch

---


![Ayam Kecap (untuk mie ayam)](https://img-global.cpcdn.com/recipes/002cdf4c7cb078ce/751x532cq70/ayam-kecap-untuk-mie-ayam-foto-resep-utama.jpg)


ayam kecap (untuk mie ayam) ini merupakan santapan nusantara yang nikmat dan harus untuk kita coba. Cita rasanya yang mantap membuat siapa pun menantikan kehadirannya di meja makan.
Lagi mencari ide resep ayam kecap (untuk mie ayam) untuk jualan atau dikonsumsi sendiri yang Lezat? Cara Memasaknya memang tidak susah dan tidak juga mudah. Jika keliru mengolah maka hasilnya Tidak Memuaskan dan justru cenderung tidak enak. Padahal ayam kecap (untuk mie ayam) yang enak selayaknya punya aroma dan cita rasa yang mampu memancing selera kita.

Banyak hal yang sedikit banyak mempengaruhi kualitas rasa dari ayam kecap (untuk mie ayam), pertama dari jenis bahan, kemudian pemilihan bahan segar, hingga cara membuat dan menyajikannya. Tidak usah pusing kalau hendak menyiapkan ayam kecap (untuk mie ayam) enak di rumah, karena asal sudah tahu triknya maka hidangan ini mampu menjadi sajian istimewa.




Nah, kali ini kita coba, yuk, buat ayam kecap (untuk mie ayam) sendiri di rumah. Tetap dengan bahan sederhana, hidangan ini dapat memberi manfaat dalam membantu menjaga kesehatan tubuhmu sekeluarga. Anda bisa membuat Ayam Kecap (untuk mie ayam) memakai 19 jenis bahan dan 5 langkah pembuatan. Berikut ini langkah-langkah dalam membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam pembuatan Ayam Kecap (untuk mie ayam):

1. Siapkan 500 gram daging ayam (potong dadu)
1. Gunakan 1 batang daun bawang iris (me: skip)
1. Siapkan  Bumbu Halus:
1. Gunakan 6 bh bawang merah
1. Ambil 4 bh bawang putih
1. Siapkan 3 bh kemiri
1. Gunakan 1/2 sdt ketumbar bubuk
1. Sediakan 1/2 sdt merica bubuk
1. Ambil 17 ruas kunyit
1. Sediakan  Bumbu Cemplung:
1. Siapkan 1 btg serai geprek
1. Gunakan 1 ruas lengkuas geprek
1. Gunakan 2 lbr daun salam
1. Gunakan 3-4 lbr daun jeruk
1. Siapkan Secukupnya kecap manis
1. Siapkan 50 ml air asam jawa
1. Ambil Secukupnya garam dan kaldu bubuk
1. Gunakan 400 ml air
1. Ambil  Minyak utk menumis




<!--inarticleads2-->

##### Cara menyiapkan Ayam Kecap (untuk mie ayam):

1. Siapkan ayam. Kucuri dengan jeruk nipis (me:jeruk cui) utk mengurangi amisnya lalu cuci kembali. (jangan salfok tulangnya ya, itu nnti utk kaldu kuah mie ayam hehe)
1. Ulek semua bumbu halus, dan siapkan bumbu cemplung.
1. Tumis bumbu halus dengan sedikit minyak diwajan, lalu masukkan bumbu cemplung (serai, lengkuas, daun salam, dan daun jeruk) tumis hingga wangi.
1. Setelah itu masukkan ayam, aduk rata hingga ayam berubah warna. Masukkan air asam jawa, kecap manis, garam, dan kaldu bubuk. Lalu tuang air. Masak hingga air menyusut.
1. Tes rasa, bila sdh pas matikan kompor. Ayam kecap pun siap di sajikan utk pelengkap mie ayam..😍




Gimana nih? Gampang kan? Itulah cara menyiapkan ayam kecap (untuk mie ayam) yang bisa Anda praktikkan di rumah. Semoga bermanfaat dan selamat mencoba!
