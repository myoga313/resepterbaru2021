---
description: "Bahan Ayam Kecap | Cara Masak Ayam Kecap Yang Sedap"
title: "Bahan Ayam Kecap | Cara Masak Ayam Kecap Yang Sedap"
slug: 377-bahan-ayam-kecap-cara-masak-ayam-kecap-yang-sedap
date: 2020-12-29T17:10:35.052Z
image: https://img-global.cpcdn.com/recipes/616e72fc7985f489/751x532cq70/ayam-kecap-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/616e72fc7985f489/751x532cq70/ayam-kecap-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/616e72fc7985f489/751x532cq70/ayam-kecap-foto-resep-utama.jpg
author: Andre Foster
ratingvalue: 4.3
reviewcount: 13
recipeingredient:
- " ayam bagian paha"
- " bawang putih"
- " bawang merah karena gada bawang bombay jd aku ganti pakai ini"
- " merica bubuk"
- " air perasan jeruk nipis"
- " garam"
- " kaldu ayam bubuk"
- " saus tiram"
- " kecap manis"
- " air matang"
- " minyak goreng  margarin"
- " daun bawang"
- " kentang iris kotak"
recipeinstructions:
- "Siapkan ayam, cuci bersih laku lumuri dengan air perasan jeruk nipis dan bumbui sedikit garam merica, tunggu -+ 15 menit. potong kentang juga ya"
- "Angkat ayam dan tiriskan. lalu cincang bawang putih dan bawang merah. ambil sedikit minyak/margarin lalu tumis sampai harum"
- "Masukkan ayam, kentang, dan air. lalu bumbui dan tunggu sampai mendidih. jangan lupa koreksi rasa setelah itu ditunggu sampai air menyusut ya lalu siap dihidangkan beri taburan irisan daun bawang"
categories:
- Resep
tags:
- ayam
- kecap

katakunci: ayam kecap 
nutrition: 260 calories
recipecuisine: Indonesian
preptime: "PT40M"
cooktime: "PT59M"
recipeyield: "2"
recipecategory: Dessert

---


![Ayam Kecap](https://img-global.cpcdn.com/recipes/616e72fc7985f489/751x532cq70/ayam-kecap-foto-resep-utama.jpg)


ayam kecap ini ialah kuliner nusantara yang nikmat dan perlu untuk kita coba. Cita rasanya yang lezat membuat siapa pun menantikan kehadirannya di meja makan.
Sedang mencari ide resep ayam kecap untuk jualan atau dikonsumsi sendiri yang Sedap? Cara menyiapkannya memang susah-susah gampang. apabila keliru mengolah maka hasilnya tidak akan memuaskan dan justru cenderung tidak enak. Padahal ayam kecap yang enak selayaknya mempunyai aroma dan rasa yang dapat memancing selera kita.



Banyak hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari ayam kecap, mulai dari jenis bahan, lalu pemilihan bahan segar sampai cara mengolah dan menyajikannya. Tidak usah pusing jika mau menyiapkan ayam kecap yang enak di rumah, karena asal sudah tahu triknya maka hidangan ini bisa jadi sajian istimewa.


Nah, kali ini kita coba, yuk, siapkan ayam kecap sendiri di rumah. Tetap berbahan yang sederhana, hidangan ini bisa memberi manfaat untuk membantu menjaga kesehatan tubuh kita. Anda dapat menyiapkan Ayam Kecap menggunakan 13 jenis bahan dan 3 tahap pembuatan. Berikut ini langkah-langkah dalam membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk menyiapkan Ayam Kecap:

1. Ambil  ayam bagian paha
1. Gunakan  bawang putih
1. Gunakan  bawang merah, karena gada bawang bombay jd aku ganti pakai ini
1. Ambil  merica bubuk
1. Ambil  air perasan jeruk nipis
1. Ambil  garam
1. Sediakan  kaldu ayam bubuk
1. Ambil  saus tiram
1. Gunakan  kecap manis
1. Siapkan  air matang
1. Gunakan  minyak goreng / margarin
1. Siapkan  daun bawang
1. Gunakan  kentang, iris kotak




<!--inarticleads2-->

##### Cara membuat Ayam Kecap:

1. Siapkan ayam, cuci bersih laku lumuri dengan air perasan jeruk nipis dan bumbui sedikit garam merica, tunggu -+ 15 menit. potong kentang juga ya
1. Angkat ayam dan tiriskan. lalu cincang bawang putih dan bawang merah. ambil sedikit minyak/margarin lalu tumis sampai harum
1. Masukkan ayam, kentang, dan air. lalu bumbui dan tunggu sampai mendidih. jangan lupa koreksi rasa setelah itu ditunggu sampai air menyusut ya lalu siap dihidangkan beri taburan irisan daun bawang




Terima kasih telah membaca resep yang kami tampilkan di halaman ini. Besar harapan kami, olahan Ayam Kecap yang mudah di atas dapat membantu Anda menyiapkan hidangan yang menarik untuk keluarga/teman ataupun menjadi inspirasi bagi Anda yang berkeinginan untuk berjualan makanan. Selamat mencoba!
