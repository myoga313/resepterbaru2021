---
description: "Olahan Ayam goreng lengkuas | Resep Membuat Ayam goreng lengkuas Yang Menggugah Selera"
title: "Olahan Ayam goreng lengkuas | Resep Membuat Ayam goreng lengkuas Yang Menggugah Selera"
slug: 247-olahan-ayam-goreng-lengkuas-resep-membuat-ayam-goreng-lengkuas-yang-menggugah-selera
date: 2020-11-26T07:09:12.288Z
image: https://img-global.cpcdn.com/recipes/721067b06014b2aa/751x532cq70/ayam-goreng-lengkuas-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/721067b06014b2aa/751x532cq70/ayam-goreng-lengkuas-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/721067b06014b2aa/751x532cq70/ayam-goreng-lengkuas-foto-resep-utama.jpg
author: Amanda Aguilar
ratingvalue: 3.3
reviewcount: 8
recipeingredient:
- " ayam potong2 jadi 10"
- " lengkuas pilih yang gak keras 5bj seukuran jari"
- " bumbu halus"
- " bawang putih"
- " garam"
- " kunyit"
recipeinstructions:
- "Bersihkan ayam"
- "Parut lengkuas"
- "Haluskan bumbu halus"
- "Campur ayam dan bumbu halus beserta lengkuas parut kasih air secukupnya"
- "Ungkep ayam yg sudah dicampur bumbu sampai air menyusut"
- "Koreksi rasa"
- "Setelah menyusut airnya, matikan kompor"
- "Goreng ayam beserta bumbunya"
- "Siap disajikan"
categories:
- Resep
tags:
- ayam
- goreng
- lengkuas

katakunci: ayam goreng lengkuas 
nutrition: 213 calories
recipecuisine: Indonesian
preptime: "PT40M"
cooktime: "PT36M"
recipeyield: "2"
recipecategory: Dessert

---


![Ayam goreng lengkuas](https://img-global.cpcdn.com/recipes/721067b06014b2aa/751x532cq70/ayam-goreng-lengkuas-foto-resep-utama.jpg)


ayam goreng lengkuas ini yaitu makanan nusantara yang istimewa dan wajib untuk kita coba. Cita rasanya yang mantap membuat siapa pun menantikan kehadirannya di meja makan.
Lagi mencari ide resep ayam goreng lengkuas untuk jualan atau dikonsumsi sendiri yang Bisa Manjain Lidah? Cara Buatnya memang tidak susah dan tidak juga mudah. Jika salah mengolah maka hasilnya Tidak Memuaskan dan justru cenderung tidak enak. Padahal ayam goreng lengkuas yang enak seharusnya mempunyai aroma dan cita rasa yang dapat memancing selera kita.

Ada beberapa hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari ayam goreng lengkuas, mulai dari jenis bahan, selanjutnya pemilihan bahan segar, hingga cara membuat dan menyajikannya. Tidak usah pusing kalau ingin menyiapkan ayam goreng lengkuas yang enak di rumah, karena asal sudah tahu triknya maka hidangan ini bisa jadi suguhan spesial.




Nah, kali ini kita coba, yuk, buat ayam goreng lengkuas sendiri di rumah. Tetap dengan bahan sederhana, sajian ini bisa memberi manfaat dalam membantu menjaga kesehatan tubuh kita. Anda dapat membuat Ayam goreng lengkuas menggunakan 6 jenis bahan dan 9 langkah pembuatan. Berikut ini langkah-langkah untuk menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk pembuatan Ayam goreng lengkuas:

1. Ambil  ayam potong2 jadi 10
1. Siapkan  lengkuas pilih yang gak keras 5bj seukuran jari
1. Ambil  bumbu halus
1. Siapkan  bawang putih
1. Ambil  garam
1. Siapkan  kunyit




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Ayam goreng lengkuas:

1. Bersihkan ayam
1. Parut lengkuas
1. Haluskan bumbu halus
1. Campur ayam dan bumbu halus beserta lengkuas parut kasih air secukupnya
1. Ungkep ayam yg sudah dicampur bumbu sampai air menyusut
1. Koreksi rasa
1. Setelah menyusut airnya, matikan kompor
1. Goreng ayam beserta bumbunya
1. Siap disajikan




Gimana nih? Mudah bukan? Itulah cara menyiapkan ayam goreng lengkuas yang bisa Anda lakukan di rumah. Semoga bermanfaat dan selamat mencoba!
