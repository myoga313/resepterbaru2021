---
description: "Resep Donat Kentang Jadul Gimpil | Resep Membuat Donat Kentang Jadul Gimpil Yang Bikin Ngiler"
title: "Resep Donat Kentang Jadul Gimpil | Resep Membuat Donat Kentang Jadul Gimpil Yang Bikin Ngiler"
slug: 179-resep-donat-kentang-jadul-gimpil-resep-membuat-donat-kentang-jadul-gimpil-yang-bikin-ngiler
date: 2020-08-06T06:32:46.246Z
image: https://img-global.cpcdn.com/recipes/2a962f296ab088b1/751x532cq70/donat-kentang-jadul-gimpil-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/2a962f296ab088b1/751x532cq70/donat-kentang-jadul-gimpil-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/2a962f296ab088b1/751x532cq70/donat-kentang-jadul-gimpil-foto-resep-utama.jpg
author: Victor Fernandez
ratingvalue: 4
reviewcount: 8
recipeingredient:
- "1/2 kg kentang"
- "1/2 kg tepung terigu"
- "3 sdm fiber creme atau susu bubuk optional"
- "1 sdt garam"
- "2 sdm gula pasir"
- "1 bungkus ragi fermipan"
- "sedikit Air bisa diganti susu cair jika tidak menggunakan susu bubuk"
- " Topping bebas saya pake gula halus"
- "1 sdm margarin"
recipeinstructions:
- "Kukus kentang, haluskan."
- "Campur semua bahan kering, masukan kentang halus, ratakan."
- "Masukan mentega cair, ulenin. Tambahkan air sedikit demi sedikit, sampai adonan kalis."
- "Diamkan adonan 1/2 jam hingga mengembang."
- "Bagi adonan (saya 70gr) bulatkan, diamkan lagi 1/2 jam."
- "Siapkan minyak, panaskan. Goreng donat yg sudah dibentuk dengan api sedang-kecil. Jangan dibolakbalik. Tunggu sampe sisi bawah keemasan, lalu balik sekali saja. Angkat jika sudah berwarna keemasan."
- "Taburi dengan topping."
- "Untuk simpan di frezer, cukup goreng donat setengah matang."
categories:
- Resep
tags:
- donat
- kentang
- jadul

katakunci: donat kentang jadul 
nutrition: 249 calories
recipecuisine: Indonesian
preptime: "PT16M"
cooktime: "PT52M"
recipeyield: "1"
recipecategory: Dinner

---


![Donat Kentang Jadul Gimpil](https://img-global.cpcdn.com/recipes/2a962f296ab088b1/751x532cq70/donat-kentang-jadul-gimpil-foto-resep-utama.jpg)


donat kentang jadul gimpil ini yaitu hidangan tanah air yang khas dan wajib untuk kita coba. Cita rasanya yang enak membuat siapa pun menantikan kehadirannya di meja makan.
Bunda lagi mencari ide resep donat kentang jadul gimpil untuk jualan atau dikonsumsi sendiri yang Enak Banget? Cara membuatnya memang tidak susah dan tidak juga mudah. jikalau keliru mengolah maka hasilnya tidak akan memuaskan dan bahkan tidak sedap. Padahal donat kentang jadul gimpil yang enak seharusnya memiliki aroma dan cita rasa yang mampu memancing selera kita.

Ada beberapa hal yang sedikit banyak mempengaruhi kualitas rasa dari donat kentang jadul gimpil, pertama dari jenis bahan, lalu pemilihan bahan segar, hingga cara membuat dan menghidangkannya. Tidak usah pusing jika hendak menyiapkan donat kentang jadul gimpil yang enak di rumah, karena asal sudah tahu triknya maka hidangan ini bisa jadi suguhan spesial.




Di bawah ini ada beberapa tips dan trik praktis yang dapat diterapkan untuk mengolah donat kentang jadul gimpil yang siap dikreasikan. Anda dapat membuat Donat Kentang Jadul Gimpil menggunakan 9 bahan dan 8 tahap pembuatan. Berikut ini cara dalam membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk menyiapkan Donat Kentang Jadul Gimpil:

1. Gunakan 1/2 kg kentang
1. Gunakan 1/2 kg tepung terigu
1. Sediakan 3 sdm fiber creme atau susu bubuk (optional)
1. Siapkan 1 sdt garam
1. Ambil 2 sdm gula pasir
1. Ambil 1 bungkus ragi fermipan
1. Siapkan sedikit Air (bisa diganti susu cair jika tidak menggunakan susu bubuk)
1. Sediakan  Topping bebas, saya pake gula halus
1. Ambil 1 sdm margarin




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Donat Kentang Jadul Gimpil:

1. Kukus kentang, haluskan.
1. Campur semua bahan kering, masukan kentang halus, ratakan.
1. Masukan mentega cair, ulenin. Tambahkan air sedikit demi sedikit, sampai adonan kalis.
1. Diamkan adonan 1/2 jam hingga mengembang.
1. Bagi adonan (saya 70gr) bulatkan, diamkan lagi 1/2 jam.
1. Siapkan minyak, panaskan. Goreng donat yg sudah dibentuk dengan api sedang-kecil. Jangan dibolakbalik. Tunggu sampe sisi bawah keemasan, lalu balik sekali saja. Angkat jika sudah berwarna keemasan.
1. Taburi dengan topping.
1. Untuk simpan di frezer, cukup goreng donat setengah matang.




Gimana nih? Mudah bukan? Itulah cara menyiapkan donat kentang jadul gimpil yang bisa Anda lakukan di rumah. Selamat mencoba!
