---
description: "Resep masakan Donat Kentang🍩🥔 | Bahan Membuat Donat Kentang🍩🥔 Yang Bisa Manjain Lidah"
title: "Resep masakan Donat Kentang🍩🥔 | Bahan Membuat Donat Kentang🍩🥔 Yang Bisa Manjain Lidah"
slug: 197-resep-masakan-donat-kentang-bahan-membuat-donat-kentang-yang-bisa-manjain-lidah
date: 2020-12-17T08:48:12.820Z
image: https://img-global.cpcdn.com/recipes/082d2a38c6438d63/751x532cq70/donat-kentang🍩🥔-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/082d2a38c6438d63/751x532cq70/donat-kentang🍩🥔-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/082d2a38c6438d63/751x532cq70/donat-kentang🍩🥔-foto-resep-utama.jpg
author: Lola Maldonado
ratingvalue: 4.5
reviewcount: 14
recipeingredient:
- " terigu pro tinggi"
- " gula pasir"
- " telur"
- " kentang rebus"
- " ragi"
- " air"
- " garam"
- " Bread Improver"
- " mentega putih"
recipeinstructions:
- "Siapkan bahan2 :"
- "Rebus kentang lalu haluskan."
- "Siapkan wadah, lalu campurkan terigu + garam + Bread Improver. Aduk rata dgn spatula."
- "Di tempat lain campurkan air + gula pasir + ragi. Aduk rata."
- "Campurkan larutan ragi ke dalam campuran terigu. Lalu masukkan kentang halus yg sdh dicampurkan dgn telur, aduk rata lalu tuang ke dalam campuran terigu. Setelah itu masukkan mentega putih dan aduk dgn ✋ ya. Uleni sebentar aja sampe tercampur rata."
- ""
- "Timbang adonan lalu bagi2 adonan. Aq bagi masing2 30gr. Setelah itu bulatkan adonan dan di proofing selama 30 menit. Setelah itu pipihkan adonan pelan2 dan lubangi adonan di bagian tengah. Bs dgn menggunakan spuit. Jgn lupa taburi terigu biar gak lengket ya."
- ""
- "Adonan siap untuk di goreng dgn🔥 yg kecil aja dan sekali balik aja. Adonan yg kecilnya di goreng jg ya."
- "Setelah donat mulai dingin, siapkan topping sesuai selera. Aq pake meses dgn lapisan coklat glaze dan gula halus."
- ""
- "Ini dia hasilnya....donatnya lembut banget dan enak buat teman ngeteh😁 jadinya lumayan bny ada 19 biji di tambah yg kecilnya....wahh puas dech makannya dr pada di beli....🤭🤗"
categories:
- Resep
tags:
- donat
- kentang

katakunci: donat kentang 
nutrition: 294 calories
recipecuisine: Indonesian
preptime: "PT10M"
cooktime: "PT36M"
recipeyield: "3"
recipecategory: Dessert

---


![Donat Kentang🍩🥔](https://img-global.cpcdn.com/recipes/082d2a38c6438d63/751x532cq70/donat-kentang🍩🥔-foto-resep-utama.jpg)


donat kentang🍩🥔 ini merupakan suguhan nusantara yang enak dan wajib untuk kita coba. Cita rasanya yang lezat membuat siapa pun menantikan kehadirannya di meja makan.
Bunda lagi mencari inspirasi resep donat kentang🍩🥔 untuk jualan atau dikonsumsi sendiri yang Bikin Ngiler? Cara Buatnya memang susah-susah gampang. jikalau keliru mengolah maka hasilnya Tidak Memuaskan dan bahkan tidak sedap. Padahal donat kentang🍩🥔 yang enak seharusnya mempunyai aroma dan rasa yang mampu memancing selera kita.

Banyak hal yang sedikit banyak mempengaruhi kualitas rasa dari donat kentang🍩🥔, pertama dari jenis bahan, selanjutnya pemilihan bahan segar, hingga cara mengolah dan menyajikannya. Tidak usah pusing kalau mau menyiapkan donat kentang🍩🥔 yang enak di rumah, karena asal sudah tahu triknya maka hidangan ini mampu jadi sajian istimewa.

Resep Donat Kentang - Donat (doughnuts atau donat) merupakan salah satu roti yang proses pembuatannya dengan cara digoreng. Terbuat dari adonan yang terdiri dari tepung terigu, gula, mentega, dan telur kemudian dicampur rata, di uleni, lalu dibentuk bulat dengan ciri khas lubang di. Siapa sangka, donat kentang menjadi primadona d itengah-tengah masyarakat pecinta donat.


Nah, kali ini kita coba, yuk, variasikan donat kentang🍩🥔 sendiri di rumah. Tetap dengan bahan sederhana, hidangan ini dapat memberi manfaat untuk membantu menjaga kesehatan tubuhmu sekeluarga. Anda bisa membuat Donat Kentang🍩🥔 memakai 9 bahan dan 12 langkah pembuatan. Berikut ini cara dalam membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk menyiapkan Donat Kentang🍩🥔:

1. Sediakan  terigu pro tinggi
1. Gunakan  gula pasir
1. Sediakan  telur
1. Sediakan  kentang rebus
1. Sediakan  ragi
1. Ambil  air
1. Gunakan  garam
1. Gunakan  Bread Improver
1. Gunakan  mentega putih


Gimana sih cara membuat donat kentang yang super enak dan Ya, donat kentang original adalah donat yang di buat dari bahan dasar kentang tanpa adanya tambahan apapun termasuk pada topping. Cara Membuat Donat Kentang - Peluang usaha donat kentang ini cukup bagus, mengingat banyaknya orang yang suka dengan cemilan yang satu ini. Lihat juga resep Donat tepung kentang enak lainnya. Donat adalah makanan yang sangat hype saat ini. 

<!--inarticleads2-->

##### Cara menyiapkan Donat Kentang🍩🥔:

1. Siapkan bahan2 :
1. Rebus kentang lalu haluskan.
1. Siapkan wadah, lalu campurkan terigu + garam + Bread Improver. Aduk rata dgn spatula.
1. Di tempat lain campurkan air + gula pasir + ragi. Aduk rata.
1. Campurkan larutan ragi ke dalam campuran terigu. Lalu masukkan kentang halus yg sdh dicampurkan dgn telur, aduk rata lalu tuang ke dalam campuran terigu. Setelah itu masukkan mentega putih dan aduk dgn ✋ ya. Uleni sebentar aja sampe tercampur rata.
1. 
1. Timbang adonan lalu bagi2 adonan. Aq bagi masing2 30gr. Setelah itu bulatkan adonan dan di proofing selama 30 menit. Setelah itu pipihkan adonan pelan2 dan lubangi adonan di bagian tengah. Bs dgn menggunakan spuit. Jgn lupa taburi terigu biar gak lengket ya.
1. 
1. Adonan siap untuk di goreng dgn🔥 yg kecil aja dan sekali balik aja. Adonan yg kecilnya di goreng jg ya.
1. Setelah donat mulai dingin, siapkan topping sesuai selera. Aq pake meses dgn lapisan coklat glaze dan gula halus.
1. 
1. Ini dia hasilnya....donatnya lembut banget dan enak buat teman ngeteh😁 jadinya lumayan bny ada 19 biji di tambah yg kecilnya....wahh puas dech makannya dr pada di beli....🤭🤗


Donat menjadi salah satu makanan favorite masyarakat Indonesia. Disini saya membuat donat dengan menggunakan inovari yang baru, yaitu disini saya menambahkan kentang kedalam adonan donat. Jajanan donat sederhana, enak, empuk, lembut, dan praktis untuk jualan. Cara buat kue donat kentang sebenarnya tidak jauh berbeda dengan resep kue donat biasa, namun ada beberapa perbedaan terutama pada cara membuatnya dan bahan bahan yang digunakan. Selain itu, donat kentang juga lebih bergizi karena mengandung tambahan kentang yang banyak manfaatnya. 

Bagaimana? Gampang kan? Itulah cara membuat donat kentang🍩🥔 yang bisa Anda lakukan di rumah. Selamat mencoba!
