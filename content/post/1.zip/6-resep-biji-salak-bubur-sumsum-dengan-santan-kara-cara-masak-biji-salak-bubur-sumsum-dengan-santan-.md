---
description: "Resep Biji salak bubur sumsum dengan santan Kara | Cara Masak Biji salak bubur sumsum dengan santan Kara Yang Enak Banget"
title: "Resep Biji salak bubur sumsum dengan santan Kara | Cara Masak Biji salak bubur sumsum dengan santan Kara Yang Enak Banget"
slug: 6-resep-biji-salak-bubur-sumsum-dengan-santan-kara-cara-masak-biji-salak-bubur-sumsum-dengan-santan-kara-yang-enak-banget
date: 2021-01-25T16:39:21.114Z
image: https://img-global.cpcdn.com/recipes/8d1e0a51cfdca52b/751x532cq70/biji-salak-bubur-sumsum-dengan-santan-kara-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/8d1e0a51cfdca52b/751x532cq70/biji-salak-bubur-sumsum-dengan-santan-kara-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/8d1e0a51cfdca52b/751x532cq70/biji-salak-bubur-sumsum-dengan-santan-kara-foto-resep-utama.jpg
author: Jonathan Stevens
ratingvalue: 4.7
reviewcount: 4
recipeingredient:
- " Bubur Sumsum "
- "100 gr tepung beras"
- "900 ml air 50ml santan instan dicampur aduk rata"
- " saya pakai merk Kara"
- "1/2 sdt garam"
- "2 lbr daun pandan"
- "Biji Salak"
- "250 gr Ubi oranye"
- "50 gr tepung sagukanji"
- "700 ml air untuk merebus biji salak"
- " Kuah Kinca"
- "200 gr gula merah"
- "1 sdm gula pasir"
- "2 lbr daun pandan"
- "1 sdm tepung sagukanji larutkan dgn 50ml air"
recipeinstructions:
- "Bubur Sumsum : bagi dua santan. campur rata tepung beras dgn sebagian santan. sisihkan."
- "Masak sisa santan lainnya dgn garam dan daun pandan sampai mendidih, lalu kecilkan apinya. masukkan larutan tepung beras, aduk terus sampai kental dan meletup letup. test rasa, (cukup test rasa asinnya saja, manisnya nanti dr kuah kinca, kalau saya suka agak asin jadi saya tambahkan sekitar 1/2sdt garam lagi.)"
- "Biji Salak : kupas ubi, cuci bersih, lalu kukus sampai matang."
- "Haluskan ubi, bisa dengan diulek/ditumbuk halus/gunakan food processor (paling bagus pakai food processor krn hasilnya halus tanpa serabut serat ubi, tapi memakai ulekan juga ok kok, jangan memakai blender yah, krn kalau pakai blender hrs dicampur air spy blender bisa jalan, kalo dicampur air tekstur dijamin rusak. Saya pernah coba dan beneran rusak T.T). Lalu campur ubi yg sdh dihaluskan dgn tepung sagu, uleni sampai kalis dan bisa dipulung. buat jadi bola bola kecil seukurn biji salak."
- "Masak air yg 700ml sampai mendidih. masukkan bola bola salak sampai matang dan mengapung. angkat dan tiriskan."
- "Tambahkan daun pandan, gula merah pada air rebusan sisa biji salak tadi, rebus sampai daun pandan harum dan semua gula merah meleleh tercampur rata. tambahkan larutan tepung sagu. masak kembali sampai mendidih. test rasa dan kekentalan (buat rasa agak manis dikit krn kuah kinca ini nanti akan memaniskan bubur sumsum) kalau kurang kental tambahkan larutan tepung tapioka. setelah pas semua baru tambahkan biji salak biarkan sekitar 3mnt. matikan."
- "Ambil bubur sumsum, tambahkan biji salak dan kuah kinca. sajikan... hangat enak dingin juga enak. (kalau saya lbh suka dlm keadaan dingin, sy masukkan kulkas bsknya mkn lbh enak lagi hehehe)"
categories:
- Resep
tags:
- biji
- salak
- bubur

katakunci: biji salak bubur 
nutrition: 118 calories
recipecuisine: Indonesian
preptime: "PT40M"
cooktime: "PT47M"
recipeyield: "1"
recipecategory: Lunch

---


![Biji salak bubur sumsum dengan santan Kara](https://img-global.cpcdn.com/recipes/8d1e0a51cfdca52b/751x532cq70/biji-salak-bubur-sumsum-dengan-santan-kara-foto-resep-utama.jpg)


biji salak bubur sumsum dengan santan kara ini ialah hidangan nusantara yang unik dan harus untuk kita coba. Cita rasanya yang mantap membuat siapa pun menantikan kehadirannya di meja makan.
Kamu Lagi mencari ide resep biji salak bubur sumsum dengan santan kara untuk jualan atau dikonsumsi sendiri yang Enak dan Simpel? Cara Buatnya memang tidak terlalu sulit namun tidak gampang juga. apabila salah mengolah maka hasilnya tidak akan memuaskan dan justru cenderung tidak enak. Padahal biji salak bubur sumsum dengan santan kara yang enak harusnya sih memiliki aroma dan rasa yang mampu memancing selera kita.

Banyak hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari biji salak bubur sumsum dengan santan kara, mulai dari jenis bahan, lalu pemilihan bahan segar, hingga cara mengolah dan menghidangkannya. Tidak usah pusing jika ingin menyiapkan biji salak bubur sumsum dengan santan kara yang enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini bisa jadi suguhan spesial.

#dirumahaja #takjil #santankara Hai, teman-teman semua. Hari ini aku mau bikin Bubur Sumsum Sutera &amp; Biji Salak Ubi Ungu. Resep Bubur Candil Ubi Ungu Biji Salak Ubi Ungu Takjil Buka Puasa.


Nah, kali ini kita coba, yuk, variasikan biji salak bubur sumsum dengan santan kara sendiri di rumah. Tetap dengan bahan yang sederhana, hidangan ini dapat memberi manfaat dalam membantu menjaga kesehatan tubuhmu sekeluarga. Anda bisa membuat Biji salak bubur sumsum dengan santan Kara memakai 15 bahan dan 7 langkah pembuatan. Berikut ini langkah-langkah dalam menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam menyiapkan Biji salak bubur sumsum dengan santan Kara:

1. Siapkan  Bubur Sumsum :
1. Siapkan 100 gr tepung beras
1. Gunakan 900 ml air +50ml santan instan dicampur aduk rata
1. Sediakan  (saya pakai merk Kara)
1. Siapkan 1/2 sdt garam
1. Sediakan 2 lbr daun pandan
1. Sediakan Biji Salak:
1. Siapkan 250 gr Ubi oranye
1. Ambil 50 gr tepung sagu/kanji
1. Gunakan 700 ml air untuk merebus biji salak
1. Ambil  Kuah Kinca:
1. Ambil 200 gr gula merah
1. Ambil 1 sdm gula pasir
1. Gunakan 2 lbr daun pandan
1. Gunakan 1 sdm tepung sagu/kanji larutkan dgn 50ml air


Dari masa kecil hingga sekarang selalu kangen dengan kudapan yang satu ini, tekstur yang lembut. Blender pandan dengan air, kemudian saring. Masukkan panci bersama tepung beras, garam, santan kara. Masukkan panci bersama tepung beras, garam, santan kara. 

<!--inarticleads2-->

##### Cara membuat Biji salak bubur sumsum dengan santan Kara:

1. Bubur Sumsum : bagi dua santan. campur rata tepung beras dgn sebagian santan. sisihkan.
1. Masak sisa santan lainnya dgn garam dan daun pandan sampai mendidih, lalu kecilkan apinya. masukkan larutan tepung beras, aduk terus sampai kental dan meletup letup. test rasa, (cukup test rasa asinnya saja, manisnya nanti dr kuah kinca, kalau saya suka agak asin jadi saya tambahkan sekitar 1/2sdt garam lagi.)
1. Biji Salak : kupas ubi, cuci bersih, lalu kukus sampai matang.
1. Haluskan ubi, bisa dengan diulek/ditumbuk halus/gunakan food processor (paling bagus pakai food processor krn hasilnya halus tanpa serabut serat ubi, tapi memakai ulekan juga ok kok, jangan memakai blender yah, krn kalau pakai blender hrs dicampur air spy blender bisa jalan, kalo dicampur air tekstur dijamin rusak. Saya pernah coba dan beneran rusak T.T). Lalu campur ubi yg sdh dihaluskan dgn tepung sagu, uleni sampai kalis dan bisa dipulung. buat jadi bola bola kecil seukurn biji salak.
1. Masak air yg 700ml sampai mendidih. masukkan bola bola salak sampai matang dan mengapung. angkat dan tiriskan.
1. Tambahkan daun pandan, gula merah pada air rebusan sisa biji salak tadi, rebus sampai daun pandan harum dan semua gula merah meleleh tercampur rata. tambahkan larutan tepung sagu. masak kembali sampai mendidih. test rasa dan kekentalan (buat rasa agak manis dikit krn kuah kinca ini nanti akan memaniskan bubur sumsum) kalau kurang kental tambahkan larutan tepung tapioka. setelah pas semua baru tambahkan biji salak biarkan sekitar 3mnt. matikan.
1. Ambil bubur sumsum, tambahkan biji salak dan kuah kinca. sajikan... hangat enak dingin juga enak. (kalau saya lbh suka dlm keadaan dingin, sy masukkan kulkas bsknya mkn lbh enak lagi hehehe)


Bubur sumsum hijau kinca durian siap dihidangkan. Bubur sumsum merupakan makanan sejenis bubur berwarna putih yang terbuat dari tepung beras yang disajikan bersama air gula merah. Teksturnya yang lembut dan gurih begitu cocok untuk dikonsumsi bersama dengan wanginya santan dan manisnya gula merah yang dicairkan. Ini dia tips sukses bikin bubur sumsum pakai santan kara. Dijamin pasti berhasil dan tidak menggumpal kalau pakai trik ini. 

Bagaimana? Mudah bukan? Itulah cara menyiapkan biji salak bubur sumsum dengan santan kara yang bisa Anda lakukan di rumah. Selamat mencoba!
