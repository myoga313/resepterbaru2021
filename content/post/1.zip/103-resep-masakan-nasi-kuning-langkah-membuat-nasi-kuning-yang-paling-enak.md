---
description: "Resep masakan Nasi Kuning | Langkah Membuat Nasi Kuning Yang Paling Enak"
title: "Resep masakan Nasi Kuning | Langkah Membuat Nasi Kuning Yang Paling Enak"
slug: 103-resep-masakan-nasi-kuning-langkah-membuat-nasi-kuning-yang-paling-enak
date: 2020-11-15T22:33:23.802Z
image: https://img-global.cpcdn.com/recipes/7c947f033d78daaa/751x532cq70/nasi-kuning-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/7c947f033d78daaa/751x532cq70/nasi-kuning-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/7c947f033d78daaa/751x532cq70/nasi-kuning-foto-resep-utama.jpg
author: Vincent Graham
ratingvalue: 4.8
reviewcount: 5
recipeingredient:
- "2 cup beras"
- "3 ruas kunyit"
- "4 sdm santan instan"
- "2 siung bawang putih"
- "2 lembar daun jeruk"
- "4 lembar daun salam"
- "2 batang serai"
- "secukupnya Garam"
recipeinstructions:
- "Cuci beras hingga bersih, sisihkan."
- "Kupas kunyit, lalu bakar agar tidak bau langu. Setelah dibakar, blender kunyit dengan sedikit air."
- "Cincang halus bawang putih, lalu tumis dengan sedikit minyak hingga matang dan harum."
- "Saring kunyit yang telah diblender, kemudian tambahkan ke dalam tumisan bawang. Tambahkan air, lalu masukkan daun jeruk, daun salam, serai dan sedikit garam."
- "Setelah air mendidih, masukkan santan kental. Lalu tuang ke dalam panci yang berisi beras yang sudah dicuci. Masak hingga air menyusut."
- "Setelah air menyusut, kukus nasi dengan dandang hingga matang."
- "Sajikan dengan lauk pelengkap."
categories:
- Resep
tags:
- nasi
- kuning

katakunci: nasi kuning 
nutrition: 133 calories
recipecuisine: Indonesian
preptime: "PT28M"
cooktime: "PT52M"
recipeyield: "4"
recipecategory: Dessert

---


![Nasi Kuning](https://img-global.cpcdn.com/recipes/7c947f033d78daaa/751x532cq70/nasi-kuning-foto-resep-utama.jpg)


nasi kuning ini yakni sajian nusantara yang ekslusif dan perlu untuk kita coba. Cita rasanya yang mantap membuat siapa pun menantikan kehadirannya di meja makan.
Anda sedang mencari ide resep nasi kuning untuk jualan atau dikonsumsi sendiri yang Lezat? Cara menyiapkannya memang tidak terlalu sulit namun tidak gampang juga. bila salah mengolah maka hasilnya tidak akan memuaskan dan justru cenderung tidak enak. Padahal nasi kuning yang enak selayaknya memiliki aroma dan cita rasa yang dapat memancing selera kita.

Ada beberapa hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari nasi kuning, pertama dari jenis bahan, selanjutnya pemilihan bahan segar, hingga cara mengolah dan menyajikannya. Tak perlu pusing jika hendak menyiapkan nasi kuning enak di rumah, karena asal sudah tahu triknya maka hidangan ini mampu menjadi sajian istimewa.




Nah, kali ini kita coba, yuk, siapkan nasi kuning sendiri di rumah. Tetap dengan bahan sederhana, sajian ini bisa memberi manfaat dalam membantu menjaga kesehatan tubuh kita. Anda bisa membuat Nasi Kuning menggunakan 8 jenis bahan dan 7 langkah pembuatan. Berikut ini langkah-langkah untuk menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk menyiapkan Nasi Kuning:

1. Ambil 2 cup beras
1. Gunakan 3 ruas kunyit
1. Sediakan 4 sdm santan instan
1. Ambil 2 siung bawang putih
1. Siapkan 2 lembar daun jeruk
1. Ambil 4 lembar daun salam
1. Siapkan 2 batang serai
1. Gunakan secukupnya Garam




<!--inarticleads2-->

##### Cara membuat Nasi Kuning:

1. Cuci beras hingga bersih, sisihkan.
1. Kupas kunyit, lalu bakar agar tidak bau langu. Setelah dibakar, blender kunyit dengan sedikit air.
1. Cincang halus bawang putih, lalu tumis dengan sedikit minyak hingga matang dan harum.
1. Saring kunyit yang telah diblender, kemudian tambahkan ke dalam tumisan bawang. Tambahkan air, lalu masukkan daun jeruk, daun salam, serai dan sedikit garam.
1. Setelah air mendidih, masukkan santan kental. Lalu tuang ke dalam panci yang berisi beras yang sudah dicuci. Masak hingga air menyusut.
1. Setelah air menyusut, kukus nasi dengan dandang hingga matang.
1. Sajikan dengan lauk pelengkap.




Terima kasih telah membaca resep yang kami tampilkan di halaman ini. Harapan kami, olahan Nasi Kuning yang mudah di atas dapat membantu Anda menyiapkan hidangan yang enak untuk keluarga/teman maupun menjadi inspirasi dalam berjualan makanan. Selamat mencoba!
