---
description: "Bumbu Seblak Simple Polmantul | Cara Bikin Seblak Simple Polmantul Yang Lezat Sekali"
title: "Bumbu Seblak Simple Polmantul | Cara Bikin Seblak Simple Polmantul Yang Lezat Sekali"
slug: 316-bumbu-seblak-simple-polmantul-cara-bikin-seblak-simple-polmantul-yang-lezat-sekali
date: 2020-12-21T22:17:39.267Z
image: https://img-global.cpcdn.com/recipes/1bb7b2005571ae2b/751x532cq70/seblak-simple-polmantul-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/1bb7b2005571ae2b/751x532cq70/seblak-simple-polmantul-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/1bb7b2005571ae2b/751x532cq70/seblak-simple-polmantul-foto-resep-utama.jpg
author: Emma Morgan
ratingvalue: 4.4
reviewcount: 6
recipeingredient:
- "100 gr kerupuk udang"
- "100 gr makaroni usus"
- "1 ikat sawi dipotong panjang"
- "1 buah mentimun diiris tipis"
- "50 gr kol diiris tipis"
- "1 buah tomat"
- "250 ml air"
- "Secukupnya minyak"
- "Secukupnya penyedap rasa"
- "Secukupnya gula"
- "2 tangkai seledri diiris tipis"
- " Bumbu"
- "4 buah cabai merah"
- "4 buah cabai rawit"
- "3 siung bawang merah"
- "2 siung bawang putih"
- "1 ruas kencur"
- "Secukupnya garam"
recipeinstructions:
- "Rebus makaroni dan kerupuk dalam air yang mendidih sampai mengembang dan teksturnya agak lunak. Jangan lupa beri sedikit minyak, agar makaroni dan kerupuknya tidak saling menempel. Lalu, tiriskan."
- "Haluskan bumbu."
- "Panaskan minyak dalam wajan. Lalu sangrai bumbu hingga harum."
- "Tambahkan air. Tunggu hingga mendidih."
- "Masukkan garam, gula, penyedap rasa. Lalu koreksi rasa."
- "Masukkan makaroni dan kerupuk. Disusul sawi, lalu irisan kol."
- "Tunggu sebentar sampai kuah agak menyusut."
- "Tambahkan irisan tomat dan seledri. Lalu koreksi rasa kembali."
- "Jika rasa dirasa sudah pas, kompor bisa dimatikan. Lalu, seblaknya bisa disajikan dengan irisan mentimun."
categories:
- Resep
tags:
- seblak
- simple
- polmantul

katakunci: seblak simple polmantul 
nutrition: 209 calories
recipecuisine: Indonesian
preptime: "PT33M"
cooktime: "PT51M"
recipeyield: "2"
recipecategory: Lunch

---


![Seblak Simple Polmantul](https://img-global.cpcdn.com/recipes/1bb7b2005571ae2b/751x532cq70/seblak-simple-polmantul-foto-resep-utama.jpg)


seblak simple polmantul ini ialah kuliner nusantara yang istimewa dan wajib untuk kita coba. Cita rasanya yang sedap membuat siapa pun menantikan kehadirannya di meja makan.
Lagi mencari inspirasi resep seblak simple polmantul untuk jualan atau dikonsumsi sendiri yang Menggugah Selera? Cara membuatnya memang tidak terlalu sulit namun tidak gampang juga. jikalau keliru mengolah maka hasilnya Tidak Memuaskan dan bahkan tidak sedap. Padahal seblak simple polmantul yang enak seharusnya memiliki aroma dan rasa yang bisa memancing selera kita.



Ada beberapa hal yang sedikit banyak mempengaruhi kualitas rasa dari seblak simple polmantul, pertama dari jenis bahan, lalu pemilihan bahan segar sampai cara membuat dan menyajikannya. Tak perlu pusing kalau ingin menyiapkan seblak simple polmantul yang enak di rumah, karena asal sudah tahu triknya maka hidangan ini bisa jadi suguhan istimewa.


Di bawah ini ada beberapa tips dan trik praktis dalam mengolah seblak simple polmantul yang siap dikreasikan. Anda dapat membuat Seblak Simple Polmantul memakai 18 jenis bahan dan 9 tahap pembuatan. Berikut ini langkah-langkah untuk menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk pembuatan Seblak Simple Polmantul:

1. Gunakan 100 gr kerupuk udang
1. Gunakan 100 gr makaroni usus
1. Gunakan 1 ikat sawi dipotong panjang
1. Ambil 1 buah mentimun diiris tipis
1. Ambil 50 gr kol diiris tipis
1. Ambil 1 buah tomat
1. Ambil 250 ml air
1. Ambil Secukupnya minyak
1. Sediakan Secukupnya penyedap rasa
1. Sediakan Secukupnya gula
1. Sediakan 2 tangkai seledri diiris tipis
1. Siapkan  Bumbu
1. Gunakan 4 buah cabai merah
1. Gunakan 4 buah cabai rawit
1. Gunakan 3 siung bawang merah
1. Sediakan 2 siung bawang putih
1. Siapkan 1 ruas kencur
1. Siapkan Secukupnya garam




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Seblak Simple Polmantul:

1. Rebus makaroni dan kerupuk dalam air yang mendidih sampai mengembang dan teksturnya agak lunak. Jangan lupa beri sedikit minyak, agar makaroni dan kerupuknya tidak saling menempel. Lalu, tiriskan.
1. Haluskan bumbu.
1. Panaskan minyak dalam wajan. Lalu sangrai bumbu hingga harum.
1. Tambahkan air. Tunggu hingga mendidih.
1. Masukkan garam, gula, penyedap rasa. Lalu koreksi rasa.
1. Masukkan makaroni dan kerupuk. Disusul sawi, lalu irisan kol.
1. Tunggu sebentar sampai kuah agak menyusut.
1. Tambahkan irisan tomat dan seledri. Lalu koreksi rasa kembali.
1. Jika rasa dirasa sudah pas, kompor bisa dimatikan. Lalu, seblaknya bisa disajikan dengan irisan mentimun.




Terima kasih telah membaca resep yang tim kami tampilkan di sini. Harapan kami, olahan Seblak Simple Polmantul yang mudah di atas dapat membantu Anda menyiapkan hidangan yang menarik untuk keluarga/teman maupun menjadi inspirasi dalam berbisnis kuliner. Selamat mencoba!
