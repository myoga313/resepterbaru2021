---
description: "Bumbu Ayam Kecap Tomat | Cara Mengolah Ayam Kecap Tomat Yang Lezat"
title: "Bumbu Ayam Kecap Tomat | Cara Mengolah Ayam Kecap Tomat Yang Lezat"
slug: 393-bumbu-ayam-kecap-tomat-cara-mengolah-ayam-kecap-tomat-yang-lezat
date: 2020-09-06T03:56:27.254Z
image: https://img-global.cpcdn.com/recipes/f03d2c88094d31a9/751x532cq70/ayam-kecap-tomat-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/f03d2c88094d31a9/751x532cq70/ayam-kecap-tomat-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/f03d2c88094d31a9/751x532cq70/ayam-kecap-tomat-foto-resep-utama.jpg
author: Eddie Jenkins
ratingvalue: 3.3
reviewcount: 7
recipeingredient:
- "1/2 ekor ayam"
- "3 bawang putih cincang"
- "1 buah tomat ukuran sedang"
- "1 buah bawang bombai"
- "1/2 sdm Garam cek rasa"
- "secukupnya Penyedap"
- "1/2 sdt lada"
- "secukupnya Kecap"
- "1/2 sdt gula"
- "1 sdm saos tiram untuk lumuran ayam mentah"
recipeinstructions:
- "Cuci bersih ayam... kemudian lumuri ayam dengan saos tiram, tidak juga tidak apa2.. diamkan sebentar.. kemudian goreng sebentar"
- "Goreng hingga agak kecoklatan, angkat, tiriskan"
- "Siapkan bumbu dan bahan"
- "Tumis bawang putih hingga wangi"
- "Tambahkan bawang bombai"
- "Masukkan air secukupnya, beri garam, lada, penyedap, gula dan kecap... cek rasa"
- "Masukkan ayam yg telah digoreng"
- "Bisa tambahkan kecap jika kurang, aduk... diamkan hingga bumbu meresap dan kuah sedikit berkurang"
- "Masukkan tomat dan daun bawang"
- "Setelah agak menyusup dan bumbu meresap, sajikan"
- "Makan dengan nasi hangat"
categories:
- Resep
tags:
- ayam
- kecap
- tomat

katakunci: ayam kecap tomat 
nutrition: 107 calories
recipecuisine: Indonesian
preptime: "PT30M"
cooktime: "PT43M"
recipeyield: "3"
recipecategory: Dessert

---


![Ayam Kecap Tomat](https://img-global.cpcdn.com/recipes/f03d2c88094d31a9/751x532cq70/ayam-kecap-tomat-foto-resep-utama.jpg)


ayam kecap tomat ini yaitu hidangan nusantara yang enak dan wajib untuk kita coba. Cita rasanya yang enak membuat siapa pun menantikan kehadirannya di meja makan.
Bunda lagi mencari ide resep ayam kecap tomat untuk jualan atau dikonsumsi sendiri yang Menggugah Selera? Cara menyiapkannya memang susah-susah gampang. misalnya keliru mengolah maka hasilnya Tidak Memuaskan dan bahkan tidak sedap. Padahal ayam kecap tomat yang enak harusnya sih mempunyai aroma dan cita rasa yang mampu memancing selera kita.



Banyak hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari ayam kecap tomat, mulai dari jenis bahan, kemudian pemilihan bahan segar sampai cara mengolah dan menyajikannya. Tidak usah pusing jika ingin menyiapkan ayam kecap tomat yang enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini mampu jadi suguhan spesial.


Berikut ini ada beberapa cara mudah dan praktis yang dapat diterapkan untuk mengolah ayam kecap tomat yang siap dikreasikan. Anda bisa membuat Ayam Kecap Tomat menggunakan 10 bahan dan 11 langkah pembuatan. Berikut ini cara dalam membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam menyiapkan Ayam Kecap Tomat:

1. Gunakan 1/2 ekor ayam
1. Siapkan 3 bawang putih cincang
1. Ambil 1 buah tomat ukuran sedang
1. Siapkan 1 buah bawang bombai
1. Sediakan 1/2 sdm Garam (cek rasa)
1. Siapkan secukupnya Penyedap
1. Siapkan 1/2 sdt lada
1. Siapkan secukupnya Kecap
1. Ambil 1/2 sdt gula
1. Sediakan 1 sdm saos tiram (untuk lumuran ayam mentah)




<!--inarticleads2-->

##### Langkah-langkah membuat Ayam Kecap Tomat:

1. Cuci bersih ayam... kemudian lumuri ayam dengan saos tiram, tidak juga tidak apa2.. diamkan sebentar.. kemudian goreng sebentar
1. Goreng hingga agak kecoklatan, angkat, tiriskan
1. Siapkan bumbu dan bahan
1. Tumis bawang putih hingga wangi
1. Tambahkan bawang bombai
1. Masukkan air secukupnya, beri garam, lada, penyedap, gula dan kecap... cek rasa
1. Masukkan ayam yg telah digoreng
1. Bisa tambahkan kecap jika kurang, aduk... diamkan hingga bumbu meresap dan kuah sedikit berkurang
1. Masukkan tomat dan daun bawang
1. Setelah agak menyusup dan bumbu meresap, sajikan
1. Makan dengan nasi hangat




Bagaimana? Mudah bukan? Itulah cara menyiapkan ayam kecap tomat yang bisa Anda lakukan di rumah. Semoga bermanfaat dan selamat mencoba!
