---
description: "Bumbu Ayam Goreng Bacem | Cara Mengolah Ayam Goreng Bacem Yang Enak Dan Mudah"
title: "Bumbu Ayam Goreng Bacem | Cara Mengolah Ayam Goreng Bacem Yang Enak Dan Mudah"
slug: 287-bumbu-ayam-goreng-bacem-cara-mengolah-ayam-goreng-bacem-yang-enak-dan-mudah
date: 2021-01-14T13:02:22.963Z
image: https://img-global.cpcdn.com/recipes/6b7fca53861c2a3f/751x532cq70/ayam-goreng-bacem-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/6b7fca53861c2a3f/751x532cq70/ayam-goreng-bacem-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/6b7fca53861c2a3f/751x532cq70/ayam-goreng-bacem-foto-resep-utama.jpg
author: Flora Tran
ratingvalue: 3
reviewcount: 3
recipeingredient:
- "1 ekor ayam kampung"
- "1 bh jeruk nipis"
- " Bumbu di haluskan"
- "8 siung bawang putih"
- "5 bh kemiri"
- "1 ruas kencur"
- "1 sdt ketumbar"
- " Bahan tambahan"
- "4 lbr daun jeruk"
- "2 lbr daun salam"
- "1 bh sereh"
- "1 ruas lengkuas"
- "1 ruas jahe"
- "1 bh gula merah"
- "1 sdt garam"
- "1 sdt lada"
- "2 sdm kecap manis"
recipeinstructions:
- "Ayam cuci bersih, kucuri jeruk nipis diamkan 5m kemudian bilas sampai bersih."
- "Haluskan bumbu halus, kemudian di tumis sampai matang"
- "Tambahkan air tunggu sampai mendidih, tambahkan garam, lada dan gula merah"
- "Masukan ayam, masak sampai matang."
- "Sebelum ayam matang, tambahkan kecap manis, aduk rata, koreksi rasa. Kemudian angkat. Siapkan pengorengan kemudian goreng ayam dg minyak panas api kecil saja. (Kelupaan di foto saat di goreng, maaf yah)"
- "Pocan dulu yah, ini ayam nya enak bgt, lembut dan ada rasa manis nya. Patut di coba lho...😊"
categories:
- Resep
tags:
- ayam
- goreng
- bacem

katakunci: ayam goreng bacem 
nutrition: 198 calories
recipecuisine: Indonesian
preptime: "PT36M"
cooktime: "PT46M"
recipeyield: "3"
recipecategory: Lunch

---


![Ayam Goreng Bacem](https://img-global.cpcdn.com/recipes/6b7fca53861c2a3f/751x532cq70/ayam-goreng-bacem-foto-resep-utama.jpg)


ayam goreng bacem ini yaitu santapan tanah air yang unik dan harus untuk kita coba. Cita rasanya yang lezat membuat siapa pun menantikan kehadirannya di meja makan.
Kamu Sedang mencari ide resep ayam goreng bacem untuk jualan atau dikonsumsi sendiri yang Paling Enak? Cara Bikinnya memang susah-susah gampang. semisal salah mengolah maka hasilnya Tidak Memuaskan dan justru cenderung tidak enak. Padahal ayam goreng bacem yang enak harusnya sih memiliki aroma dan cita rasa yang bisa memancing selera kita.



Ada beberapa hal yang sedikit banyak mempengaruhi kualitas rasa dari ayam goreng bacem, mulai dari jenis bahan, lalu pemilihan bahan segar hingga cara mengolah dan menyajikannya. Tak perlu pusing kalau mau menyiapkan ayam goreng bacem enak di rumah, karena asal sudah tahu triknya maka hidangan ini bisa jadi suguhan istimewa.


Di bawah ini ada beberapa tips dan trik praktis yang dapat diterapkan untuk mengolah ayam goreng bacem yang siap dikreasikan. Anda dapat menyiapkan Ayam Goreng Bacem memakai 17 jenis bahan dan 6 langkah pembuatan. Berikut ini langkah-langkah untuk menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk pembuatan Ayam Goreng Bacem:

1. Sediakan 1 ekor ayam kampung
1. Gunakan 1 bh jeruk nipis
1. Siapkan  Bumbu di haluskan
1. Ambil 8 siung bawang putih
1. Gunakan 5 bh kemiri
1. Ambil 1 ruas kencur
1. Ambil 1 sdt ketumbar
1. Sediakan  Bahan tambahan
1. Ambil 4 lbr daun jeruk
1. Gunakan 2 lbr daun salam
1. Ambil 1 bh sereh
1. Siapkan 1 ruas lengkuas
1. Siapkan 1 ruas jahe
1. Ambil 1 bh gula merah
1. Siapkan 1 sdt garam
1. Siapkan 1 sdt lada
1. Ambil 2 sdm kecap manis




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Ayam Goreng Bacem:

1. Ayam cuci bersih, kucuri jeruk nipis diamkan 5m kemudian bilas sampai bersih.
1. Haluskan bumbu halus, kemudian di tumis sampai matang
1. Tambahkan air tunggu sampai mendidih, tambahkan garam, lada dan gula merah
1. Masukan ayam, masak sampai matang.
1. Sebelum ayam matang, tambahkan kecap manis, aduk rata, koreksi rasa. Kemudian angkat. Siapkan pengorengan kemudian goreng ayam dg minyak panas api kecil saja. (Kelupaan di foto saat di goreng, maaf yah)
1. Pocan dulu yah, ini ayam nya enak bgt, lembut dan ada rasa manis nya. Patut di coba lho...😊




Bagaimana? Mudah bukan? Itulah cara membuat ayam goreng bacem yang bisa Anda praktikkan di rumah. Selamat mencoba!
