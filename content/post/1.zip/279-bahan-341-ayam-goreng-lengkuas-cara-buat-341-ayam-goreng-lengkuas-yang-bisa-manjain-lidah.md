---
description: "Bahan 34.1~ Ayam Goreng Lengkuas | Cara Buat 34.1~ Ayam Goreng Lengkuas Yang Bisa Manjain Lidah"
title: "Bahan 34.1~ Ayam Goreng Lengkuas | Cara Buat 34.1~ Ayam Goreng Lengkuas Yang Bisa Manjain Lidah"
slug: 279-bahan-341-ayam-goreng-lengkuas-cara-buat-341-ayam-goreng-lengkuas-yang-bisa-manjain-lidah
date: 2020-09-07T08:20:56.576Z
image: https://img-global.cpcdn.com/recipes/109041f11e4f137e/751x532cq70/341-ayam-goreng-lengkuas-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/109041f11e4f137e/751x532cq70/341-ayam-goreng-lengkuas-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/109041f11e4f137e/751x532cq70/341-ayam-goreng-lengkuas-foto-resep-utama.jpg
author: Helena White
ratingvalue: 3.1
reviewcount: 5
recipeingredient:
- " ayam"
- " lengkuas parut"
- " Bumbu halus"
- " bawang merah"
- " bawang putih"
- " kemiri"
- " kunyit seukuran 2 ruas jari"
- " jahe"
- " ketumbar bubuk"
- " air"
- " Bumbu Ungkep"
- " daun salam sobek2"
- " daun jeruk sobek2"
- " sereh geprek"
- " garam"
- " gula"
- " merica bubuk"
- " air secukupnya"
recipeinstructions:
- "Cuci bersih ayam, saya pakai paha ayam 9 potong"
- "Masukkan air, bumbu halus, ayam, daun salam, daun jeruk, sereh, dan lengkuas parut. Aduk rata"
- "Beri gula, garam, merica bubuk dan penyedap rasa. Masak dengan api sedang cenderung kecil hingga air menyusut."
- "Saring air ungkepan dan ampas lengkuas. Pisahkan. Goreng untuk taburan ayamnya."
- "Goreng ayam dan sajikan dengan taburan lengkuas goreng"
categories:
- Resep
tags:
- 341
- ayam
- goreng

katakunci: 341 ayam goreng 
nutrition: 195 calories
recipecuisine: Indonesian
preptime: "PT26M"
cooktime: "PT46M"
recipeyield: "3"
recipecategory: Lunch

---


![34.1~ Ayam Goreng Lengkuas](https://img-global.cpcdn.com/recipes/109041f11e4f137e/751x532cq70/341-ayam-goreng-lengkuas-foto-resep-utama.jpg)


34.1~ ayam goreng lengkuas ini yaitu hidangan nusantara yang unik dan wajib untuk kita coba. Cita rasanya yang enak membuat siapa pun menantikan kehadirannya di meja makan.
Sedang mencari inspirasi resep 34.1~ ayam goreng lengkuas untuk jualan atau dikonsumsi sendiri yang Enak Banget? Cara Memasaknya memang susah-susah gampang. Jika keliru mengolah maka hasilnya tidak akan memuaskan dan justru cenderung tidak enak. Padahal 34.1~ ayam goreng lengkuas yang enak seharusnya memiliki aroma dan cita rasa yang dapat memancing selera kita.

Banyak hal yang sedikit banyak mempengaruhi kualitas rasa dari 34.1~ ayam goreng lengkuas, mulai dari jenis bahan, selanjutnya pemilihan bahan segar, sampai cara mengolah dan menghidangkannya. Tidak usah pusing jika hendak menyiapkan 34.1~ ayam goreng lengkuas enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini mampu menjadi suguhan spesial.




Berikut ini ada beberapa tips dan trik praktis yang dapat diterapkan untuk mengolah 34.1~ ayam goreng lengkuas yang siap dikreasikan. Anda dapat membuat 34.1~ Ayam Goreng Lengkuas memakai 18 bahan dan 5 tahap pembuatan. Berikut ini cara untuk membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam menyiapkan 34.1~ Ayam Goreng Lengkuas:

1. Ambil  ayam
1. Ambil  lengkuas (parut)
1. Sediakan  Bumbu halus
1. Sediakan  bawang merah
1. Ambil  bawang putih
1. Siapkan  kemiri
1. Siapkan  kunyit seukuran 2 ruas jari
1. Sediakan  jahe
1. Gunakan  ketumbar bubuk
1. Sediakan  air
1. Siapkan  Bumbu Ungkep
1. Gunakan  daun salam (sobek2)
1. Sediakan  daun jeruk (sobek2)
1. Siapkan  sereh (geprek)
1. Sediakan  garam
1. Siapkan  gula
1. Sediakan  merica bubuk
1. Siapkan  air (secukupnya)




<!--inarticleads2-->

##### Cara menyiapkan 34.1~ Ayam Goreng Lengkuas:

1. Cuci bersih ayam, saya pakai paha ayam 9 potong
1. Masukkan air, bumbu halus, ayam, daun salam, daun jeruk, sereh, dan lengkuas parut. Aduk rata
1. Beri gula, garam, merica bubuk dan penyedap rasa. Masak dengan api sedang cenderung kecil hingga air menyusut.
1. Saring air ungkepan dan ampas lengkuas. Pisahkan. Goreng untuk taburan ayamnya.
1. Goreng ayam dan sajikan dengan taburan lengkuas goreng




Gimana nih? Mudah bukan? Itulah cara membuat 34.1~ ayam goreng lengkuas yang bisa Anda lakukan di rumah. Selamat mencoba!
