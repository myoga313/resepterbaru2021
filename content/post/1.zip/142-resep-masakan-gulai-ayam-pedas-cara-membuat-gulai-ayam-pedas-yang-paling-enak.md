---
description: "Resep masakan Gulai Ayam Pedas | Cara Membuat Gulai Ayam Pedas Yang Paling Enak"
title: "Resep masakan Gulai Ayam Pedas | Cara Membuat Gulai Ayam Pedas Yang Paling Enak"
slug: 142-resep-masakan-gulai-ayam-pedas-cara-membuat-gulai-ayam-pedas-yang-paling-enak
date: 2020-10-02T05:24:58.826Z
image: https://img-global.cpcdn.com/recipes/8c1a670c653e168e/751x532cq70/gulai-ayam-pedas-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/8c1a670c653e168e/751x532cq70/gulai-ayam-pedas-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/8c1a670c653e168e/751x532cq70/gulai-ayam-pedas-foto-resep-utama.jpg
author: Clara Blake
ratingvalue: 4.4
reviewcount: 14
recipeingredient:
- " Ayam Me Bagian Paha Cincang Kecil"
- " Jeruk Nipis"
- " Bumbu halus"
- " Bawang Merah"
- " Bawang Putih"
- " Cabe Merah Keriting"
- " Cabe Rawit Merah"
- " Kunyit"
- " Jahe"
- " Ketumbar Sangrai"
- " Kemiri Sangrai"
- " Jintan"
- " Bumbum Utuh"
- " Daun Salam"
- " Daun Jeruk buang tulangnya"
- " Serai Geprek"
- " Lengkuas Geprek"
- " Asam Kandis ukuran Sedang"
- " Air"
- " Santan Kara 65ml"
- " Minyak secukupnya untuk menumis"
- " Garam"
- " Gula"
- " Kaldu Ayam Sesuai Selera"
recipeinstructions:
- "Cuci ayam sampai bersih, lalu kucuri dengan air perasan jeruk nipis. Diamkan selama 10 menit, lalu bilas kembali hingga bersih. Sisihkan"
- "Siapkan bumbu - bumbu. Baik yg dihaluskan dan yg utuh"
- "Tumis terlebih dahulu bumbu halus hingga harum, kemudian masukkan bumbu utuh dan masak hingga matang"
- "Setelah itu masukkan ayam yg sudah dibersihka. Tumis hingga bumbu tercampur rata dengan ayam. Kemudian tambahkan air + santan, aduk rata"
- "Kemudian masukkan garam + gula + kaldu ayam. Masak ayam hingga matang dan air sedikit menyusut."
- "Jika sudah matang, angkat dan siap disajikan. Selesai"
categories:
- Resep
tags:
- gulai
- ayam
- pedas

katakunci: gulai ayam pedas 
nutrition: 259 calories
recipecuisine: Indonesian
preptime: "PT25M"
cooktime: "PT31M"
recipeyield: "4"
recipecategory: Dinner

---


![Gulai Ayam Pedas](https://img-global.cpcdn.com/recipes/8c1a670c653e168e/751x532cq70/gulai-ayam-pedas-foto-resep-utama.jpg)


gulai ayam pedas ini yaitu makanan tanah air yang enak dan wajib untuk kita coba. Cita rasanya yang sedap membuat siapa pun menantikan kehadirannya di meja makan.
Kamu Sedang mencari inspirasi resep gulai ayam pedas untuk jualan atau dikonsumsi sendiri yang Enak Dan Mudah? Cara Bikinnya memang susah-susah gampang. seumpama salah mengolah maka hasilnya Tidak Memuaskan dan bahkan tidak sedap. Padahal gulai ayam pedas yang enak seharusnya mempunyai aroma dan cita rasa yang dapat memancing selera kita.



Banyak hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari gulai ayam pedas, pertama dari jenis bahan, kemudian pemilihan bahan segar hingga cara mengolah dan menghidangkannya. Tidak usah pusing jika ingin menyiapkan gulai ayam pedas enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini mampu menjadi suguhan spesial.


Berikut ini ada beberapa tips dan trik praktis yang dapat diterapkan untuk mengolah gulai ayam pedas yang siap dikreasikan. Anda bisa membuat Gulai Ayam Pedas menggunakan 24 jenis bahan dan 6 tahap pembuatan. Berikut ini langkah-langkah untuk membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk menyiapkan Gulai Ayam Pedas:

1. Sediakan  Ayam (Me Bagian Paha) Cincang Kecil
1. Sediakan  Jeruk Nipis
1. Ambil  Bumbu halus
1. Gunakan  Bawang Merah
1. Sediakan  Bawang Putih
1. Siapkan  Cabe Merah Keriting
1. Gunakan  Cabe Rawit Merah
1. Siapkan  Kunyit
1. Gunakan  Jahe
1. Sediakan  Ketumbar Sangrai
1. Siapkan  Kemiri Sangrai
1. Siapkan  Jintan
1. Siapkan  Bumbum Utuh
1. Siapkan  Daun Salam
1. Ambil  Daun Jeruk buang tulangnya
1. Sediakan  Serai Geprek
1. Siapkan  Lengkuas Geprek
1. Siapkan  Asam Kandis ukuran Sedang
1. Gunakan  Air
1. Ambil  Santan Kara 65ml
1. Gunakan  Minyak secukupnya untuk menumis
1. Ambil  Garam
1. Ambil  Gula
1. Siapkan  Kaldu Ayam (Sesuai Selera)




<!--inarticleads2-->

##### Langkah-langkah membuat Gulai Ayam Pedas:

1. Cuci ayam sampai bersih, lalu kucuri dengan air perasan jeruk nipis. Diamkan selama 10 menit, lalu bilas kembali hingga bersih. Sisihkan
1. Siapkan bumbu - bumbu. Baik yg dihaluskan dan yg utuh
1. Tumis terlebih dahulu bumbu halus hingga harum, kemudian masukkan bumbu utuh dan masak hingga matang
1. Setelah itu masukkan ayam yg sudah dibersihka. Tumis hingga bumbu tercampur rata dengan ayam. Kemudian tambahkan air + santan, aduk rata
1. Kemudian masukkan garam + gula + kaldu ayam. Masak ayam hingga matang dan air sedikit menyusut.
1. Jika sudah matang, angkat dan siap disajikan. Selesai




Gimana nih? Mudah bukan? Itulah cara menyiapkan gulai ayam pedas yang bisa Anda praktikkan di rumah. Selamat mencoba!
