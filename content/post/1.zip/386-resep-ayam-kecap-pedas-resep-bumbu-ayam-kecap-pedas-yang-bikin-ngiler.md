---
description: "Resep Ayam Kecap Pedas | Resep Bumbu Ayam Kecap Pedas Yang Bikin Ngiler"
title: "Resep Ayam Kecap Pedas | Resep Bumbu Ayam Kecap Pedas Yang Bikin Ngiler"
slug: 386-resep-ayam-kecap-pedas-resep-bumbu-ayam-kecap-pedas-yang-bikin-ngiler
date: 2020-09-02T10:17:06.858Z
image: https://img-global.cpcdn.com/recipes/013fcdf99d82ef80/751x532cq70/ayam-kecap-pedas-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/013fcdf99d82ef80/751x532cq70/ayam-kecap-pedas-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/013fcdf99d82ef80/751x532cq70/ayam-kecap-pedas-foto-resep-utama.jpg
author: Tom Freeman
ratingvalue: 4.9
reviewcount: 12
recipeingredient:
- " Bahan"
- " ayam pakai bagian paha lebih enak"
- " daun jeruk"
- " lengkuas cuci bersih kupas lalu geprek"
- " kecap bango"
- " gula merah serut"
- " lada putih bubuk"
- " kaldu bubuk dan garam"
- " santan bubuk"
- " minyak untuk menumis"
- " Bumbu halus 1"
- " bawang putih"
- " bawang merah"
- " Bumbu halus 2"
- " tomat kecil"
- " kemiri goreng dulu"
- " cabai merah keriting"
- " cabai rawit merah"
- " pala"
recipeinstructions:
- "Potong ayam menjadi beberapa bagian (saya pakai bagian dada dan dipotong jadi 8). Lalu cuci bersih di air mengalir."
- "Panaskan wajan, masukkan sedikit minyak. Tumis bumbu halus 1 bersama daun jeruk dan lengkuas hingga kekuningan."
- "Masukkan bumbu halus 2, tumis bersamaan hingga sedikit mengering."
- "Beri air secukupnya (kira-kira ayamnya bisa terendam saat dimasak)"
- "Setelah mendidih masukkan kecap, garam, kaldu bubuk, lada, dan gula merah yang sudah diserut. Tes rasa. Kalau sudah pas masukkan ayamnya, tunggu mendidih lagi kemudian kecilkan api kompor dan tutup wajannya."
- "Setelah kurang lebih 20 menit buka tutupnya lalu masukkan santan bubuk, aduk rata. Lalu tutup kembali dan biarkan bumbu meresap kurang lebih 15-20 menit."
- "Selesai"
categories:
- Resep
tags:
- ayam
- kecap
- pedas

katakunci: ayam kecap pedas 
nutrition: 168 calories
recipecuisine: Indonesian
preptime: "PT18M"
cooktime: "PT41M"
recipeyield: "4"
recipecategory: Lunch

---


![Ayam Kecap Pedas](https://img-global.cpcdn.com/recipes/013fcdf99d82ef80/751x532cq70/ayam-kecap-pedas-foto-resep-utama.jpg)


ayam kecap pedas ini yakni kuliner nusantara yang khas dan harus untuk kita coba. Cita rasanya yang nikmat membuat siapa pun menantikan kehadirannya di meja makan.
Lagi mencari ide resep ayam kecap pedas untuk jualan atau dikonsumsi sendiri yang Bikin Ngiler? Cara Buatnya memang tidak susah dan tidak juga mudah. bila salah mengolah maka hasilnya akan hambar dan bahkan tidak sedap. Padahal ayam kecap pedas yang enak seharusnya memiliki aroma dan cita rasa yang bisa memancing selera kita.



Banyak hal yang sedikit banyak mempengaruhi kualitas rasa dari ayam kecap pedas, mulai dari jenis bahan, lalu pemilihan bahan segar hingga cara membuat dan menyajikannya. Tak perlu pusing jika hendak menyiapkan ayam kecap pedas enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini dapat menjadi suguhan istimewa.


Berikut ini ada beberapa tips dan trik praktis untuk membuat ayam kecap pedas yang siap dikreasikan. Anda bisa menyiapkan Ayam Kecap Pedas menggunakan 19 bahan dan 7 langkah pembuatan. Berikut ini cara dalam membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam pembuatan Ayam Kecap Pedas:

1. Gunakan  Bahan:
1. Sediakan  ayam (pakai bagian paha lebih enak)
1. Siapkan  daun jeruk
1. Siapkan  lengkuas, cuci bersih, kupas lalu geprek
1. Gunakan  kecap bango
1. Gunakan  gula merah serut
1. Ambil  lada putih bubuk
1. Sediakan  kaldu bubuk dan garam
1. Sediakan  santan bubuk
1. Siapkan  minyak untuk menumis
1. Gunakan  Bumbu halus 1:
1. Ambil  bawang putih
1. Sediakan  bawang merah
1. Siapkan  Bumbu halus 2:
1. Ambil  tomat kecil
1. Ambil  kemiri, goreng dulu
1. Ambil  cabai merah keriting
1. Gunakan  cabai rawit merah
1. Siapkan  pala




<!--inarticleads2-->

##### Langkah-langkah membuat Ayam Kecap Pedas:

1. Potong ayam menjadi beberapa bagian (saya pakai bagian dada dan dipotong jadi 8). Lalu cuci bersih di air mengalir.
1. Panaskan wajan, masukkan sedikit minyak. Tumis bumbu halus 1 bersama daun jeruk dan lengkuas hingga kekuningan.
1. Masukkan bumbu halus 2, tumis bersamaan hingga sedikit mengering.
1. Beri air secukupnya (kira-kira ayamnya bisa terendam saat dimasak)
1. Setelah mendidih masukkan kecap, garam, kaldu bubuk, lada, dan gula merah yang sudah diserut. Tes rasa. Kalau sudah pas masukkan ayamnya, tunggu mendidih lagi kemudian kecilkan api kompor dan tutup wajannya.
1. Setelah kurang lebih 20 menit buka tutupnya lalu masukkan santan bubuk, aduk rata. Lalu tutup kembali dan biarkan bumbu meresap kurang lebih 15-20 menit.
1. Selesai




Bagaimana? Gampang kan? Itulah cara menyiapkan ayam kecap pedas yang bisa Anda lakukan di rumah. Semoga bermanfaat dan selamat mencoba!
