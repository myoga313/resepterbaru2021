---
description: "Olahan Donat Menal Menul With Metode Autolysis | Bahan Membuat Donat Menal Menul With Metode Autolysis Yang Paling Enak"
title: "Olahan Donat Menal Menul With Metode Autolysis | Bahan Membuat Donat Menal Menul With Metode Autolysis Yang Paling Enak"
slug: 200-olahan-donat-menal-menul-with-metode-autolysis-bahan-membuat-donat-menal-menul-with-metode-autolysis-yang-paling-enak
date: 2020-12-19T22:51:14.367Z
image: https://img-global.cpcdn.com/recipes/40910a8e4de06afe/751x532cq70/donat-menal-menul-with-metode-autolysis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/40910a8e4de06afe/751x532cq70/donat-menal-menul-with-metode-autolysis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/40910a8e4de06afe/751x532cq70/donat-menal-menul-with-metode-autolysis-foto-resep-utama.jpg
author: Walter Williams
ratingvalue: 3.6
reviewcount: 12
recipeingredient:
- " Bahan A "
- "250 gr tepung cakra"
- "1 sdm susu bubuk full cream"
- "125 ml air"
- "2 1/2 sdm gula pasir"
- "1 butir kuning telur"
- "Sejumput garam halus"
- " Bahan B "
- "5 ml air  takaran 1 sendok obat sirup"
- "3 gr ragi instan fernipam"
- "50 gr mentega royal palmia"
recipeinstructions:
- "Siapkan bahan 2,,lalu Masukkan kuning telur,gula pasir pd baskom"
- "Kocok lepas hingga rata lalu masukkan air aduk sampai merata, lalu masukkan tepung terigu,susu bubuk, dan garam,,aduk sampai tercampur,lalu uleni sebentar,lalu buat bulatan"
- "Tutup adonan diamkan selama 6-8jam,,tp saya ini selama 6 jam ngadon selesai pas jam 12mlm,,jd pas saya cek saat subuh ternyata sudah lentur ya mom,,sambil menunggu juga siapkan coklat leleh nya/glazenya,,jika sudah lentur Tandanya sudah bisa di beri Bahan B"
- "Kemudian tambahkan air pd ragi,,aduk hingga menjadi pasta ya,"
- "Lalu oles² ke adonan yg sudah lentur tadi aduk sampai ½ Kalis lalu masukkan mentega dan kembali uleni sampai kalis"
- "Kalis elastis seperti gambar,,lalu ambil adonan timbang 30-40gr bulatan, letakkan pd loyang yang sudah di alasi plastik,,atau baking paper taburi dengan tepung terigu agar tidak menempel,, lakukan sampai habis adonan,lalu bolongkan adonan dengan spuit kuker,,"
- "Lalu diamkan hingga 30-60menit tp ini di menit ke 45 saya sudah mengembang jd sudah bisa di goreng,, panaskan minyak goreng tes dengan sumpit bila sudah berbuih sudah bisa di masukkan ke dalam wajan.. kemudian ubah ke api kecil,lalu masukkan donat dengan posisi yg atas ada di bawah minyak goreng,putar tengahnya dengan sumpit, kemudian balik dan angkat, tiriskan."
- "Lalu dinginkan untuk diberi coklat leleh/glaze,selera aja ya.. [ Note : ingat moms proses membalik donat hanya satu kali saja,jd ga perlu bolak-balik,,Lalu angkat, Tiriskan,karena akan menghilangkan efek white ring nya pd donat ],, lakukan sampai habis..dan siap untuk dinikmati selamat mencoba semoga bermanfaat 👌🙏😊"
categories:
- Resep
tags:
- donat
- menal
- menul

katakunci: donat menal menul 
nutrition: 101 calories
recipecuisine: Indonesian
preptime: "PT11M"
cooktime: "PT44M"
recipeyield: "4"
recipecategory: Dinner

---


![Donat Menal Menul With Metode Autolysis](https://img-global.cpcdn.com/recipes/40910a8e4de06afe/751x532cq70/donat-menal-menul-with-metode-autolysis-foto-resep-utama.jpg)


donat menal menul with metode autolysis ini yaitu suguhan nusantara yang unik dan perlu untuk kita coba. Cita rasanya yang enak membuat siapa pun menantikan kehadirannya di meja makan.
Sedang mencari inspirasi resep donat menal menul with metode autolysis untuk jualan atau dikonsumsi sendiri yang Bikin Ngiler? Cara menyiapkannya memang susah-susah gampang. semisal keliru mengolah maka hasilnya Tidak Memuaskan dan bahkan tidak sedap. Padahal donat menal menul with metode autolysis yang enak seharusnya mempunyai aroma dan cita rasa yang bisa memancing selera kita.



Ada beberapa hal yang sedikit banyak mempengaruhi kualitas rasa dari donat menal menul with metode autolysis, mulai dari jenis bahan, kemudian pemilihan bahan segar hingga cara mengolah dan menghidangkannya. Tidak usah pusing kalau mau menyiapkan donat menal menul with metode autolysis yang enak di rumah, karena asal sudah tahu triknya maka hidangan ini mampu jadi suguhan spesial.


Nah, kali ini kita coba, yuk, kreasikan donat menal menul with metode autolysis sendiri di rumah. Tetap dengan bahan sederhana, sajian ini dapat memberi manfaat dalam membantu menjaga kesehatan tubuh kita. Anda bisa menyiapkan Donat Menal Menul With Metode Autolysis menggunakan 11 bahan dan 8 langkah pembuatan. Berikut ini langkah-langkah untuk membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk menyiapkan Donat Menal Menul With Metode Autolysis:

1. Ambil  Bahan A :
1. Ambil 250 gr tepung cakra
1. Gunakan 1 sdm susu bubuk full cream
1. Ambil 125 ml air
1. Gunakan 2 1/2 sdm gula pasir
1. Sediakan 1 butir kuning telur
1. Gunakan Sejumput garam halus
1. Sediakan  Bahan B :
1. Ambil 5 ml air / takaran 1 sendok obat sirup
1. Siapkan 3 gr ragi instan fernipam
1. Sediakan 50 gr mentega royal palmia




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Donat Menal Menul With Metode Autolysis:

1. Siapkan bahan 2,,lalu Masukkan kuning telur,gula pasir pd baskom
1. Kocok lepas hingga rata lalu masukkan air aduk sampai merata, lalu masukkan tepung terigu,susu bubuk, dan garam,,aduk sampai tercampur,lalu uleni sebentar,lalu buat bulatan
1. Tutup adonan diamkan selama 6-8jam,,tp saya ini selama 6 jam ngadon selesai pas jam 12mlm,,jd pas saya cek saat subuh ternyata sudah lentur ya mom,,sambil menunggu juga siapkan coklat leleh nya/glazenya,,jika sudah lentur Tandanya sudah bisa di beri Bahan B
1. Kemudian tambahkan air pd ragi,,aduk hingga menjadi pasta ya,
1. Lalu oles² ke adonan yg sudah lentur tadi aduk sampai ½ Kalis lalu masukkan mentega dan kembali uleni sampai kalis
1. Kalis elastis seperti gambar,,lalu ambil adonan timbang 30-40gr bulatan, letakkan pd loyang yang sudah di alasi plastik,,atau baking paper taburi dengan tepung terigu agar tidak menempel,, lakukan sampai habis adonan,lalu bolongkan adonan dengan spuit kuker,,
1. Lalu diamkan hingga 30-60menit tp ini di menit ke 45 saya sudah mengembang jd sudah bisa di goreng,, panaskan minyak goreng tes dengan sumpit bila sudah berbuih sudah bisa di masukkan ke dalam wajan.. kemudian ubah ke api kecil,lalu masukkan donat dengan posisi yg atas ada di bawah minyak goreng,putar tengahnya dengan sumpit, kemudian balik dan angkat, tiriskan.
1. Lalu dinginkan untuk diberi coklat leleh/glaze,selera aja ya.. [ Note : ingat moms proses membalik donat hanya satu kali saja,jd ga perlu bolak-balik,,Lalu angkat, Tiriskan,karena akan menghilangkan efek white ring nya pd donat ],, lakukan sampai habis..dan siap untuk dinikmati selamat mencoba semoga bermanfaat 👌🙏😊




Gimana nih? Gampang kan? Itulah cara membuat donat menal menul with metode autolysis yang bisa Anda praktikkan di rumah. Selamat mencoba!
