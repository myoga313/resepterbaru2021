---
description: "Bumbu Ayam Kecap sederhana | Langkah Membuat Ayam Kecap sederhana Yang Enak Dan Mudah"
title: "Bumbu Ayam Kecap sederhana | Langkah Membuat Ayam Kecap sederhana Yang Enak Dan Mudah"
slug: 378-bumbu-ayam-kecap-sederhana-langkah-membuat-ayam-kecap-sederhana-yang-enak-dan-mudah
date: 2020-10-10T13:56:32.978Z
image: https://img-global.cpcdn.com/recipes/fe567c4d08cfa524/751x532cq70/ayam-kecap-sederhana-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/fe567c4d08cfa524/751x532cq70/ayam-kecap-sederhana-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/fe567c4d08cfa524/751x532cq70/ayam-kecap-sederhana-foto-resep-utama.jpg
author: Gertrude Cruz
ratingvalue: 4.4
reviewcount: 14
recipeingredient:
- "1/2 kg Ayam potongpotong sesuai selera"
- "4 buah tahu iris serong lalu goreng setengah kering"
- " Bumbu Uleg"
- "2 buah cabe rawit bisa ditambah jika suka pedas"
- "3 buah cabe merah besar"
- "2 siung bawang putih"
- "5 siung bawang merah"
- "1 buah kemiri"
- "1 buah tomat"
- " Bumbu Cemplung"
- "2 lembar daun jeruk"
- "2 lembar daun salam"
- "1 batang daun sereh"
- "4 sdm Kecap Manis"
- "8 buah cabe rawit hijau"
- "Secukupnya garam"
- "Secukupnya penyedap jamur"
- "35 ml santan kental kr"
recipeinstructions:
- "Cuci bersih ayam lalu masak sebentar. Angkat lalu tiriskan"
- "Goreng ayam hingga setengah matang"
- "Haluskan semua bumbu"
- "Panaskan minyak lalu goreng bumbu hingga harum, kasih air aduk rata biarkan mendidih"
- "Kemudian masukkan ayam, tahu dan bumbu lainnya (daun salam, daun jeruk, serai, cabe rawit hijau, garam penyedap jamur, kecap dan santan). Aduk rata, tunggu sampai mendidih. koreksi rasa. dan angkat"
- "Ayam siap dihidangkan dengan nasi hangat.. Selamat mencoba"
categories:
- Resep
tags:
- ayam
- kecap
- sederhana

katakunci: ayam kecap sederhana 
nutrition: 190 calories
recipecuisine: Indonesian
preptime: "PT16M"
cooktime: "PT30M"
recipeyield: "4"
recipecategory: Dinner

---


![Ayam Kecap sederhana](https://img-global.cpcdn.com/recipes/fe567c4d08cfa524/751x532cq70/ayam-kecap-sederhana-foto-resep-utama.jpg)


ayam kecap sederhana ini merupakan kuliner tanah air yang istimewa dan wajib untuk kita coba. Cita rasanya yang nikmat membuat siapa pun menantikan kehadirannya di meja makan.
Lagi mencari ide resep ayam kecap sederhana untuk jualan atau dikonsumsi sendiri yang Menggugah Selera? Cara membuatnya memang tidak susah dan tidak juga mudah. apabila salah mengolah maka hasilnya tidak akan memuaskan dan justru cenderung tidak enak. Padahal ayam kecap sederhana yang enak selayaknya punya aroma dan cita rasa yang dapat memancing selera kita.

Ada beberapa hal yang sedikit banyak mempengaruhi kualitas rasa dari ayam kecap sederhana, pertama dari jenis bahan, selanjutnya pemilihan bahan segar, hingga cara membuat dan menghidangkannya. Tak perlu pusing kalau mau menyiapkan ayam kecap sederhana enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini dapat menjadi suguhan istimewa.




Berikut ini ada beberapa cara mudah dan praktis untuk membuat ayam kecap sederhana yang siap dikreasikan. Anda bisa membuat Ayam Kecap sederhana menggunakan 18 jenis bahan dan 6 tahap pembuatan. Berikut ini cara dalam menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk menyiapkan Ayam Kecap sederhana:

1. Gunakan 1/2 kg Ayam potong-potong sesuai selera
1. Siapkan 4 buah tahu iris serong lalu goreng setengah kering
1. Ambil  Bumbu Uleg
1. Ambil 2 buah cabe rawit (bisa ditambah jika suka pedas)
1. Gunakan 3 buah cabe merah besar
1. Gunakan 2 siung bawang putih
1. Ambil 5 siung bawang merah
1. Gunakan 1 buah kemiri
1. Siapkan 1 buah tomat
1. Siapkan  Bumbu Cemplung
1. Sediakan 2 lembar daun jeruk
1. Siapkan 2 lembar daun salam
1. Ambil 1 batang daun sereh
1. Ambil 4 sdm Kecap Manis
1. Sediakan 8 buah cabe rawit hijau
1. Siapkan Secukupnya garam
1. Sediakan Secukupnya penyedap jamur
1. Sediakan 35 ml santan kental (k*r*)




<!--inarticleads2-->

##### Cara membuat Ayam Kecap sederhana:

1. Cuci bersih ayam lalu masak sebentar. Angkat lalu tiriskan
1. Goreng ayam hingga setengah matang
1. Haluskan semua bumbu
1. Panaskan minyak lalu goreng bumbu hingga harum, kasih air aduk rata biarkan mendidih
1. Kemudian masukkan ayam, tahu dan bumbu lainnya (daun salam, daun jeruk, serai, cabe rawit hijau, garam penyedap jamur, kecap dan santan). Aduk rata, tunggu sampai mendidih. koreksi rasa. dan angkat
1. Ayam siap dihidangkan dengan nasi hangat.. Selamat mencoba




Bagaimana? Mudah bukan? Itulah cara membuat ayam kecap sederhana yang bisa Anda lakukan di rumah. Semoga bermanfaat dan selamat mencoba!
