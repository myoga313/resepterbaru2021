---
description: "Bumbu Nasi Kuning | Cara Membuat Nasi Kuning Yang Enak dan Simpel"
title: "Bumbu Nasi Kuning | Cara Membuat Nasi Kuning Yang Enak dan Simpel"
slug: 91-bumbu-nasi-kuning-cara-membuat-nasi-kuning-yang-enak-dan-simpel
date: 2020-10-22T21:29:44.675Z
image: https://img-global.cpcdn.com/recipes/982e9be37c02b6ed/751x532cq70/nasi-kuning-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/982e9be37c02b6ed/751x532cq70/nasi-kuning-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/982e9be37c02b6ed/751x532cq70/nasi-kuning-foto-resep-utama.jpg
author: Alejandro Wallace
ratingvalue: 4.3
reviewcount: 8
recipeingredient:
- " beras"
- " santan instant 200ml  air"
- " salam"
- " daun jeruk"
- " daun pandan"
- " serai"
- " lengkuas"
- " kunyit"
- " air jeruk nipis"
- " Garam"
recipeinstructions:
- "Cuci bersih beras"
- "Blender kunyit, saring, ambil airnya. Geprek serai dan lengkuas"
- "Didihkan santan+air (secukupnya, kira-kira setengah takaran air untuk memasak nasi) tambahkan air kunyit, jeruk nipis, lengkuas dan daun-daunan dan garam"
- "Setelah mendidih, masukkan beras. Masak sampai air terserap habis."
- "Pindahkan ke dandang, kukus sampai empuk."
categories:
- Resep
tags:
- nasi
- kuning

katakunci: nasi kuning 
nutrition: 180 calories
recipecuisine: Indonesian
preptime: "PT34M"
cooktime: "PT41M"
recipeyield: "4"
recipecategory: Dessert

---


![Nasi Kuning](https://img-global.cpcdn.com/recipes/982e9be37c02b6ed/751x532cq70/nasi-kuning-foto-resep-utama.jpg)


nasi kuning ini ialah hidangan nusantara yang spesial dan harus untuk kita coba. Cita rasanya yang nikmat membuat siapa pun menantikan kehadirannya di meja makan.
Anda sedang mencari inspirasi resep nasi kuning untuk jualan atau dikonsumsi sendiri yang Sedap? Cara Buatnya memang susah-susah gampang. sekiranya keliru mengolah maka hasilnya tidak akan memuaskan dan bahkan tidak sedap. Padahal nasi kuning yang enak selayaknya memiliki aroma dan cita rasa yang bisa memancing selera kita.



Banyak hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari nasi kuning, pertama dari jenis bahan, kedua pemilihan bahan segar sampai cara mengolah dan menyajikannya. Tak perlu pusing jika hendak menyiapkan nasi kuning yang enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini mampu jadi sajian istimewa.


Di bawah ini ada beberapa cara mudah dan praktis dalam mengolah nasi kuning yang siap dikreasikan. Anda dapat membuat Nasi Kuning memakai 10 jenis bahan dan 5 langkah pembuatan. Berikut ini langkah-langkah dalam menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk pembuatan Nasi Kuning:

1. Ambil  beras
1. Gunakan  santan instant 200ml + air
1. Sediakan  salam
1. Sediakan  daun jeruk
1. Gunakan  daun pandan
1. Ambil  serai
1. Gunakan  lengkuas
1. Sediakan  kunyit
1. Sediakan  air jeruk nipis
1. Sediakan  Garam




<!--inarticleads2-->

##### Cara membuat Nasi Kuning:

1. Cuci bersih beras
1. Blender kunyit, saring, ambil airnya. Geprek serai dan lengkuas
1. Didihkan santan+air (secukupnya, kira-kira setengah takaran air untuk memasak nasi) tambahkan air kunyit, jeruk nipis, lengkuas dan daun-daunan dan garam
1. Setelah mendidih, masukkan beras. Masak sampai air terserap habis.
1. Pindahkan ke dandang, kukus sampai empuk.




Terima kasih telah membaca resep yang kami tampilkan di sini. Harapan kami, olahan Nasi Kuning yang mudah di atas dapat membantu Anda menyiapkan hidangan yang menarik untuk keluarga/teman ataupun menjadi ide untuk berjualan makanan. Semoga bermanfaat dan selamat mencoba!
