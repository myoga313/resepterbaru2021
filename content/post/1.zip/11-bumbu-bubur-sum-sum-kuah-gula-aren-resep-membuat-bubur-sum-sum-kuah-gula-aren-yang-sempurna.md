---
description: "Bumbu Bubur Sum-Sum Kuah Gula Aren | Resep Membuat Bubur Sum-Sum Kuah Gula Aren Yang Sempurna"
title: "Bumbu Bubur Sum-Sum Kuah Gula Aren | Resep Membuat Bubur Sum-Sum Kuah Gula Aren Yang Sempurna"
slug: 11-bumbu-bubur-sum-sum-kuah-gula-aren-resep-membuat-bubur-sum-sum-kuah-gula-aren-yang-sempurna
date: 2020-12-06T01:27:51.046Z
image: https://img-global.cpcdn.com/recipes/cf7161c2db7b28cc/751x532cq70/bubur-sum-sum-kuah-gula-aren-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/cf7161c2db7b28cc/751x532cq70/bubur-sum-sum-kuah-gula-aren-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/cf7161c2db7b28cc/751x532cq70/bubur-sum-sum-kuah-gula-aren-foto-resep-utama.jpg
author: Don Weber
ratingvalue: 3.4
reviewcount: 3
recipeingredient:
- "100 gram tepung beras"
- "1000 ml santan bisa dr campuran 200ml santan instan800 ml air"
- "1 sdt garam"
- "1 lembar daun pandan simpul"
- " Bahan KincaKuah"
- "150 gram gula arenmerah"
- "1 cangkir air"
- "1 lembar daun pandan simpul"
recipeinstructions:
- "Campur semua bahan jadi satu. Aduk hingga licin benar supaya tidak menggumpal pas dimasak."
- "Masak diatas api sedang cenderung kecil sambil diaduk hingga mendidih dan meletup-letup, angkat."
- "Campur semua bahan menjadi satu, masak hingga gula larut. Angkat dan saring."
- "Sajikan bubur sum sum dengan kuah kinca. Siap disantap hangat atau juga enak kalau dingin."
categories:
- Resep
tags:
- bubur
- sumsum
- kuah

katakunci: bubur sumsum kuah 
nutrition: 150 calories
recipecuisine: Indonesian
preptime: "PT17M"
cooktime: "PT47M"
recipeyield: "4"
recipecategory: Dessert

---


![Bubur Sum-Sum Kuah Gula Aren](https://img-global.cpcdn.com/recipes/cf7161c2db7b28cc/751x532cq70/bubur-sum-sum-kuah-gula-aren-foto-resep-utama.jpg)


bubur sum-sum kuah gula aren ini yakni makanan nusantara yang unik dan harus untuk kita coba. Cita rasanya yang enak membuat siapa pun menantikan kehadirannya di meja makan.
Sedang mencari ide resep bubur sum-sum kuah gula aren untuk jualan atau dikonsumsi sendiri yang Sempurna? Cara membuatnya memang susah-susah gampang. misalnya keliru mengolah maka hasilnya Tidak Memuaskan dan justru cenderung tidak enak. Padahal bubur sum-sum kuah gula aren yang enak selayaknya mempunyai aroma dan rasa yang mampu memancing selera kita.

Selamat menjalankan ibadah puasa ya guys🙏. Hai guys kali ini @hellencooking mau berbagi resep bagaimana Cara Membuat Takjil Simple Bubur Sumsum Gula Aren. Bubur sum-sum merupakan sejenis kuih yang dimakan dengan kuah manis (air nisan/gula).

Ada beberapa hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari bubur sum-sum kuah gula aren, pertama dari jenis bahan, lalu pemilihan bahan segar hingga cara membuat dan menghidangkannya. Tak perlu pusing jika mau menyiapkan bubur sum-sum kuah gula aren enak di rumah, karena asal sudah tahu triknya maka hidangan ini mampu menjadi sajian spesial.


Nah, kali ini kita coba, yuk, siapkan bubur sum-sum kuah gula aren sendiri di rumah. Tetap berbahan yang sederhana, sajian ini dapat memberi manfaat untuk membantu menjaga kesehatan tubuh kita. Anda dapat membuat Bubur Sum-Sum Kuah Gula Aren menggunakan 8 jenis bahan dan 4 tahap pembuatan. Berikut ini cara dalam menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam pembuatan Bubur Sum-Sum Kuah Gula Aren:

1. Ambil 100 gram tepung beras
1. Siapkan 1000 ml santan (bisa dr campuran 200ml santan instan+800 ml air)
1. Siapkan 1 sdt garam
1. Sediakan 1 lembar daun pandan, simpul
1. Sediakan  Bahan Kinca/Kuah:
1. Ambil 150 gram gula aren/merah
1. Gunakan 1 cangkir air
1. Ambil 1 lembar daun pandan, simpul


Bubur sumsum sangat enak dikonsumsi bila sedang bosan dengan nasi meski sebenarnya bubur sumsum lebih tepat disebut camilan. Sajikan bubur sumsum dengan cara menuangkannya bersama dengan santan dan gula merah yang sudah dicairkan. Yup , makanan tradisional ini digemari oleh banyak orang karena rasanya yang manis dan gurih. Hmm , pada tulisan kali ini aku akan menjelaskan tentang cara membuat Bubur Sum-Sum ala Rika yang lembut, manis, gurih dan sederhana. ^ Bubur sumsum terbuat dari campuran tepung beras dan santan. 

<!--inarticleads2-->

##### Langkah-langkah membuat Bubur Sum-Sum Kuah Gula Aren:

1. Campur semua bahan jadi satu. Aduk hingga licin benar supaya tidak menggumpal pas dimasak.
1. Masak diatas api sedang cenderung kecil sambil diaduk hingga mendidih dan meletup-letup, angkat.
1. Campur semua bahan menjadi satu, masak hingga gula larut. Angkat dan saring.
1. Sajikan bubur sum sum dengan kuah kinca. Siap disantap hangat atau juga enak kalau dingin.


Disajikan bersama saus kinca atau saus gula merah. Sajian ini biasa disantap saat sarapan. Tak lupa, bubur sumsum disiram dengan saus gula merah. Executive Chef dari Hotel Santika Premiere Yogyakarta Totok Siswantoko. Bubur sumsum terbuat dari tepung beras yang dimasak bersama santan dan dinikmati bersama kuah gula merah atau juruh. 

Terima kasih telah membaca resep yang kami tampilkan di sini. Besar harapan kami, olahan Bubur Sum-Sum Kuah Gula Aren yang mudah di atas dapat membantu Anda menyiapkan hidangan yang sedap untuk keluarga/teman maupun menjadi ide dalam berjualan makanan. Selamat mencoba!
