---
description: "Resep Ayam Geprek Cabe Ijo | Cara Mengolah Ayam Geprek Cabe Ijo Yang Enak dan Simpel"
title: "Resep Ayam Geprek Cabe Ijo | Cara Mengolah Ayam Geprek Cabe Ijo Yang Enak dan Simpel"
slug: 130-resep-ayam-geprek-cabe-ijo-cara-mengolah-ayam-geprek-cabe-ijo-yang-enak-dan-simpel
date: 2020-09-22T10:40:53.059Z
image: https://img-global.cpcdn.com/recipes/747fe258c1138c75/751x532cq70/ayam-geprek-cabe-ijo-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/747fe258c1138c75/751x532cq70/ayam-geprek-cabe-ijo-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/747fe258c1138c75/751x532cq70/ayam-geprek-cabe-ijo-foto-resep-utama.jpg
author: Stanley Gill
ratingvalue: 3.6
reviewcount: 7
recipeingredient:
- " Ayam goreng"
- " cabe rawit hijau"
- " cabe rawit merah"
- " bawang putih"
- " Garam dan kaldu jamur"
- " minyak panas bekas goreng ayam"
recipeinstructions:
- "Siapkan bahan cuci bersih"
- "Uleg cabe²an, bawang, beri garam dan kaldu jamur. Enak nya sih jangan terlalu halus uleg nya. Kemudian beri 1 sdt minyak panas bekas goreng ayam tadi supaya sambel tidak langu (bau mentah)"
- "Geprek ayam pada cobek campur dengan sambelnya. Sajikan dengan nasi hangat 😍"
categories:
- Resep
tags:
- ayam
- geprek
- cabe

katakunci: ayam geprek cabe 
nutrition: 116 calories
recipecuisine: Indonesian
preptime: "PT20M"
cooktime: "PT44M"
recipeyield: "2"
recipecategory: Dessert

---


![Ayam Geprek Cabe Ijo](https://img-global.cpcdn.com/recipes/747fe258c1138c75/751x532cq70/ayam-geprek-cabe-ijo-foto-resep-utama.jpg)


ayam geprek cabe ijo ini yaitu kuliner tanah air yang spesial dan wajib untuk kita coba. Cita rasanya yang mantap membuat siapa pun menantikan kehadirannya di meja makan.
Lagi mencari ide resep ayam geprek cabe ijo untuk jualan atau dikonsumsi sendiri yang Lezat Sekali? Cara Memasaknya memang tidak terlalu sulit namun tidak gampang juga. andaikan salah mengolah maka hasilnya akan hambar dan bahkan tidak sedap. Padahal ayam geprek cabe ijo yang enak seharusnya mempunyai aroma dan rasa yang bisa memancing selera kita.

Ada beberapa hal yang sedikit banyak mempengaruhi kualitas rasa dari ayam geprek cabe ijo, mulai dari jenis bahan, lalu pemilihan bahan segar, sampai cara membuat dan menyajikannya. Tak perlu pusing kalau hendak menyiapkan ayam geprek cabe ijo enak di rumah, karena asal sudah tahu triknya maka hidangan ini dapat menjadi suguhan istimewa.




Berikut ini ada beberapa tips dan trik praktis dalam mengolah ayam geprek cabe ijo yang siap dikreasikan. Anda dapat menyiapkan Ayam Geprek Cabe Ijo menggunakan 6 bahan dan 3 langkah pembuatan. Berikut ini langkah-langkah untuk membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk menyiapkan Ayam Geprek Cabe Ijo:

1. Ambil  Ayam goreng
1. Ambil  cabe rawit hijau
1. Gunakan  cabe rawit merah
1. Ambil  bawang putih
1. Gunakan  Garam dan kaldu jamur
1. Ambil  minyak panas bekas goreng ayam




<!--inarticleads2-->

##### Cara membuat Ayam Geprek Cabe Ijo:

1. Siapkan bahan cuci bersih
1. Uleg cabe²an, bawang, beri garam dan kaldu jamur. Enak nya sih jangan terlalu halus uleg nya. Kemudian beri 1 sdt minyak panas bekas goreng ayam tadi supaya sambel tidak langu (bau mentah)
1. Geprek ayam pada cobek campur dengan sambelnya. Sajikan dengan nasi hangat 😍




Bagaimana? Mudah bukan? Itulah cara membuat ayam geprek cabe ijo yang bisa Anda praktikkan di rumah. Selamat mencoba!
