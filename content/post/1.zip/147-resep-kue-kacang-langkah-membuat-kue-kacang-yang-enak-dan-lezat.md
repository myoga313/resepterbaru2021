---
description: "Resep Kue Kacang | Langkah Membuat Kue Kacang Yang Enak Dan Lezat"
title: "Resep Kue Kacang | Langkah Membuat Kue Kacang Yang Enak Dan Lezat"
slug: 147-resep-kue-kacang-langkah-membuat-kue-kacang-yang-enak-dan-lezat
date: 2020-11-05T18:01:08.200Z
image: https://img-global.cpcdn.com/recipes/152c63d1c6bd8585/751x532cq70/kue-kacang-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/152c63d1c6bd8585/751x532cq70/kue-kacang-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/152c63d1c6bd8585/751x532cq70/kue-kacang-foto-resep-utama.jpg
author: Brian Fletcher
ratingvalue: 4
reviewcount: 13
recipeingredient:
- "150 gr kacang tanah yang sudah disangrai blender halus"
- "225 gr tepung protein sedang ayak"
- "25 gr susu bubuk ayak"
- "60 gr gula halus ayak"
- "150 ml minyak sayur"
- " Olesan"
- "2 butir kuning telur"
- "1/4 sdt minyakmadususu"
- "Opsional wijen"
recipeinstructions:
- "Campur rata kacang, tepung terigu, susu bubuk dan gula halus."
- "Tambahkan minyak kemudian aduk rata."
- "Pipihkan adonan dan cetak sesuai keinginan kemudian susun dalam loyang."
- "Olesi dengan kuning telur yang sudah dicampur dengan minyak/madu/susu kemudian taburi sedikit wijen untuk mempercantik penampilan."
- "Oven dengan suhu 150°C selama 15-20 menit."
categories:
- Resep
tags:
- kue
- kacang

katakunci: kue kacang 
nutrition: 207 calories
recipecuisine: Indonesian
preptime: "PT30M"
cooktime: "PT57M"
recipeyield: "4"
recipecategory: Dessert

---


![Kue Kacang](https://img-global.cpcdn.com/recipes/152c63d1c6bd8585/751x532cq70/kue-kacang-foto-resep-utama.jpg)


kue kacang ini merupakan sajian nusantara yang unik dan wajib untuk kita coba. Cita rasanya yang nikmat membuat siapa pun menantikan kehadirannya di meja makan.
Kamu Sedang mencari inspirasi resep kue kacang untuk jualan atau dikonsumsi sendiri yang Lezat? Cara Memasaknya memang susah-susah gampang. andaikata salah mengolah maka hasilnya akan hambar dan justru cenderung tidak enak. Padahal kue kacang yang enak selayaknya memiliki aroma dan rasa yang bisa memancing selera kita.



Ada beberapa hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari kue kacang, pertama dari jenis bahan, kemudian pemilihan bahan segar sampai cara membuat dan menghidangkannya. Tidak usah pusing kalau mau menyiapkan kue kacang enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini bisa menjadi suguhan istimewa.


Nah, kali ini kita coba, yuk, ciptakan kue kacang sendiri di rumah. Tetap dengan bahan sederhana, hidangan ini bisa memberi manfaat dalam membantu menjaga kesehatan tubuhmu sekeluarga. Anda dapat membuat Kue Kacang menggunakan 9 jenis bahan dan 5 langkah pembuatan. Berikut ini cara dalam menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam pembuatan Kue Kacang:

1. Siapkan 150 gr kacang tanah yang sudah disangrai, blender halus
1. Sediakan 225 gr tepung protein sedang, ayak
1. Gunakan 25 gr susu bubuk, ayak
1. Siapkan 60 gr gula halus, ayak
1. Gunakan 150 ml minyak sayur
1. Ambil  Olesan
1. Siapkan 2 butir kuning telur
1. Gunakan 1/4 sdt minyak/madu/susu
1. Ambil Opsional wijen




<!--inarticleads2-->

##### Langkah-langkah membuat Kue Kacang:

1. Campur rata kacang, tepung terigu, susu bubuk dan gula halus.
1. Tambahkan minyak kemudian aduk rata.
1. Pipihkan adonan dan cetak sesuai keinginan kemudian susun dalam loyang.
1. Olesi dengan kuning telur yang sudah dicampur dengan minyak/madu/susu kemudian taburi sedikit wijen untuk mempercantik penampilan.
1. Oven dengan suhu 150°C selama 15-20 menit.




Gimana nih? Mudah bukan? Itulah cara membuat kue kacang yang bisa Anda praktikkan di rumah. Semoga bermanfaat dan selamat mencoba!
