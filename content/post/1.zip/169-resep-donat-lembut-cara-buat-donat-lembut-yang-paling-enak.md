---
description: "Resep Donat Lembut | Cara Buat Donat Lembut Yang Paling Enak"
title: "Resep Donat Lembut | Cara Buat Donat Lembut Yang Paling Enak"
slug: 169-resep-donat-lembut-cara-buat-donat-lembut-yang-paling-enak
date: 2020-08-08T03:32:20.684Z
image: https://img-global.cpcdn.com/recipes/6ae50caf412dcb1a/751x532cq70/donat-lembut-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/6ae50caf412dcb1a/751x532cq70/donat-lembut-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/6ae50caf412dcb1a/751x532cq70/donat-lembut-foto-resep-utama.jpg
author: Victoria Banks
ratingvalue: 3.6
reviewcount: 5
recipeingredient:
- " Tepung Protein Tinggi"
- " Tepung Protein Sedang"
- " Tepung Maizena"
- " Kuning Telur"
- " Susu Bubuk Dancow"
- " Ovalet"
- " Gula Pasir 2 SDM dilarutkan dengan air"
- " Garam"
- " Margarin"
- " Bibit Roti  ragi"
- " Air Hangat"
- " Minyak untuk menggoreng"
- " Gula Halus untuk Topping"
recipeinstructions:
- "Larutkan 2 SDM Gula pasir dengan air hangat, masukkan bibit roti aduk dan diamkan ±10 menit (jika berbuih berarti ragi aktif)"
- "Campuran semua tepung, susu bubuk, gula pasir (3 SDM), Ovalet &amp; telur aduk rata"
- "Masukkan larutan ragi sedikit demi sedikit hingga tercampur"
- "Masukkan garam &amp; margarin uleni hingga kalis, cirinya adonan sudah halus dan lentur"
- "Diamkan adonan hingga mengembang, tutup wadah dengan plastik/kain (1 jam sudah cukup sebetulnya tapi tadi saya tinggal sekitar 5 jam)"
- "Buang anginnya dengan menekan adonan perlahan, timbang sekitar 30 gram dan bulatkan. Diamkan 30 menit"
- "Pipihkan lalu cetak sesuai selera, saya pakai cetakan donat. Diamkan lagi sekitar 30 menit sambil menyiapkan minyak untuk menggoreng"
- "Goreng dalam minyak panas dengan api kecil sampai matang. Cukup satu kali balik agar tidak terlalu menyerap minyak"
- "Sajikan dengan topping sesuai selera. Hasil donat lembut namun tidak kempes, pas sesuai selera keluarga."
categories:
- Resep
tags:
- donat
- lembut

katakunci: donat lembut 
nutrition: 186 calories
recipecuisine: Indonesian
preptime: "PT25M"
cooktime: "PT39M"
recipeyield: "2"
recipecategory: Dinner

---


![Donat Lembut](https://img-global.cpcdn.com/recipes/6ae50caf412dcb1a/751x532cq70/donat-lembut-foto-resep-utama.jpg)


donat lembut ini ialah santapan nusantara yang khas dan harus untuk kita coba. Cita rasanya yang lezat membuat siapa pun menantikan kehadirannya di meja makan.
Kamu Lagi mencari inspirasi resep donat lembut untuk jualan atau dikonsumsi sendiri yang Lezat Sekali? Cara menyiapkannya memang tidak terlalu sulit namun tidak gampang juga. semisal keliru mengolah maka hasilnya akan hambar dan bahkan tidak sedap. Padahal donat lembut yang enak harusnya sih mempunyai aroma dan cita rasa yang bisa memancing selera kita.



Banyak hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari donat lembut, pertama dari jenis bahan, lalu pemilihan bahan segar sampai cara membuat dan menghidangkannya. Tak perlu pusing jika hendak menyiapkan donat lembut enak di rumah, karena asal sudah tahu triknya maka hidangan ini mampu menjadi sajian istimewa.


Di bawah ini ada beberapa cara mudah dan praktis yang dapat diterapkan untuk mengolah donat lembut yang siap dikreasikan. Anda dapat membuat Donat Lembut memakai 13 jenis bahan dan 9 langkah pembuatan. Berikut ini cara dalam menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk pembuatan Donat Lembut:

1. Ambil  Tepung Protein Tinggi
1. Siapkan  Tepung Protein Sedang
1. Ambil  Tepung Maizena
1. Gunakan  Kuning Telur
1. Sediakan  Susu Bubuk Dancow
1. Siapkan  Ovalet
1. Sediakan  Gula Pasir (2 SDM dilarutkan dengan air)
1. Gunakan  Garam
1. Gunakan  Margarin
1. Sediakan  Bibit Roti / ragi
1. Gunakan  Air Hangat
1. Siapkan  Minyak untuk menggoreng
1. Gunakan  Gula Halus untuk Topping




<!--inarticleads2-->

##### Cara membuat Donat Lembut:

1. Larutkan 2 SDM Gula pasir dengan air hangat, masukkan bibit roti aduk dan diamkan ±10 menit (jika berbuih berarti ragi aktif)
1. Campuran semua tepung, susu bubuk, gula pasir (3 SDM), Ovalet &amp; telur aduk rata
1. Masukkan larutan ragi sedikit demi sedikit hingga tercampur
1. Masukkan garam &amp; margarin uleni hingga kalis, cirinya adonan sudah halus dan lentur
1. Diamkan adonan hingga mengembang, tutup wadah dengan plastik/kain (1 jam sudah cukup sebetulnya tapi tadi saya tinggal sekitar 5 jam)
1. Buang anginnya dengan menekan adonan perlahan, timbang sekitar 30 gram dan bulatkan. Diamkan 30 menit
1. Pipihkan lalu cetak sesuai selera, saya pakai cetakan donat. Diamkan lagi sekitar 30 menit sambil menyiapkan minyak untuk menggoreng
1. Goreng dalam minyak panas dengan api kecil sampai matang. Cukup satu kali balik agar tidak terlalu menyerap minyak
1. Sajikan dengan topping sesuai selera. Hasil donat lembut namun tidak kempes, pas sesuai selera keluarga.




Terima kasih telah menggunakan resep yang kami tampilkan di sini. Besar harapan kami, olahan Donat Lembut yang mudah di atas dapat membantu Anda menyiapkan makanan yang enak untuk keluarga/teman maupun menjadi ide bagi Anda yang berkeinginan untuk berjualan makanan. Selamat mencoba!
