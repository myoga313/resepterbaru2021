---
description: "Resep masakan Bubur Sumsum Anti Gagal (santan kara) | Resep Membuat Bubur Sumsum Anti Gagal (santan kara) Yang Bikin Ngiler"
title: "Resep masakan Bubur Sumsum Anti Gagal (santan kara) | Resep Membuat Bubur Sumsum Anti Gagal (santan kara) Yang Bikin Ngiler"
slug: 7-resep-masakan-bubur-sumsum-anti-gagal-santan-kara-resep-membuat-bubur-sumsum-anti-gagal-santan-kara-yang-bikin-ngiler
date: 2020-09-03T17:42:18.639Z
image: https://img-global.cpcdn.com/recipes/17f9d28a51eb20c0/751x532cq70/bubur-sumsum-anti-gagal-santan-kara-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/17f9d28a51eb20c0/751x532cq70/bubur-sumsum-anti-gagal-santan-kara-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/17f9d28a51eb20c0/751x532cq70/bubur-sumsum-anti-gagal-santan-kara-foto-resep-utama.jpg
author: Madge Clayton
ratingvalue: 3.2
reviewcount: 6
recipeingredient:
- " bahan bubur sumsum "
- "50 gram tepung beras 5 sdmbisa lebih untuk mengatur tekstur kekentalan bubur"
- "1 bks santan kara uk 65 gramair 3 atau 4 gelas uk sedang"
- "1 lembar daun pandan"
- "sejumput garam"
- " bahan saus kinca "
- "2 bh gula merah uk sedang  boleh lebih banyak biar kentel kuahnya"
- "2 gelas air gelas ukuran sedang"
- "1 lembar daun pandan"
- "sejumput garam"
- "secukupnya gula putih optional  aku ga pake karena manis dari gula merah sudah cukup"
recipeinstructions:
- "Masak santan terlebih dahulu, tambahkan sejumput garam dan daun pandan. tunggu hingga mendidih. setelah mendidih campurkan larutan tepung beras (liat note), jangan dilupa diaduk. jika bubur sum sum sudah mengental, angkat. sajikan."
- "Note :  1. Tepung beras dikasih air terlebih dulu, biar dia cair dan tidak mengumpal pada saat proses pemasakan.  2. jika tekstur bubur sumsum belum mengental tambahkan tepung beras (tidak perlu di kasih air) sedikit demi sedikit kedalam panci. hingga mendapatkan tekstur kekentalan yang diinginkan."
- "Saus kinca :  masukkan gula merah, garam, daun pandan. diaduk. dipanasin sampe larut. angkat.  note :  air banyak = gula juga harus banyak, biar kentel."
categories:
- Resep
tags:
- bubur
- sumsum
- anti

katakunci: bubur sumsum anti 
nutrition: 178 calories
recipecuisine: Indonesian
preptime: "PT21M"
cooktime: "PT40M"
recipeyield: "4"
recipecategory: Dinner

---


![Bubur Sumsum Anti Gagal (santan kara)](https://img-global.cpcdn.com/recipes/17f9d28a51eb20c0/751x532cq70/bubur-sumsum-anti-gagal-santan-kara-foto-resep-utama.jpg)


bubur sumsum anti gagal (santan kara) ini yakni makanan tanah air yang istimewa dan perlu untuk kita coba. Cita rasanya yang mantap membuat siapa pun menantikan kehadirannya di meja makan.
Sedang mencari inspirasi resep bubur sumsum anti gagal (santan kara) untuk jualan atau dikonsumsi sendiri yang Sedap? Cara Bikinnya memang tidak terlalu sulit namun tidak gampang juga. kalau keliru mengolah maka hasilnya akan hambar dan justru cenderung tidak enak. Padahal bubur sumsum anti gagal (santan kara) yang enak harusnya sih punya aroma dan rasa yang mampu memancing selera kita.

Ada beberapa hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari bubur sumsum anti gagal (santan kara), mulai dari jenis bahan, selanjutnya pemilihan bahan segar, hingga cara membuat dan menghidangkannya. Tak perlu pusing jika ingin menyiapkan bubur sumsum anti gagal (santan kara) enak di rumah, karena asal sudah tahu triknya maka hidangan ini dapat jadi suguhan spesial.




Di bawah ini ada beberapa tips dan trik praktis yang dapat diterapkan untuk mengolah bubur sumsum anti gagal (santan kara) yang siap dikreasikan. Anda dapat membuat Bubur Sumsum Anti Gagal (santan kara) menggunakan 11 bahan dan 3 langkah pembuatan. Berikut ini langkah-langkah dalam membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam pembuatan Bubur Sumsum Anti Gagal (santan kara):

1. Ambil  bahan bubur sumsum :
1. Siapkan 50 gram tepung beras (5 sdm-bisa lebih untuk mengatur tekstur kekentalan bubur)
1. Ambil 1 bks santan kara (uk 65 gram+air 3 atau 4 gelas uk sedang)
1. Ambil 1 lembar daun pandan
1. Ambil sejumput garam
1. Sediakan  bahan saus kinca :
1. Ambil 2 bh gula merah (uk sedang) - (boleh lebih banyak, biar kentel kuahnya)
1. Sediakan 2 gelas air (gelas ukuran sedang)
1. Ambil 1 lembar daun pandan
1. Sediakan sejumput garam
1. Gunakan secukupnya gula putih (optional - aku ga pake karena manis dari gula merah sudah cukup)




<!--inarticleads2-->

##### Langkah-langkah membuat Bubur Sumsum Anti Gagal (santan kara):

1. Masak santan terlebih dahulu, tambahkan sejumput garam dan daun pandan. tunggu hingga mendidih. setelah mendidih campurkan larutan tepung beras (liat note), jangan dilupa diaduk. jika bubur sum sum sudah mengental, angkat. sajikan.
1. Note :  - 1. Tepung beras dikasih air terlebih dulu, biar dia cair dan tidak mengumpal pada saat proses pemasakan.  - 2. jika tekstur bubur sumsum belum mengental tambahkan tepung beras (tidak perlu di kasih air) sedikit demi sedikit kedalam panci. hingga mendapatkan tekstur kekentalan yang diinginkan.
1. Saus kinca :  - masukkan gula merah, garam, daun pandan. diaduk. dipanasin sampe larut. angkat. -  - note :  - air banyak = gula juga harus banyak, biar kentel.




Gimana nih? Mudah bukan? Itulah cara menyiapkan bubur sumsum anti gagal (santan kara) yang bisa Anda lakukan di rumah. Selamat mencoba!
