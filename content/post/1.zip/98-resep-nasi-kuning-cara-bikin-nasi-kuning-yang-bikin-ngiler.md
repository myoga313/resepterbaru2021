---
description: "Resep Nasi kuning | Cara Bikin Nasi kuning Yang Bikin Ngiler"
title: "Resep Nasi kuning | Cara Bikin Nasi kuning Yang Bikin Ngiler"
slug: 98-resep-nasi-kuning-cara-bikin-nasi-kuning-yang-bikin-ngiler
date: 2020-11-02T02:17:28.553Z
image: https://img-global.cpcdn.com/recipes/0ce78f2dade268d6/751x532cq70/nasi-kuning-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/0ce78f2dade268d6/751x532cq70/nasi-kuning-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/0ce78f2dade268d6/751x532cq70/nasi-kuning-foto-resep-utama.jpg
author: Alan Briggs
ratingvalue: 3.5
reviewcount: 14
recipeingredient:
- "500 gram beras"
- "65 mL santan kara"
- "600 mL air"
- "1 sdt kunyit bubuk"
- "1 batang serai geprek"
- "3 lb daun salam"
- "secukupnya Garam"
- "secukupnya Gula"
- " Bumbu halus "
- "3 siung bawang putih"
- "5 siung bawang merah"
- "3 cm jahe"
recipeinstructions:
- "Tumis bumbu halus hingga harum. Tambahkan serai dan daun salam. Tumis."
- "Tambahkan kunyit bubuk, air, garam, gula, dan santan ke dalam tumisan bumbu. Tes rasa. Jika pas, matikan api."
- "Cuci beras, tuanglan air bumbu ke beras yg sudah dicuci."
- "Masak hingga matang seperti masak nasi biasa pakai rice cooker."
- "Aduk aduk jika nasi sudah matang."
categories:
- Resep
tags:
- nasi
- kuning

katakunci: nasi kuning 
nutrition: 185 calories
recipecuisine: Indonesian
preptime: "PT19M"
cooktime: "PT57M"
recipeyield: "1"
recipecategory: Dinner

---


![Nasi kuning](https://img-global.cpcdn.com/recipes/0ce78f2dade268d6/751x532cq70/nasi-kuning-foto-resep-utama.jpg)


nasi kuning ini merupakan santapan nusantara yang ekslusif dan wajib untuk kita coba. Cita rasanya yang nikmat membuat siapa pun menantikan kehadirannya di meja makan.
Lagi mencari ide resep nasi kuning untuk jualan atau dikonsumsi sendiri yang Bisa Manjain Lidah? Cara Bikinnya memang tidak susah dan tidak juga mudah. sekiranya keliru mengolah maka hasilnya akan hambar dan bahkan tidak sedap. Padahal nasi kuning yang enak selayaknya mempunyai aroma dan rasa yang bisa memancing selera kita.



Banyak hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari nasi kuning, pertama dari jenis bahan, kedua pemilihan bahan segar hingga cara mengolah dan menghidangkannya. Tak perlu pusing jika hendak menyiapkan nasi kuning enak di rumah, karena asal sudah tahu triknya maka hidangan ini mampu jadi sajian istimewa.


Berikut ini ada beberapa cara mudah dan praktis untuk membuat nasi kuning yang siap dikreasikan. Anda dapat membuat Nasi kuning menggunakan 12 jenis bahan dan 5 langkah pembuatan. Berikut ini cara dalam membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam pembuatan Nasi kuning:

1. Ambil 500 gram beras
1. Siapkan 65 mL santan kara
1. Gunakan 600 mL air
1. Sediakan 1 sdt kunyit bubuk
1. Sediakan 1 batang serai geprek
1. Ambil 3 lb daun salam
1. Sediakan secukupnya Garam
1. Siapkan secukupnya Gula
1. Ambil  Bumbu halus :
1. Ambil 3 siung bawang putih
1. Ambil 5 siung bawang merah
1. Ambil 3 cm jahe




<!--inarticleads2-->

##### Cara membuat Nasi kuning:

1. Tumis bumbu halus hingga harum. Tambahkan serai dan daun salam. Tumis.
1. Tambahkan kunyit bubuk, air, garam, gula, dan santan ke dalam tumisan bumbu. Tes rasa. Jika pas, matikan api.
1. Cuci beras, tuanglan air bumbu ke beras yg sudah dicuci.
1. Masak hingga matang seperti masak nasi biasa pakai rice cooker.
1. Aduk aduk jika nasi sudah matang.




Gimana nih? Gampang kan? Itulah cara membuat nasi kuning yang bisa Anda praktikkan di rumah. Semoga bermanfaat dan selamat mencoba!
