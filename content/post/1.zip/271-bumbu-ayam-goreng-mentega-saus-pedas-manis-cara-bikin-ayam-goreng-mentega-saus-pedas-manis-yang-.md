---
description: "Bumbu Ayam goreng mentega (saus pedas manis) | Cara Bikin Ayam goreng mentega (saus pedas manis) Yang Menggugah Selera"
title: "Bumbu Ayam goreng mentega (saus pedas manis) | Cara Bikin Ayam goreng mentega (saus pedas manis) Yang Menggugah Selera"
slug: 271-bumbu-ayam-goreng-mentega-saus-pedas-manis-cara-bikin-ayam-goreng-mentega-saus-pedas-manis-yang-menggugah-selera
date: 2021-01-17T11:40:26.257Z
image: https://img-global.cpcdn.com/recipes/bb001d7ffa79fd1e/751x532cq70/ayam-goreng-mentega-saus-pedas-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/bb001d7ffa79fd1e/751x532cq70/ayam-goreng-mentega-saus-pedas-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/bb001d7ffa79fd1e/751x532cq70/ayam-goreng-mentega-saus-pedas-manis-foto-resep-utama.jpg
author: Mattie Swanson
ratingvalue: 4.1
reviewcount: 5
recipeingredient:
- " paha atas bawah ayam"
- " Bawang bombay di iris tipistipis"
- " Wortel besar dipotong sesuai selera"
- " bawang putih di cincang halus"
- " jeruk nipis"
- " garam"
- " merica bubuk"
- " Saus tomat"
- " saus sambal"
- " kecap manis"
- " kecap inggris"
- " baby paprika hanya optional kalau tidak dipakai juga gapapa moms"
- " Kaldu jamur totole optional juga ya moms"
- " Mentega blueband"
recipeinstructions:
- "4 potong ayam di peras dengan jeruk nipis + balurkan garam biasa (himalayan salt juga boleh) lalu di diamkan 10menit."
- "Masukan minyak ke dalam panci sekiranya goreng ayam nya bisa tenggelam (biar merata sempurna). lalu bolak balik hingga warna ke emasan. Lalu jika sudah keemasan, saya tambahkan blueband di atas ayam tsb agar rasa blueband nya menyerap di daging dalam ayam."
- "Setelah ayam matang, tiriskan. Lalu masukan blueband 3 sendok ke dalam panci, dan tumis bawang putih + bawang bombay + baby paprika hingga wangi."
- "Setelah wangi, masukan campuran bumbu (Saus sambal, Saus tomat, Kecap inggris, Kecap manis, Merica 1 sachet) lalu aduk sampai merata. Setelah merata masukn wortel dan tambahkan air (saya 2gelas full air 500ml takarannya) lalu masukan wortel, dan masak hingga worlet setengah empuk."
- "Setelah semuanya sudah tercampur, beri air lagi 100ml lalu tuangkan, dan masukan ayam yang sudah di goreng ke dalam panci. masak hingga kuah berubah menjadi sedikit kental (jangan lupa cobaiin rasanya ya mom, takutnya selera masing2 beda jadi kalau ada yg kurang bisa di tambah). Lalu saya tuang kaldu jamur totole sedikit (ini optional). Lalu tunggu sampai mengental, dan matikan kompor."
- "Jadi deh, silahkan mencoba🤍 dijamin rasanya nagih.."
categories:
- Resep
tags:
- ayam
- goreng
- mentega

katakunci: ayam goreng mentega 
nutrition: 288 calories
recipecuisine: Indonesian
preptime: "PT13M"
cooktime: "PT58M"
recipeyield: "2"
recipecategory: Dinner

---


![Ayam goreng mentega (saus pedas manis)](https://img-global.cpcdn.com/recipes/bb001d7ffa79fd1e/751x532cq70/ayam-goreng-mentega-saus-pedas-manis-foto-resep-utama.jpg)


ayam goreng mentega (saus pedas manis) ini ialah hidangan nusantara yang unik dan perlu untuk kita coba. Cita rasanya yang lezat membuat siapa pun menantikan kehadirannya di meja makan.
Kamu Sedang mencari ide resep ayam goreng mentega (saus pedas manis) untuk jualan atau dikonsumsi sendiri yang Mudah Dan Praktis? Cara membuatnya memang susah-susah gampang. andaikan keliru mengolah maka hasilnya akan hambar dan justru cenderung tidak enak. Padahal ayam goreng mentega (saus pedas manis) yang enak selayaknya punya aroma dan cita rasa yang mampu memancing selera kita.



Banyak hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari ayam goreng mentega (saus pedas manis), mulai dari jenis bahan, kedua pemilihan bahan segar sampai cara membuat dan menyajikannya. Tidak usah pusing jika ingin menyiapkan ayam goreng mentega (saus pedas manis) yang enak di rumah, karena asal sudah tahu triknya maka hidangan ini dapat jadi sajian istimewa.


Nah, kali ini kita coba, yuk, variasikan ayam goreng mentega (saus pedas manis) sendiri di rumah. Tetap berbahan yang sederhana, sajian ini dapat memberi manfaat untuk membantu menjaga kesehatan tubuhmu sekeluarga. Anda bisa membuat Ayam goreng mentega (saus pedas manis) menggunakan 14 bahan dan 6 langkah pembuatan. Berikut ini cara untuk membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk menyiapkan Ayam goreng mentega (saus pedas manis):

1. Gunakan  paha atas bawah ayam
1. Ambil  Bawang bombay (di iris tipis-tipis)
1. Siapkan  Wortel besar (dipotong sesuai selera)
1. Sediakan  bawang putih (di cincang halus)
1. Siapkan  jeruk nipis
1. Sediakan  garam
1. Sediakan  merica bubuk
1. Siapkan  Saus tomat
1. Ambil  saus sambal
1. Sediakan  kecap manis
1. Sediakan  kecap inggris
1. Gunakan  baby paprika (hanya optional, kalau tidak dipakai juga gapapa moms)
1. Ambil  Kaldu jamur totole (optional juga ya moms)
1. Gunakan  Mentega (blueband)




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Ayam goreng mentega (saus pedas manis):

1. 4 potong ayam di peras dengan jeruk nipis + balurkan garam biasa (himalayan salt juga boleh) lalu di diamkan 10menit.
1. Masukan minyak ke dalam panci sekiranya goreng ayam nya bisa tenggelam (biar merata sempurna). lalu bolak balik hingga warna ke emasan. Lalu jika sudah keemasan, saya tambahkan blueband di atas ayam tsb agar rasa blueband nya menyerap di daging dalam ayam.
1. Setelah ayam matang, tiriskan. Lalu masukan blueband 3 sendok ke dalam panci, dan tumis bawang putih + bawang bombay + baby paprika hingga wangi.
1. Setelah wangi, masukan campuran bumbu (Saus sambal, Saus tomat, Kecap inggris, Kecap manis, Merica 1 sachet) lalu aduk sampai merata. Setelah merata masukn wortel dan tambahkan air (saya 2gelas full air 500ml takarannya) lalu masukan wortel, dan masak hingga worlet setengah empuk.
1. Setelah semuanya sudah tercampur, beri air lagi 100ml lalu tuangkan, dan masukan ayam yang sudah di goreng ke dalam panci. masak hingga kuah berubah menjadi sedikit kental (jangan lupa cobaiin rasanya ya mom, takutnya selera masing2 beda jadi kalau ada yg kurang bisa di tambah). Lalu saya tuang kaldu jamur totole sedikit (ini optional). Lalu tunggu sampai mengental, dan matikan kompor.
1. Jadi deh, silahkan mencoba🤍 dijamin rasanya nagih..




Bagaimana? Gampang kan? Itulah cara menyiapkan ayam goreng mentega (saus pedas manis) yang bisa Anda lakukan di rumah. Semoga bermanfaat dan selamat mencoba!
