---
description: "Resep masakan Ayam Goreng Lengkuas | Cara Bikin Ayam Goreng Lengkuas Yang Enak Dan Lezat"
title: "Resep masakan Ayam Goreng Lengkuas | Cara Bikin Ayam Goreng Lengkuas Yang Enak Dan Lezat"
slug: 300-resep-masakan-ayam-goreng-lengkuas-cara-bikin-ayam-goreng-lengkuas-yang-enak-dan-lezat
date: 2020-11-26T23:02:56.505Z
image: https://img-global.cpcdn.com/recipes/83377d3db23c6ddb/751x532cq70/ayam-goreng-lengkuas-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/83377d3db23c6ddb/751x532cq70/ayam-goreng-lengkuas-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/83377d3db23c6ddb/751x532cq70/ayam-goreng-lengkuas-foto-resep-utama.jpg
author: Alex Harper
ratingvalue: 4
reviewcount: 12
recipeingredient:
- "1 kg sayap ayam"
- " Bahan Marinasi Ayam "
- "1 sdm garam"
- "1 buah jeruk ambil airnya  bisa di ganti cuka"
- "Secukupnya penyedap rasa"
- " Bahan Lengkuas "
- "120 gr lengkuas diparut"
- "8 siung bawang putih uleg"
- "50 ml air kelapa"
- "1 butir telur"
- "1 sdt kaldu bubuk ayam"
- "1 sdt garam"
- "2 ruas kunyit uleg"
- "1 sdm margarin"
- " Bahan Ungkep "
- "20 lembar daun salam"
recipeinstructions:
- "Marinasi ayam nya dulu yaa, sebelumnya udah dicuci dulu. Diamkan ayam marinasi selama 1 jam simpan kulkas, setelah itu di ungkep sampe matang, nanti dia ngeluarin air sendiri abis itu tetep diungkep sampe air asat. Tips nya : siapkan wajan anti lengket, tata daun salam taruh ayam di atasnya lalu tutup lagi pakai daun salam nya"
- "Siapkan bahan lengkuas..campur semua bahan ya..tuang sedikit2 air kelapa cukup sampe nyemek2 aja gitu"
- "Tunggu ayam ungkep tadi dingin ya, baru di balurin ke bahan lengkuas, taruh dalam wadah simpan di kulkas minimal 1 jam biar bumbu meresap..abis itu goreng, jadi ini bisa di simpan ya, jadi sewaktu2 tinggal goreng deh😚"
- "Serius ini enak bgt apalagi temennya nasi gurih..hhmmmm"
- "Yummy 🤤"
- "Selamat mencoba"
categories:
- Resep
tags:
- ayam
- goreng
- lengkuas

katakunci: ayam goreng lengkuas 
nutrition: 131 calories
recipecuisine: Indonesian
preptime: "PT20M"
cooktime: "PT36M"
recipeyield: "4"
recipecategory: Dinner

---


![Ayam Goreng Lengkuas](https://img-global.cpcdn.com/recipes/83377d3db23c6ddb/751x532cq70/ayam-goreng-lengkuas-foto-resep-utama.jpg)


ayam goreng lengkuas ini merupakan makanan tanah air yang spesial dan wajib untuk kita coba. Cita rasanya yang mantap membuat siapa pun menantikan kehadirannya di meja makan.
Lagi mencari inspirasi resep ayam goreng lengkuas untuk jualan atau dikonsumsi sendiri yang Sempurna? Cara menyiapkannya memang tidak terlalu sulit namun tidak gampang juga. kalau salah mengolah maka hasilnya akan hambar dan justru cenderung tidak enak. Padahal ayam goreng lengkuas yang enak harusnya sih mempunyai aroma dan rasa yang dapat memancing selera kita.



Banyak hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari ayam goreng lengkuas, mulai dari jenis bahan, kemudian pemilihan bahan segar hingga cara membuat dan menghidangkannya. Tidak usah pusing kalau mau menyiapkan ayam goreng lengkuas enak di rumah, karena asal sudah tahu triknya maka hidangan ini mampu jadi suguhan spesial.


Nah, kali ini kita coba, yuk, siapkan ayam goreng lengkuas sendiri di rumah. Tetap dengan bahan sederhana, sajian ini dapat memberi manfaat dalam membantu menjaga kesehatan tubuhmu sekeluarga. Anda dapat menyiapkan Ayam Goreng Lengkuas menggunakan 16 bahan dan 6 tahap pembuatan. Berikut ini cara dalam membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam menyiapkan Ayam Goreng Lengkuas:

1. Gunakan 1 kg sayap ayam
1. Siapkan  Bahan Marinasi Ayam :
1. Ambil 1 sdm garam
1. Siapkan 1 buah jeruk ambil airnya / bisa di ganti cuka
1. Gunakan Secukupnya penyedap rasa
1. Gunakan  Bahan Lengkuas :
1. Ambil 120 gr lengkuas diparut
1. Siapkan 8 siung bawang putih (uleg)
1. Siapkan 50 ml air kelapa
1. Gunakan 1 butir telur
1. Sediakan 1 sdt kaldu bubuk ayam
1. Sediakan 1 sdt garam
1. Gunakan 2 ruas kunyit (uleg)
1. Gunakan 1 sdm margarin
1. Gunakan  Bahan Ungkep :
1. Gunakan 20 lembar daun salam




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Ayam Goreng Lengkuas:

1. Marinasi ayam nya dulu yaa, sebelumnya udah dicuci dulu. Diamkan ayam marinasi selama 1 jam simpan kulkas, setelah itu di ungkep sampe matang, nanti dia ngeluarin air sendiri abis itu tetep diungkep sampe air asat. Tips nya : siapkan wajan anti lengket, tata daun salam taruh ayam di atasnya lalu tutup lagi pakai daun salam nya
1. Siapkan bahan lengkuas..campur semua bahan ya..tuang sedikit2 air kelapa cukup sampe nyemek2 aja gitu
1. Tunggu ayam ungkep tadi dingin ya, baru di balurin ke bahan lengkuas, taruh dalam wadah simpan di kulkas minimal 1 jam biar bumbu meresap..abis itu goreng, jadi ini bisa di simpan ya, jadi sewaktu2 tinggal goreng deh😚
1. Serius ini enak bgt apalagi temennya nasi gurih..hhmmmm
1. Yummy 🤤
1. Selamat mencoba




Terima kasih telah menggunakan resep yang tim kami tampilkan di halaman ini. Harapan kami, olahan Ayam Goreng Lengkuas yang mudah di atas dapat membantu Anda menyiapkan hidangan yang sedap untuk keluarga/teman ataupun menjadi inspirasi dalam berjualan makanan. Selamat mencoba!
