---
description: "Bahan Ayam Kecap | Langkah Membuat Ayam Kecap Yang Enak Dan Lezat"
title: "Bahan Ayam Kecap | Langkah Membuat Ayam Kecap Yang Enak Dan Lezat"
slug: 376-bahan-ayam-kecap-langkah-membuat-ayam-kecap-yang-enak-dan-lezat
date: 2020-07-30T02:29:18.251Z
image: https://img-global.cpcdn.com/recipes/616e72fc7985f489/751x532cq70/ayam-kecap-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/616e72fc7985f489/751x532cq70/ayam-kecap-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/616e72fc7985f489/751x532cq70/ayam-kecap-foto-resep-utama.jpg
author: Mario Hansen
ratingvalue: 5
reviewcount: 5
recipeingredient:
- "3 potong ayam bagian paha"
- "2 siung bawang putih"
- "2 siung bawang merah karena gada bawang bombay jd aku ganti pakai ini"
- " merica bubuk"
- " air perasan jeruk nipis"
- " garam"
- " kaldu ayam bubuk"
- "1 sdm saus tiram"
- "4 sdm kecap manis"
- "200 cc air matang"
- "secukupnya minyak goreng  margarin"
- "irisan daun bawang"
- "1 buah kentang iris kotak"
recipeinstructions:
- "Siapkan ayam, cuci bersih laku lumuri dengan air perasan jeruk nipis dan bumbui sedikit garam merica, tunggu -+ 15 menit. potong kentang juga ya"
- "Angkat ayam dan tiriskan. lalu cincang bawang putih dan bawang merah. ambil sedikit minyak/margarin lalu tumis sampai harum"
- "Masukkan ayam, kentang, dan air. lalu bumbui dan tunggu sampai mendidih. jangan lupa koreksi rasa setelah itu ditunggu sampai air menyusut ya lalu siap dihidangkan beri taburan irisan daun bawang"
categories:
- Resep
tags:
- ayam
- kecap

katakunci: ayam kecap 
nutrition: 150 calories
recipecuisine: Indonesian
preptime: "PT16M"
cooktime: "PT37M"
recipeyield: "2"
recipecategory: Dessert

---


![Ayam Kecap](https://img-global.cpcdn.com/recipes/616e72fc7985f489/751x532cq70/ayam-kecap-foto-resep-utama.jpg)


ayam kecap ini yaitu santapan tanah air yang ekslusif dan perlu untuk kita coba. Cita rasanya yang mantap membuat siapa pun menantikan kehadirannya di meja makan.
Bunda Sedang mencari ide resep ayam kecap untuk jualan atau dikonsumsi sendiri yang Enak Dan Mudah? Cara membuatnya memang tidak susah dan tidak juga mudah. apabila keliru mengolah maka hasilnya akan hambar dan bahkan tidak sedap. Padahal ayam kecap yang enak selayaknya mempunyai aroma dan rasa yang bisa memancing selera kita.

Banyak hal yang sedikit banyak mempengaruhi kualitas rasa dari ayam kecap, pertama dari jenis bahan, lalu pemilihan bahan segar, sampai cara mengolah dan menyajikannya. Tak perlu pusing jika hendak menyiapkan ayam kecap enak di rumah, karena asal sudah tahu triknya maka hidangan ini mampu menjadi suguhan spesial.




Nah, kali ini kita coba, yuk, siapkan ayam kecap sendiri di rumah. Tetap berbahan sederhana, sajian ini bisa memberi manfaat dalam membantu menjaga kesehatan tubuhmu sekeluarga. Anda bisa membuat Ayam Kecap memakai 13 jenis bahan dan 3 tahap pembuatan. Berikut ini langkah-langkah untuk menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam menyiapkan Ayam Kecap:

1. Sediakan 3 potong ayam bagian paha
1. Siapkan 2 siung bawang putih
1. Ambil 2 siung bawang merah, karena gada bawang bombay jd aku ganti pakai ini
1. Gunakan  merica bubuk
1. Siapkan  air perasan jeruk nipis
1. Ambil  garam
1. Ambil  kaldu ayam bubuk
1. Gunakan 1 sdm saus tiram
1. Siapkan 4 sdm kecap manis
1. Sediakan 200 cc air matang
1. Siapkan secukupnya minyak goreng / margarin
1. Sediakan irisan daun bawang
1. Gunakan 1 buah kentang, iris kotak




<!--inarticleads2-->

##### Langkah-langkah membuat Ayam Kecap:

1. Siapkan ayam, cuci bersih laku lumuri dengan air perasan jeruk nipis dan bumbui sedikit garam merica, tunggu -+ 15 menit. potong kentang juga ya
1. Angkat ayam dan tiriskan. lalu cincang bawang putih dan bawang merah. ambil sedikit minyak/margarin lalu tumis sampai harum
1. Masukkan ayam, kentang, dan air. lalu bumbui dan tunggu sampai mendidih. jangan lupa koreksi rasa setelah itu ditunggu sampai air menyusut ya lalu siap dihidangkan beri taburan irisan daun bawang




Bagaimana? Mudah bukan? Itulah cara membuat ayam kecap yang bisa Anda praktikkan di rumah. Selamat mencoba!
