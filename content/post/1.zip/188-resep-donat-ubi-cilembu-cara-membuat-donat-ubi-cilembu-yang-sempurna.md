---
description: "Resep Donat Ubi Cilembu | Cara Membuat Donat Ubi Cilembu Yang Sempurna"
title: "Resep Donat Ubi Cilembu | Cara Membuat Donat Ubi Cilembu Yang Sempurna"
slug: 188-resep-donat-ubi-cilembu-cara-membuat-donat-ubi-cilembu-yang-sempurna
date: 2020-09-18T08:28:55.971Z
image: https://img-global.cpcdn.com/recipes/96b703de2bd4a617/751x532cq70/donat-ubi-cilembu-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/96b703de2bd4a617/751x532cq70/donat-ubi-cilembu-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/96b703de2bd4a617/751x532cq70/donat-ubi-cilembu-foto-resep-utama.jpg
author: Maurice Lucas
ratingvalue: 3.3
reviewcount: 8
recipeingredient:
- "200 gr ubi cilembu kukus lalu haluskan"
- "500 gr terigu protein tinggi"
- "2 butir telur"
- "6 sdm gula pasir"
- "1 sdm ragi instan"
- " 150ml susu hangat pakai air juga boleh"
- "80 gr margarin"
- "1/2 sdt garam"
recipeinstructions:
- "Masukkan tepung terigu, ubi yg sudah dihaluskan, telur, gula, ragi instan ke dalam wadah"
- "Masukkan air sedikit demi sedikit secara bertahap sambil diuleni, saya nguleninya pake mixer biar cepet😁"
- "Hentikan penggunaan air kalau dirasa udah cukup dan adonan udah enak diuleni, untuk adonan ini saya pake air sebanyak ±125ml"
- "Uleni sampai setengah kalis"
- "Setelah setengah kalis lalu masukkan margarin dan garam kemudian uleni lagi sampai kalis elastis, ini penting ya supaya hasil donatnya empuk, saya uleni pake mixer speed 3 selama ± 15 menit"
- "Setelah kalis elastis istirahatkan adonan selama 1 jam, atau sampai adonan mengembang 2X lipat"
- "Setelah mengembang kempiskan adonan dengan cara ditinju supaya udaranya keluar, kemudian bentuk adonan, setelah terbentuk semua diamkan lagi sekitar 30 menit"
- "Setelah itu donat siap digoreng di minyak panas dengan api kecil, goreng donat dengan sekali balik saja supaya tidak terlalu berminyak"
- "Setelah matang tiriskan dan donat siap dikasih topping sesuai selera"
categories:
- Resep
tags:
- donat
- ubi
- cilembu

katakunci: donat ubi cilembu 
nutrition: 157 calories
recipecuisine: Indonesian
preptime: "PT25M"
cooktime: "PT59M"
recipeyield: "3"
recipecategory: Dinner

---


![Donat Ubi Cilembu](https://img-global.cpcdn.com/recipes/96b703de2bd4a617/751x532cq70/donat-ubi-cilembu-foto-resep-utama.jpg)


donat ubi cilembu ini yaitu santapan tanah air yang ekslusif dan wajib untuk kita coba. Cita rasanya yang sedap membuat siapa pun menantikan kehadirannya di meja makan.
Bunda Sedang mencari ide resep donat ubi cilembu untuk jualan atau dikonsumsi sendiri yang Sempurna? Cara Memasaknya memang tidak susah dan tidak juga mudah. apabila keliru mengolah maka hasilnya tidak akan memuaskan dan bahkan tidak sedap. Padahal donat ubi cilembu yang enak harusnya sih mempunyai aroma dan rasa yang bisa memancing selera kita.

Banyak hal yang sedikit banyak mempengaruhi kualitas rasa dari donat ubi cilembu, mulai dari jenis bahan, kemudian pemilihan bahan segar, hingga cara membuat dan menyajikannya. Tidak usah pusing jika ingin menyiapkan donat ubi cilembu yang enak di rumah, karena asal sudah tahu triknya maka hidangan ini mampu jadi suguhan istimewa.




Nah, kali ini kita coba, yuk, siapkan donat ubi cilembu sendiri di rumah. Tetap berbahan sederhana, sajian ini bisa memberi manfaat untuk membantu menjaga kesehatan tubuh kita. Anda dapat menyiapkan Donat Ubi Cilembu memakai 8 jenis bahan dan 9 tahap pembuatan. Berikut ini cara untuk menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam menyiapkan Donat Ubi Cilembu:

1. Ambil 200 gr ubi cilembu (kukus lalu haluskan)
1. Ambil 500 gr terigu protein tinggi
1. Gunakan 2 butir telur
1. Sediakan 6 sdm gula pasir
1. Ambil 1 sdm ragi instan
1. Siapkan  ±150ml susu hangat (pakai air juga boleh)
1. Ambil 80 gr margarin
1. Ambil 1/2 sdt garam




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Donat Ubi Cilembu:

1. Masukkan tepung terigu, ubi yg sudah dihaluskan, telur, gula, ragi instan ke dalam wadah
1. Masukkan air sedikit demi sedikit secara bertahap sambil diuleni, saya nguleninya pake mixer biar cepet😁
1. Hentikan penggunaan air kalau dirasa udah cukup dan adonan udah enak diuleni, untuk adonan ini saya pake air sebanyak ±125ml
1. Uleni sampai setengah kalis
1. Setelah setengah kalis lalu masukkan margarin dan garam kemudian uleni lagi sampai kalis elastis, ini penting ya supaya hasil donatnya empuk, saya uleni pake mixer speed 3 selama ± 15 menit
1. Setelah kalis elastis istirahatkan adonan selama 1 jam, atau sampai adonan mengembang 2X lipat
1. Setelah mengembang kempiskan adonan dengan cara ditinju supaya udaranya keluar, kemudian bentuk adonan, setelah terbentuk semua diamkan lagi sekitar 30 menit
1. Setelah itu donat siap digoreng di minyak panas dengan api kecil, goreng donat dengan sekali balik saja supaya tidak terlalu berminyak
1. Setelah matang tiriskan dan donat siap dikasih topping sesuai selera




Bagaimana? Gampang kan? Itulah cara membuat donat ubi cilembu yang bisa Anda praktikkan di rumah. Selamat mencoba!
