---
description: "Bumbu Gulai Ayam Pedas | Cara Membuat Gulai Ayam Pedas Yang Mudah Dan Praktis"
title: "Bumbu Gulai Ayam Pedas | Cara Membuat Gulai Ayam Pedas Yang Mudah Dan Praktis"
slug: 140-bumbu-gulai-ayam-pedas-cara-membuat-gulai-ayam-pedas-yang-mudah-dan-praktis
date: 2020-12-28T04:29:38.510Z
image: https://img-global.cpcdn.com/recipes/8c1a670c653e168e/751x532cq70/gulai-ayam-pedas-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/8c1a670c653e168e/751x532cq70/gulai-ayam-pedas-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/8c1a670c653e168e/751x532cq70/gulai-ayam-pedas-foto-resep-utama.jpg
author: Terry Goodman
ratingvalue: 5
reviewcount: 4
recipeingredient:
- " Ayam Me Bagian Paha Cincang Kecil"
- " Jeruk Nipis"
- " Bumbu halus"
- " Bawang Merah"
- " Bawang Putih"
- " Cabe Merah Keriting"
- " Cabe Rawit Merah"
- " Kunyit"
- " Jahe"
- " Ketumbar Sangrai"
- " Kemiri Sangrai"
- " Jintan"
- " Bumbum Utuh"
- " Daun Salam"
- " Daun Jeruk buang tulangnya"
- " Serai Geprek"
- " Lengkuas Geprek"
- " Asam Kandis ukuran Sedang"
- " Air"
- " Santan Kara 65ml"
- " Minyak secukupnya untuk menumis"
- " Garam"
- " Gula"
- " Kaldu Ayam Sesuai Selera"
recipeinstructions:
- "Cuci ayam sampai bersih, lalu kucuri dengan air perasan jeruk nipis. Diamkan selama 10 menit, lalu bilas kembali hingga bersih. Sisihkan"
- "Siapkan bumbu - bumbu. Baik yg dihaluskan dan yg utuh"
- "Tumis terlebih dahulu bumbu halus hingga harum, kemudian masukkan bumbu utuh dan masak hingga matang"
- "Setelah itu masukkan ayam yg sudah dibersihka. Tumis hingga bumbu tercampur rata dengan ayam. Kemudian tambahkan air + santan, aduk rata"
- "Kemudian masukkan garam + gula + kaldu ayam. Masak ayam hingga matang dan air sedikit menyusut."
- "Jika sudah matang, angkat dan siap disajikan. Selesai"
categories:
- Resep
tags:
- gulai
- ayam
- pedas

katakunci: gulai ayam pedas 
nutrition: 193 calories
recipecuisine: Indonesian
preptime: "PT17M"
cooktime: "PT36M"
recipeyield: "3"
recipecategory: Dinner

---


![Gulai Ayam Pedas](https://img-global.cpcdn.com/recipes/8c1a670c653e168e/751x532cq70/gulai-ayam-pedas-foto-resep-utama.jpg)


gulai ayam pedas ini yaitu makanan tanah air yang spesial dan wajib untuk kita coba. Cita rasanya yang sedap membuat siapa pun menantikan kehadirannya di meja makan.
Kamu Lagi mencari ide resep gulai ayam pedas untuk jualan atau dikonsumsi sendiri yang Enak Banget? Cara menyiapkannya memang tidak susah dan tidak juga mudah. seandainya keliru mengolah maka hasilnya akan hambar dan justru cenderung tidak enak. Padahal gulai ayam pedas yang enak harusnya sih mempunyai aroma dan rasa yang dapat memancing selera kita.

Ada beberapa hal yang sedikit banyak mempengaruhi kualitas rasa dari gulai ayam pedas, pertama dari jenis bahan, kemudian pemilihan bahan segar, sampai cara mengolah dan menyajikannya. Tak perlu pusing kalau mau menyiapkan gulai ayam pedas yang enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini mampu menjadi sajian spesial.




Nah, kali ini kita coba, yuk, buat gulai ayam pedas sendiri di rumah. Tetap dengan bahan sederhana, sajian ini bisa memberi manfaat dalam membantu menjaga kesehatan tubuh kita. Anda bisa membuat Gulai Ayam Pedas memakai 24 bahan dan 6 tahap pembuatan. Berikut ini langkah-langkah dalam menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk menyiapkan Gulai Ayam Pedas:

1. Sediakan  Ayam (Me Bagian Paha) Cincang Kecil
1. Siapkan  Jeruk Nipis
1. Gunakan  Bumbu halus
1. Ambil  Bawang Merah
1. Ambil  Bawang Putih
1. Siapkan  Cabe Merah Keriting
1. Siapkan  Cabe Rawit Merah
1. Ambil  Kunyit
1. Siapkan  Jahe
1. Gunakan  Ketumbar Sangrai
1. Ambil  Kemiri Sangrai
1. Sediakan  Jintan
1. Siapkan  Bumbum Utuh
1. Gunakan  Daun Salam
1. Sediakan  Daun Jeruk buang tulangnya
1. Siapkan  Serai Geprek
1. Ambil  Lengkuas Geprek
1. Ambil  Asam Kandis ukuran Sedang
1. Siapkan  Air
1. Siapkan  Santan Kara 65ml
1. Ambil  Minyak secukupnya untuk menumis
1. Ambil  Garam
1. Gunakan  Gula
1. Sediakan  Kaldu Ayam (Sesuai Selera)




<!--inarticleads2-->

##### Langkah-langkah membuat Gulai Ayam Pedas:

1. Cuci ayam sampai bersih, lalu kucuri dengan air perasan jeruk nipis. Diamkan selama 10 menit, lalu bilas kembali hingga bersih. Sisihkan
1. Siapkan bumbu - bumbu. Baik yg dihaluskan dan yg utuh
1. Tumis terlebih dahulu bumbu halus hingga harum, kemudian masukkan bumbu utuh dan masak hingga matang
1. Setelah itu masukkan ayam yg sudah dibersihka. Tumis hingga bumbu tercampur rata dengan ayam. Kemudian tambahkan air + santan, aduk rata
1. Kemudian masukkan garam + gula + kaldu ayam. Masak ayam hingga matang dan air sedikit menyusut.
1. Jika sudah matang, angkat dan siap disajikan. Selesai




Gimana nih? Mudah bukan? Itulah cara membuat gulai ayam pedas yang bisa Anda lakukan di rumah. Selamat mencoba!
