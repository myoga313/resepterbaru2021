---
description: "Resep masakan Nasi Kuning | Cara Membuat Nasi Kuning Yang Lezat"
title: "Resep masakan Nasi Kuning | Cara Membuat Nasi Kuning Yang Lezat"
slug: 105-resep-masakan-nasi-kuning-cara-membuat-nasi-kuning-yang-lezat
date: 2020-07-31T17:12:13.097Z
image: https://img-global.cpcdn.com/recipes/7c947f033d78daaa/751x532cq70/nasi-kuning-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/7c947f033d78daaa/751x532cq70/nasi-kuning-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/7c947f033d78daaa/751x532cq70/nasi-kuning-foto-resep-utama.jpg
author: Lillian Parks
ratingvalue: 4.4
reviewcount: 14
recipeingredient:
- " beras"
- " kunyit"
- " santan instan"
- " bawang putih"
- " daun jeruk"
- " daun salam"
- " serai"
- " Garam"
recipeinstructions:
- "Cuci beras hingga bersih, sisihkan."
- "Kupas kunyit, lalu bakar agar tidak bau langu. Setelah dibakar, blender kunyit dengan sedikit air."
- "Cincang halus bawang putih, lalu tumis dengan sedikit minyak hingga matang dan harum."
- "Saring kunyit yang telah diblender, kemudian tambahkan ke dalam tumisan bawang. Tambahkan air, lalu masukkan daun jeruk, daun salam, serai dan sedikit garam."
- "Setelah air mendidih, masukkan santan kental. Lalu tuang ke dalam panci yang berisi beras yang sudah dicuci. Masak hingga air menyusut."
- "Setelah air menyusut, kukus nasi dengan dandang hingga matang."
- "Sajikan dengan lauk pelengkap."
categories:
- Resep
tags:
- nasi
- kuning

katakunci: nasi kuning 
nutrition: 190 calories
recipecuisine: Indonesian
preptime: "PT15M"
cooktime: "PT48M"
recipeyield: "3"
recipecategory: Lunch

---


![Nasi Kuning](https://img-global.cpcdn.com/recipes/7c947f033d78daaa/751x532cq70/nasi-kuning-foto-resep-utama.jpg)


nasi kuning ini ialah santapan nusantara yang ekslusif dan perlu untuk kita coba. Cita rasanya yang mantap membuat siapa pun menantikan kehadirannya di meja makan.
Anda sedang mencari inspirasi resep nasi kuning untuk jualan atau dikonsumsi sendiri yang Lezat? Cara menyiapkannya memang tidak terlalu sulit namun tidak gampang juga. misalnya salah mengolah maka hasilnya tidak akan memuaskan dan justru cenderung tidak enak. Padahal nasi kuning yang enak selayaknya punya aroma dan cita rasa yang mampu memancing selera kita.



Ada beberapa hal yang sedikit banyak mempengaruhi kualitas rasa dari nasi kuning, mulai dari jenis bahan, kedua pemilihan bahan segar sampai cara mengolah dan menyajikannya. Tidak usah pusing jika ingin menyiapkan nasi kuning enak di rumah, karena asal sudah tahu triknya maka hidangan ini mampu menjadi sajian istimewa.


Di bawah ini ada beberapa cara mudah dan praktis untuk membuat nasi kuning yang siap dikreasikan. Anda bisa membuat Nasi Kuning menggunakan 8 jenis bahan dan 7 langkah pembuatan. Berikut ini langkah-langkah untuk membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk menyiapkan Nasi Kuning:

1. Siapkan  beras
1. Sediakan  kunyit
1. Ambil  santan instan
1. Gunakan  bawang putih
1. Sediakan  daun jeruk
1. Sediakan  daun salam
1. Ambil  serai
1. Gunakan  Garam




<!--inarticleads2-->

##### Cara membuat Nasi Kuning:

1. Cuci beras hingga bersih, sisihkan.
1. Kupas kunyit, lalu bakar agar tidak bau langu. Setelah dibakar, blender kunyit dengan sedikit air.
1. Cincang halus bawang putih, lalu tumis dengan sedikit minyak hingga matang dan harum.
1. Saring kunyit yang telah diblender, kemudian tambahkan ke dalam tumisan bawang. Tambahkan air, lalu masukkan daun jeruk, daun salam, serai dan sedikit garam.
1. Setelah air mendidih, masukkan santan kental. Lalu tuang ke dalam panci yang berisi beras yang sudah dicuci. Masak hingga air menyusut.
1. Setelah air menyusut, kukus nasi dengan dandang hingga matang.
1. Sajikan dengan lauk pelengkap.




Terima kasih telah menggunakan resep yang tim kami tampilkan di sini. Harapan kami, olahan Nasi Kuning yang mudah di atas dapat membantu Anda menyiapkan hidangan yang lezat untuk keluarga/teman maupun menjadi ide untuk berbisnis kuliner. Semoga bermanfaat dan selamat mencoba!
