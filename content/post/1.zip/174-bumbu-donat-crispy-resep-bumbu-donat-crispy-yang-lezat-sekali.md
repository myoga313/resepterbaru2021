---
description: "Bumbu Donat Crispy | Resep Bumbu Donat Crispy Yang Lezat Sekali"
title: "Bumbu Donat Crispy | Resep Bumbu Donat Crispy Yang Lezat Sekali"
slug: 174-bumbu-donat-crispy-resep-bumbu-donat-crispy-yang-lezat-sekali
date: 2020-10-02T14:00:22.873Z
image: https://img-global.cpcdn.com/recipes/240b3eb9aff5056f/751x532cq70/donat-crispy-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/240b3eb9aff5056f/751x532cq70/donat-crispy-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/240b3eb9aff5056f/751x532cq70/donat-crispy-foto-resep-utama.jpg
author: Jacob Strickland
ratingvalue: 4.7
reviewcount: 13
recipeingredient:
- " Bahan kering "
- "  400 gr tepung cakra"
- "  100 gr tepung maizena"
- "  1 bks 27 gr susu dancow bubuk"
- "  5gr 12 sdt bread improver opsional"
- " Bahan cair "
- "  150 gr 6 sdm gula pasir masukkan sebagian ke bahan kering"
- "  5 gr 12 bks ragi"
- "  120 ml air hangat"
- " 250 gr 2 btr ukuran sedang Kentang rebuskukus"
- " 2 butir telur"
- "  50 gr 2 sdm mentega putih bisa diganti margarine"
- "  8 gr 12 sdt garam"
recipeinstructions:
- "Siapkan bahan2nya."
- "Masukkan semua bahan kering dalam wadah yg cukup besar, aduk asal tercampur."
- "Campurkan sebagian gula pasir, ragi dan air hangat, aduk rata, biarkan hingga larut dan berbuih (kurleb 15 menit). Jika anda menggunakan ragi lama atau ragi sisa, ketika campuran sudah tidak berbuih, ganti ragi anda (buih menandakan ragi anda masih aktif). Masukkan sisa gula pasir ke bahan kering."
- "Haluskan kentang (saya : parut menggunakan parutan keju), tambahkan telur, aduk asal rata dengan whisk."
- "Campurkan bahan kering dengan air ragi. Aduk asal rata. Masukkan campuran kentang dan telur, uleni hingga kalis."
- "Tambahkan mentega dan garam, uleni lagi hingga kalis elastis."
- "Diamkan adonan hingga mengembang 2x lipat (kurleb 45-60 menit), tutup dengan kain lembab yang bersih."
- "Kempeskan adonan, bagi menjadi 32 bagian (saya lupa menimbangnya(. Bulat2kan adonan (jika anda punya cetakan donat, silakan pakai) hingga adonan habis (saat anda selesai membulatkan, adonan awal sudah mengembang lagi)."
- "Panaskan minyak, buat lubang pada tengah adonan yg agak besar (nanti akan mengecil saat adonan semakin besar saat digoreng), masukkan dalam minyak yang sudah panas, goreng dengan api sedang cenderung kecil hingga kecokelatan. Banyak tips yg mengatakan anda cukup 1x membalik agar tidak terlalu menyerap minyak,, saya coba menggoreng dengan beberapa kali balik, perbedaannya tidak terlalu banyak menurut saya."
- "Tiriskan adonan, akan lebih baik jika digantung."
- "Sajikan sesuai selera anda....happy cooking.."
categories:
- Resep
tags:
- donat
- crispy

katakunci: donat crispy 
nutrition: 232 calories
recipecuisine: Indonesian
preptime: "PT37M"
cooktime: "PT33M"
recipeyield: "4"
recipecategory: Dinner

---


![Donat Crispy](https://img-global.cpcdn.com/recipes/240b3eb9aff5056f/751x532cq70/donat-crispy-foto-resep-utama.jpg)


donat crispy ini ialah sajian nusantara yang spesial dan harus untuk kita coba. Cita rasanya yang nikmat membuat siapa pun menantikan kehadirannya di meja makan.
Anda sedang mencari ide resep donat crispy untuk jualan atau dikonsumsi sendiri yang Enak Dan Lezat? Cara Buatnya memang tidak susah dan tidak juga mudah. kalau keliru mengolah maka hasilnya Tidak Memuaskan dan justru cenderung tidak enak. Padahal donat crispy yang enak selayaknya mempunyai aroma dan rasa yang dapat memancing selera kita.



Banyak hal yang sedikit banyak mempengaruhi kualitas rasa dari donat crispy, mulai dari jenis bahan, lalu pemilihan bahan segar sampai cara mengolah dan menghidangkannya. Tak perlu pusing kalau mau menyiapkan donat crispy yang enak di rumah, karena asal sudah tahu triknya maka hidangan ini mampu jadi suguhan spesial.


Nah, kali ini kita coba, yuk, kreasikan donat crispy sendiri di rumah. Tetap dengan bahan sederhana, sajian ini bisa memberi manfaat dalam membantu menjaga kesehatan tubuh kita. Anda bisa menyiapkan Donat Crispy memakai 13 jenis bahan dan 11 tahap pembuatan. Berikut ini cara dalam membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam pembuatan Donat Crispy:

1. Siapkan  Bahan kering :
1. Sediakan  ☆ 400 gr tepung cakra
1. Ambil  ☆ 100 gr tepung maizena
1. Gunakan  ☆ 1 bks (27 gr) susu dancow bubuk
1. Siapkan  ☆ 5gr (1/2 sdt) bread improver (opsional)
1. Gunakan  Bahan cair :
1. Ambil  ♡ 150 gr (6 sdm) gula pasir (masukkan sebagian ke bahan kering)
1. Siapkan  ♡ 5 gr (1/2 bks) ragi
1. Siapkan  ♡ 120 ml air hangat
1. Ambil  ▪︎250 gr (2 btr ukuran sedang) Kentang, rebus/kukus
1. Gunakan  ▪︎2 butir telur
1. Gunakan  ~ 50 gr (2 sdm) mentega putih (bisa diganti margarine)
1. Siapkan  ~ 8 gr (1/2 sdt) garam




<!--inarticleads2-->

##### Cara membuat Donat Crispy:

1. Siapkan bahan2nya.
1. Masukkan semua bahan kering dalam wadah yg cukup besar, aduk asal tercampur.
1. Campurkan sebagian gula pasir, ragi dan air hangat, aduk rata, biarkan hingga larut dan berbuih (kurleb 15 menit). Jika anda menggunakan ragi lama atau ragi sisa, ketika campuran sudah tidak berbuih, ganti ragi anda (buih menandakan ragi anda masih aktif). Masukkan sisa gula pasir ke bahan kering.
1. Haluskan kentang (saya : parut menggunakan parutan keju), tambahkan telur, aduk asal rata dengan whisk.
1. Campurkan bahan kering dengan air ragi. Aduk asal rata. Masukkan campuran kentang dan telur, uleni hingga kalis.
1. Tambahkan mentega dan garam, uleni lagi hingga kalis elastis.
1. Diamkan adonan hingga mengembang 2x lipat (kurleb 45-60 menit), tutup dengan kain lembab yang bersih.
1. Kempeskan adonan, bagi menjadi 32 bagian (saya lupa menimbangnya(. Bulat2kan adonan (jika anda punya cetakan donat, silakan pakai) hingga adonan habis (saat anda selesai membulatkan, adonan awal sudah mengembang lagi).
1. Panaskan minyak, buat lubang pada tengah adonan yg agak besar (nanti akan mengecil saat adonan semakin besar saat digoreng), masukkan dalam minyak yang sudah panas, goreng dengan api sedang cenderung kecil hingga kecokelatan. Banyak tips yg mengatakan anda cukup 1x membalik agar tidak terlalu menyerap minyak,, saya coba menggoreng dengan beberapa kali balik, perbedaannya tidak terlalu banyak menurut saya.
1. Tiriskan adonan, akan lebih baik jika digantung.
1. Sajikan sesuai selera anda....happy cooking..




Terima kasih telah menggunakan resep yang tim kami tampilkan di sini. Besar harapan kami, olahan Donat Crispy yang mudah di atas dapat membantu Anda menyiapkan makanan yang sedap untuk keluarga/teman ataupun menjadi inspirasi untuk berbisnis kuliner. Selamat mencoba!
