---
description: "Resep masakan Bubur Sumsum Cendil (Santan Kara) | Resep Bumbu Bubur Sumsum Cendil (Santan Kara) Yang Enak Banget"
title: "Resep masakan Bubur Sumsum Cendil (Santan Kara) | Resep Bumbu Bubur Sumsum Cendil (Santan Kara) Yang Enak Banget"
slug: 9-resep-masakan-bubur-sumsum-cendil-santan-kara-resep-bumbu-bubur-sumsum-cendil-santan-kara-yang-enak-banget
date: 2020-08-18T18:30:17.829Z
image: https://img-global.cpcdn.com/recipes/d08f54ef01f6eda1/751x532cq70/bubur-sumsum-cendil-santan-kara-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/d08f54ef01f6eda1/751x532cq70/bubur-sumsum-cendil-santan-kara-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/d08f54ef01f6eda1/751x532cq70/bubur-sumsum-cendil-santan-kara-foto-resep-utama.jpg
author: Billy Campbell
ratingvalue: 4
reviewcount: 3
recipeingredient:
- " Bubur Sumsum"
- "10 sendok makan tepung beras"
- "800 ml air"
- "2 bungkus santan kara 65gr"
- "1 sendok teh garam"
- "1 lembar daun pandan"
- " Cendil"
- "10 sendok makan tepung ketan"
- "1/2 bungkus santan kara 65gr"
- "1/2 sendok teh garam"
- "Secukupnya air panas"
- "Secukupnya pewarna makanan warna sesuai selera"
- " Saus Kinca Gula Merah"
- "250 gr gula merah"
- "2 sendok makan gula putih sesuai selera"
- "1 sendok teh garam"
- "1 lembar daun pandan"
- "2 sendok makan tepung maizenasagu sesuai selera"
recipeinstructions:
- "Bubur Sumsum: Campur semua bahan, masak dengan api kecil, sambil terus diaduk. Tidak perlu dimasak hingga keras menggumpal, karena saat dingin akan menggumpal sendirinya."
- "Cendil: Campur semua bahan, masukan air sedikit demi sedikit, uleni hingga kalis (sampai bisa dibentuk bulat), masukan ke rebusan air yang sudah mendidih."
- "Saus Kinca (Gula Merah): Masukan semua bahan, masak hingga mendidih, sambil terus diaduk, tambahkan larutan tepung maizena/sagu untuk membuat sedikit kental (sesuai selera)."
categories:
- Resep
tags:
- bubur
- sumsum
- cendil

katakunci: bubur sumsum cendil 
nutrition: 203 calories
recipecuisine: Indonesian
preptime: "PT17M"
cooktime: "PT44M"
recipeyield: "1"
recipecategory: Lunch

---


![Bubur Sumsum Cendil (Santan Kara)](https://img-global.cpcdn.com/recipes/d08f54ef01f6eda1/751x532cq70/bubur-sumsum-cendil-santan-kara-foto-resep-utama.jpg)


bubur sumsum cendil (santan kara) ini merupakan kuliner nusantara yang mantap dan harus untuk kita coba. Cita rasanya yang enak membuat siapa pun menantikan kehadirannya di meja makan.
Sedang mencari ide resep bubur sumsum cendil (santan kara) untuk jualan atau dikonsumsi sendiri yang Lezat? Cara menyiapkannya memang susah-susah gampang. seumpama salah mengolah maka hasilnya Tidak Memuaskan dan justru cenderung tidak enak. Padahal bubur sumsum cendil (santan kara) yang enak harusnya sih memiliki aroma dan cita rasa yang mampu memancing selera kita.

Banyak hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari bubur sumsum cendil (santan kara), pertama dari jenis bahan, lalu pemilihan bahan segar, hingga cara membuat dan menghidangkannya. Tidak usah pusing kalau mau menyiapkan bubur sumsum cendil (santan kara) enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini dapat jadi sajian spesial.




Nah, kali ini kita coba, yuk, ciptakan bubur sumsum cendil (santan kara) sendiri di rumah. Tetap berbahan sederhana, hidangan ini dapat memberi manfaat dalam membantu menjaga kesehatan tubuh kita. Anda bisa membuat Bubur Sumsum Cendil (Santan Kara) memakai 18 jenis bahan dan 3 langkah pembuatan. Berikut ini cara dalam membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam menyiapkan Bubur Sumsum Cendil (Santan Kara):

1. Sediakan  Bubur Sumsum
1. Gunakan 10 sendok makan tepung beras
1. Gunakan 800 ml air
1. Sediakan 2 bungkus santan kara (@65gr)
1. Ambil 1 sendok teh garam
1. Ambil 1 lembar daun pandan
1. Sediakan  Cendil
1. Gunakan 10 sendok makan tepung ketan
1. Sediakan 1/2 bungkus santan kara (@65gr)
1. Ambil 1/2 sendok teh garam
1. Gunakan Secukupnya air panas
1. Siapkan Secukupnya pewarna makanan (warna sesuai selera)
1. Sediakan  Saus Kinca (Gula Merah)
1. Siapkan 250 gr gula merah
1. Sediakan 2 sendok makan gula putih (sesuai selera)
1. Gunakan 1 sendok teh garam
1. Gunakan 1 lembar daun pandan
1. Siapkan 2 sendok makan tepung maizena/sagu (sesuai selera)




<!--inarticleads2-->

##### Langkah-langkah membuat Bubur Sumsum Cendil (Santan Kara):

1. Bubur Sumsum: Campur semua bahan, masak dengan api kecil, sambil terus diaduk. Tidak perlu dimasak hingga keras menggumpal, karena saat dingin akan menggumpal sendirinya.
1. Cendil: Campur semua bahan, masukan air sedikit demi sedikit, uleni hingga kalis (sampai bisa dibentuk bulat), masukan ke rebusan air yang sudah mendidih.
1. Saus Kinca (Gula Merah): Masukan semua bahan, masak hingga mendidih, sambil terus diaduk, tambahkan larutan tepung maizena/sagu untuk membuat sedikit kental (sesuai selera).




Gimana nih? Gampang kan? Itulah cara membuat bubur sumsum cendil (santan kara) yang bisa Anda praktikkan di rumah. Selamat mencoba!
