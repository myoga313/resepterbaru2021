---
description: "Bumbu Ayam Goreng Krispi ala KFC | Langkah Membuat Ayam Goreng Krispi ala KFC Yang Sempurna"
title: "Bumbu Ayam Goreng Krispi ala KFC | Langkah Membuat Ayam Goreng Krispi ala KFC Yang Sempurna"
slug: 255-bumbu-ayam-goreng-krispi-ala-kfc-langkah-membuat-ayam-goreng-krispi-ala-kfc-yang-sempurna
date: 2020-08-29T18:09:26.437Z
image: https://img-global.cpcdn.com/recipes/c74404b195bf3685/751x532cq70/ayam-goreng-krispi-ala-kfc-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/c74404b195bf3685/751x532cq70/ayam-goreng-krispi-ala-kfc-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/c74404b195bf3685/751x532cq70/ayam-goreng-krispi-ala-kfc-foto-resep-utama.jpg
author: Ida Weber
ratingvalue: 3.3
reviewcount: 14
recipeingredient:
- " Bahan marinasi ayam"
- " dada ayam buang tulang dibagi 5 bagian memanjang"
- " bumbu marinasi ayam desaku"
- " merica bubuk"
- " Bahan tepung kering"
- " tepung terigu protein sedang"
- " tepung tapioka"
- " garam"
- " merica bubuk"
- " baking powder"
- " Bahan pelapis"
- " Ambil 5 sdm dari campuran tepung kering"
- " air"
recipeinstructions:
- "Marinasi ayam. Diamkan dalam kulkas bawah 2 jam (saya setengah hari). Jika tidak menemukan bumbu marinasi ayam, bisa diganti bumbu racik ayam goreng."
- "Buat adonan tepung kering. Campur rata. Ambil 5 sdm dan campur dengan air untuk mendapatkan adonan pelapis."
- "Ambil ayam yg sudah dimarinasi. Gulingkan di adonan basah, kemudian di adonan kering sambil dicubit2. Lakukan sampai selesai."
- "Jika ada sisa adonan, lapisi ayam sekali lagi jadi menghasilkan tepung yg tebal. Cara sama dengan langkah nomor 3."
- "Goreng dengan minyak yg panas (hampir berasap) api kecil saja sehingga tidak mudah gosong. Goreng sampai ayam matang bewarna kuning kecokelatan di kedua sisi. Tanda jika sudah matang, minyak tidak mengeluarkan busa lagi (sudah jernih). Angkat dan tiriskan."
- "Sajikan dengan nasi putih hangat, saus sambal dan saus tomat. Selamat mencoba 😀"
categories:
- Resep
tags:
- ayam
- goreng
- krispi

katakunci: ayam goreng krispi 
nutrition: 151 calories
recipecuisine: Indonesian
preptime: "PT17M"
cooktime: "PT34M"
recipeyield: "1"
recipecategory: Lunch

---


![Ayam Goreng Krispi ala KFC](https://img-global.cpcdn.com/recipes/c74404b195bf3685/751x532cq70/ayam-goreng-krispi-ala-kfc-foto-resep-utama.jpg)


ayam goreng krispi ala kfc ini merupakan sajian nusantara yang istimewa dan harus untuk kita coba. Cita rasanya yang enak membuat siapa pun menantikan kehadirannya di meja makan.
Sedang mencari inspirasi resep ayam goreng krispi ala kfc untuk jualan atau dikonsumsi sendiri yang Sedap? Cara menyiapkannya memang tidak susah dan tidak juga mudah. misalnya salah mengolah maka hasilnya Tidak Memuaskan dan bahkan tidak sedap. Padahal ayam goreng krispi ala kfc yang enak harusnya sih mempunyai aroma dan cita rasa yang mampu memancing selera kita.



Ada beberapa hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari ayam goreng krispi ala kfc, mulai dari jenis bahan, kedua pemilihan bahan segar hingga cara mengolah dan menyajikannya. Tak perlu pusing kalau mau menyiapkan ayam goreng krispi ala kfc enak di rumah, karena asal sudah tahu triknya maka hidangan ini dapat jadi suguhan istimewa.


Nah, kali ini kita coba, yuk, buat ayam goreng krispi ala kfc sendiri di rumah. Tetap dengan bahan sederhana, hidangan ini bisa memberi manfaat dalam membantu menjaga kesehatan tubuh kita. Anda dapat menyiapkan Ayam Goreng Krispi ala KFC memakai 13 bahan dan 6 langkah pembuatan. Berikut ini cara dalam membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk menyiapkan Ayam Goreng Krispi ala KFC:

1. Siapkan  Bahan marinasi ayam
1. Gunakan  dada ayam (buang tulang, dibagi 5 bagian memanjang)
1. Siapkan  bumbu marinasi ayam desaku
1. Gunakan  merica bubuk
1. Sediakan  Bahan tepung kering
1. Siapkan  tepung terigu protein sedang
1. Siapkan  tepung tapioka
1. Gunakan  garam
1. Sediakan  merica bubuk
1. Sediakan  baking powder
1. Sediakan  Bahan pelapis
1. Sediakan  Ambil 5 sdm dari campuran tepung kering
1. Ambil  air




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Ayam Goreng Krispi ala KFC:

1. Marinasi ayam. Diamkan dalam kulkas bawah 2 jam (saya setengah hari). Jika tidak menemukan bumbu marinasi ayam, bisa diganti bumbu racik ayam goreng.
1. Buat adonan tepung kering. Campur rata. Ambil 5 sdm dan campur dengan air untuk mendapatkan adonan pelapis.
1. Ambil ayam yg sudah dimarinasi. Gulingkan di adonan basah, kemudian di adonan kering sambil dicubit2. Lakukan sampai selesai.
1. Jika ada sisa adonan, lapisi ayam sekali lagi jadi menghasilkan tepung yg tebal. Cara sama dengan langkah nomor 3.
1. Goreng dengan minyak yg panas (hampir berasap) api kecil saja sehingga tidak mudah gosong. Goreng sampai ayam matang bewarna kuning kecokelatan di kedua sisi. Tanda jika sudah matang, minyak tidak mengeluarkan busa lagi (sudah jernih). Angkat dan tiriskan.
1. Sajikan dengan nasi putih hangat, saus sambal dan saus tomat. Selamat mencoba 😀




Terima kasih telah menggunakan resep yang kami tampilkan di sini. Besar harapan kami, olahan Ayam Goreng Krispi ala KFC yang mudah di atas dapat membantu Anda menyiapkan makanan yang sedap untuk keluarga/teman ataupun menjadi inspirasi dalam berbisnis kuliner. Selamat mencoba!
