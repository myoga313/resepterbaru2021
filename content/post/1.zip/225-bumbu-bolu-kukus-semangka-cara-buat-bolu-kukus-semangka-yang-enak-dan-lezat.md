---
description: "Bumbu Bolu Kukus Semangka | Cara Buat Bolu Kukus Semangka Yang Enak Dan Lezat"
title: "Bumbu Bolu Kukus Semangka | Cara Buat Bolu Kukus Semangka Yang Enak Dan Lezat"
slug: 225-bumbu-bolu-kukus-semangka-cara-buat-bolu-kukus-semangka-yang-enak-dan-lezat
date: 2020-10-31T11:27:30.404Z
image: https://img-global.cpcdn.com/recipes/8af05f5b1da6cb4f/751x532cq70/bolu-kukus-semangka-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/8af05f5b1da6cb4f/751x532cq70/bolu-kukus-semangka-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/8af05f5b1da6cb4f/751x532cq70/bolu-kukus-semangka-foto-resep-utama.jpg
author: Gussie Klein
ratingvalue: 5
reviewcount: 5
recipeingredient:
- " telur"
- " gula pasir"
- " SP"
- " garam"
- " vanili bubuk"
- " tepung terigu"
- " susu uht plain resep asli  santan"
- " minyak goreng baru"
- " Meises"
- " Pewarna makanan hijau dan merah"
recipeinstructions:
- "Mixer telur, gula, garam, vanili dan SP sampai kental, putih berjejak. Tambahkan tepung terigu yang telah diayak. Mixer dengan kecepatan rendah asal rata saja. Masukkan susu dan minyak. Mixer asal rata saja."
- "Bagi adonan menjadi 3 warna hijau untuk kulit semangka, putih untuk daging semangka, dan merah untuk daging semangka yang manis. Untuk warna putih dan hijau cukup sedikit saja. Untuk warna merah, bisa dicampur Meises sebagai biji. Kemudian aduk balik dengan spatula (Gambar terakhir pakai Blitz motonya jadi warna kurang jelas)."
- "Siapkan kukusan dengan tutup yang diberi serbet agar air tidak menetes. Setelah panas. Masukkan loyang yang telah dioles minyak, tuang warna hijau. Tutup selama 5 menit. Tuang warna putih. Tutup lagi 5 menit. Yang terakhir tuang warna merah masak selama 15 menit. Angkat setelah matang dinginkan."
- "Siap dipotong-potong dan disajikan."
categories:
- Resep
tags:
- bolu
- kukus
- semangka

katakunci: bolu kukus semangka 
nutrition: 149 calories
recipecuisine: Indonesian
preptime: "PT27M"
cooktime: "PT55M"
recipeyield: "1"
recipecategory: Dinner

---


![Bolu Kukus Semangka](https://img-global.cpcdn.com/recipes/8af05f5b1da6cb4f/751x532cq70/bolu-kukus-semangka-foto-resep-utama.jpg)


bolu kukus semangka ini yakni kuliner nusantara yang khas dan wajib untuk kita coba. Cita rasanya yang sedap membuat siapa pun menantikan kehadirannya di meja makan.
Sedang mencari ide resep bolu kukus semangka untuk jualan atau dikonsumsi sendiri yang Bikin Ngiler? Cara Bikinnya memang tidak susah dan tidak juga mudah. kalau keliru mengolah maka hasilnya Tidak Memuaskan dan justru cenderung tidak enak. Padahal bolu kukus semangka yang enak selayaknya memiliki aroma dan cita rasa yang mampu memancing selera kita.



Ada beberapa hal yang sedikit banyak mempengaruhi kualitas rasa dari bolu kukus semangka, pertama dari jenis bahan, lalu pemilihan bahan segar sampai cara membuat dan menyajikannya. Tak perlu pusing jika ingin menyiapkan bolu kukus semangka yang enak di rumah, karena asal sudah tahu triknya maka hidangan ini bisa menjadi suguhan spesial.


Nah, kali ini kita coba, yuk, kreasikan bolu kukus semangka sendiri di rumah. Tetap berbahan sederhana, hidangan ini dapat memberi manfaat dalam membantu menjaga kesehatan tubuh kita. Anda bisa menyiapkan Bolu Kukus Semangka menggunakan 10 bahan dan 4 langkah pembuatan. Berikut ini cara untuk menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk pembuatan Bolu Kukus Semangka:

1. Ambil  telur
1. Gunakan  gula pasir
1. Siapkan  SP
1. Ambil  garam
1. Sediakan  vanili bubuk
1. Gunakan  tepung terigu
1. Gunakan  susu uht plain (resep asli : santan)
1. Siapkan  minyak goreng baru
1. Siapkan  Meises
1. Siapkan  Pewarna makanan: hijau dan merah




<!--inarticleads2-->

##### Cara membuat Bolu Kukus Semangka:

1. Mixer telur, gula, garam, vanili dan SP sampai kental, putih berjejak. Tambahkan tepung terigu yang telah diayak. Mixer dengan kecepatan rendah asal rata saja. Masukkan susu dan minyak. Mixer asal rata saja.
1. Bagi adonan menjadi 3 warna hijau untuk kulit semangka, putih untuk daging semangka, dan merah untuk daging semangka yang manis. Untuk warna putih dan hijau cukup sedikit saja. Untuk warna merah, bisa dicampur Meises sebagai biji. Kemudian aduk balik dengan spatula (Gambar terakhir pakai Blitz motonya jadi warna kurang jelas).
1. Siapkan kukusan dengan tutup yang diberi serbet agar air tidak menetes. Setelah panas. Masukkan loyang yang telah dioles minyak, tuang warna hijau. Tutup selama 5 menit. Tuang warna putih. Tutup lagi 5 menit. Yang terakhir tuang warna merah masak selama 15 menit. Angkat setelah matang dinginkan.
1. Siap dipotong-potong dan disajikan.




Terima kasih telah membaca resep yang tim kami tampilkan di halaman ini. Harapan kami, olahan Bolu Kukus Semangka yang mudah di atas dapat membantu Anda menyiapkan makanan yang menarik untuk keluarga/teman ataupun menjadi inspirasi bagi Anda yang berkeinginan untuk berbisnis kuliner. Semoga bermanfaat dan selamat mencoba!
