---
description: "Bumbu Soto Ayam Khas Medan | Resep Bumbu Soto Ayam Khas Medan Yang Lezat"
title: "Bumbu Soto Ayam Khas Medan | Resep Bumbu Soto Ayam Khas Medan Yang Lezat"
slug: 409-bumbu-soto-ayam-khas-medan-resep-bumbu-soto-ayam-khas-medan-yang-lezat
date: 2020-09-04T23:23:50.842Z
image: https://img-global.cpcdn.com/recipes/1a92c8cbcaab2a48/751x532cq70/soto-ayam-khas-medan-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/1a92c8cbcaab2a48/751x532cq70/soto-ayam-khas-medan-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/1a92c8cbcaab2a48/751x532cq70/soto-ayam-khas-medan-foto-resep-utama.jpg
author: Justin McGuire
ratingvalue: 4.8
reviewcount: 6
recipeingredient:
- " ayam"
- " Santan kental"
- " Air untuk merebus ayam"
- " Bumbu halus "
- " Bawang merah"
- " Bawang putih"
- " kunyit"
- " jahe"
- " cabai keriting"
- " Bumbu rempah "
- " lengkuas geprek"
- " serai geprek"
- " kapulaga"
- " pala rendam beberapa menit lalu geprekdi haluskan"
- " bunga Lawang"
- " cengkeh"
- " kulit manis"
- " Daun salam"
- " Daun jeruk"
- " Tomat iris"
- " daun bawang iris"
- " Garam"
- " merica"
- " Penyedap"
- " Bahan pelengkap"
- " Tauge di kukus atau di siram air panas hingga setengah matang"
- " Telur rebus"
- " Kubis di kukus atau di siram air panas hingga setengah matang"
- " Mie hun yang sudah di rendam air panas hingga lunak"
- " Kerupuk merah putih"
- " Jeruk nipis"
- " Sambal"
recipeinstructions:
- "Potong ayam menjadi 4 bagian jika ayamnya masih utuh, kemudian cuci dan beri perasan air jeruk nipis dan garam lalu biarkan 5 menit kemudian bilas kembali hingga bersih dan sisihkan."
- "Didihkan air, lalu masukkan ayam bersama daun salam, lengkuas, serai, merica, cengkeh, kapulaga, bunga Lawang, kulit manis, pala yang sudah di geprek, penyedap, dan juga garam.  Lalu masak ayam hingga benar-benar empuk."
- "Sementara ayam di rebus, blender semua bumbu-bumbu yang akan di haluskan. Lalu tumis bersama daun jeruk dengan sedikit minyak goreng."
- "Setelah ayam benar-benar empuk, keluarkan ayam dari dalam panci lalu sisihkan. Kemudian masukkan bumbu halus yang sudah di tumis sebelumnya dan biarkan hingga mendidih hingga 5 menit."
- "Kemudian masukkan santan dan tetap di aduk agar santan tidak pecah.  Lakukan hingga santan terlihat mengembang kira-kira 10 menit dan terakhir masukkan tomat juga daun bawang yang sudah di iris, dan biarkan mendidih sebentar saja lalu matikan kompor."
- "Kemudian untuk ayam yang sebelumnya sudah di masak, goreng ayam sebentar saja dalam minyak panas lalu angkat. Setelah dingin pisahkan daging ayam dari tulang,kemudian sisihkan."
- "Terakhir, tata semua bahan pelengkap dalam mangkuk seperti mie hun, tauge, kubis, telur rebus, ayam suwir lalu siram dengan kuah soto. Lalu taburi dengan bawang goreng, daun sup serta perasan jeruk nipis dan juga sambal. Kalau mau lebih lengkap boleh buat pergedel kentang agar lebih nikmat 🤗"
categories:
- Resep
tags:
- soto
- ayam
- khas

katakunci: soto ayam khas 
nutrition: 201 calories
recipecuisine: Indonesian
preptime: "PT20M"
cooktime: "PT34M"
recipeyield: "2"
recipecategory: Lunch

---


![Soto Ayam Khas Medan](https://img-global.cpcdn.com/recipes/1a92c8cbcaab2a48/751x532cq70/soto-ayam-khas-medan-foto-resep-utama.jpg)


soto ayam khas medan ini yaitu sajian nusantara yang enak dan wajib untuk kita coba. Cita rasanya yang mantap membuat siapa pun menantikan kehadirannya di meja makan.
Kamu Lagi mencari inspirasi resep soto ayam khas medan untuk jualan atau dikonsumsi sendiri yang Mudah Dan Praktis? Cara membuatnya memang susah-susah gampang. sekiranya keliru mengolah maka hasilnya Tidak Memuaskan dan bahkan tidak sedap. Padahal soto ayam khas medan yang enak seharusnya mempunyai aroma dan cita rasa yang dapat memancing selera kita.

Banyak hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari soto ayam khas medan, pertama dari jenis bahan, kemudian pemilihan bahan segar, sampai cara membuat dan menyajikannya. Tak perlu pusing jika hendak menyiapkan soto ayam khas medan enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini mampu jadi suguhan spesial.




Berikut ini ada beberapa cara mudah dan praktis untuk membuat soto ayam khas medan yang siap dikreasikan. Anda bisa membuat Soto Ayam Khas Medan memakai 32 jenis bahan dan 7 tahap pembuatan. Berikut ini langkah-langkah dalam membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk pembuatan Soto Ayam Khas Medan:

1. Gunakan  ayam
1. Sediakan  Santan kental
1. Siapkan  Air untuk merebus ayam
1. Gunakan  Bumbu halus :
1. Gunakan  Bawang merah
1. Ambil  Bawang putih
1. Ambil  kunyit
1. Gunakan  jahe
1. Sediakan  cabai keriting
1. Sediakan  Bumbu rempah :
1. Ambil  lengkuas (geprek)
1. Gunakan  serai (geprek)
1. Ambil  kapulaga
1. Siapkan  pala (rendam beberapa menit lalu geprek/di haluskan)
1. Siapkan  bunga Lawang
1. Gunakan  cengkeh
1. Ambil  kulit manis
1. Siapkan  Daun salam
1. Sediakan  Daun jeruk
1. Gunakan  Tomat iris
1. Siapkan  daun bawang iris
1. Gunakan  Garam
1. Siapkan  merica
1. Siapkan  Penyedap
1. Gunakan  Bahan pelengkap:
1. Siapkan  Tauge di kukus atau di siram air panas hingga setengah matang
1. Siapkan  Telur rebus
1. Sediakan  Kubis di kukus atau di siram air panas hingga setengah matang
1. Siapkan  Mie hun yang sudah di rendam air panas hingga lunak
1. Siapkan  Kerupuk merah putih
1. Sediakan  Jeruk nipis
1. Ambil  Sambal




<!--inarticleads2-->

##### Langkah-langkah membuat Soto Ayam Khas Medan:

1. Potong ayam menjadi 4 bagian jika ayamnya masih utuh, kemudian cuci dan beri perasan air jeruk nipis dan garam lalu biarkan 5 menit kemudian bilas kembali hingga bersih dan sisihkan.
1. Didihkan air, lalu masukkan ayam bersama daun salam, lengkuas, serai, merica, cengkeh, kapulaga, bunga Lawang, kulit manis, pala yang sudah di geprek, penyedap, dan juga garam.  - Lalu masak ayam hingga benar-benar empuk.
1. Sementara ayam di rebus, blender semua bumbu-bumbu yang akan di haluskan. Lalu tumis bersama daun jeruk dengan sedikit minyak goreng.
1. Setelah ayam benar-benar empuk, keluarkan ayam dari dalam panci lalu sisihkan. Kemudian masukkan bumbu halus yang sudah di tumis sebelumnya dan biarkan hingga mendidih hingga 5 menit.
1. Kemudian masukkan santan dan tetap di aduk agar santan tidak pecah.  - Lakukan hingga santan terlihat mengembang kira-kira 10 menit dan terakhir masukkan tomat juga daun bawang yang sudah di iris, dan biarkan mendidih sebentar saja lalu matikan kompor.
1. Kemudian untuk ayam yang sebelumnya sudah di masak, goreng ayam sebentar saja dalam minyak panas lalu angkat. Setelah dingin pisahkan daging ayam dari tulang,kemudian sisihkan.
1. Terakhir, tata semua bahan pelengkap dalam mangkuk seperti mie hun, tauge, kubis, telur rebus, ayam suwir lalu siram dengan kuah soto. Lalu taburi dengan bawang goreng, daun sup serta perasan jeruk nipis dan juga sambal. - Kalau mau lebih lengkap boleh buat pergedel kentang agar lebih nikmat 🤗




Gimana nih? Gampang kan? Itulah cara membuat soto ayam khas medan yang bisa Anda lakukan di rumah. Semoga bermanfaat dan selamat mencoba!
