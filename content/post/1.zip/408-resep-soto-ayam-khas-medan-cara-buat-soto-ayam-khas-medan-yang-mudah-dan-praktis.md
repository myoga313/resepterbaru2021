---
description: "Resep Soto Ayam Khas Medan | Cara Buat Soto Ayam Khas Medan Yang Mudah Dan Praktis"
title: "Resep Soto Ayam Khas Medan | Cara Buat Soto Ayam Khas Medan Yang Mudah Dan Praktis"
slug: 408-resep-soto-ayam-khas-medan-cara-buat-soto-ayam-khas-medan-yang-mudah-dan-praktis
date: 2020-07-27T02:14:04.654Z
image: https://img-global.cpcdn.com/recipes/1a92c8cbcaab2a48/751x532cq70/soto-ayam-khas-medan-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/1a92c8cbcaab2a48/751x532cq70/soto-ayam-khas-medan-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/1a92c8cbcaab2a48/751x532cq70/soto-ayam-khas-medan-foto-resep-utama.jpg
author: Celia Estrada
ratingvalue: 4
reviewcount: 7
recipeingredient:
- "1 kg ayam"
- "1/2 liter Santan kental"
- "1.2 liter Air untuk merebus ayam"
- " Bumbu halus "
- "30 gr Bawang merah"
- "5 siung Bawang putih"
- "2 ruas kunyit"
- "2 ruas jahe"
- "3 buah cabai keriting"
- " Bumbu rempah "
- "5 cm lengkuas geprek"
- "3 batang serai geprek"
- "4 buah kapulaga"
- "1/2 buah pala rendam beberapa menit lalu geprekdi haluskan"
- "3 buah bunga Lawang"
- "5 buah cengkeh"
- "5 cm kulit manis"
- "3 lembar Daun salam"
- "7 lembar Daun jeruk"
- "2 buah Tomat iris"
- "2 batang daun bawang iris"
- "Secukupnya Garam"
- "Secukupnya merica"
- "Secukupnya Penyedap"
- " Bahan pelengkap"
- " Tauge di kukus atau di siram air panas hingga setengah matang"
- " Telur rebus"
- " Kubis di kukus atau di siram air panas hingga setengah matang"
- " Mie hun yang sudah di rendam air panas hingga lunak"
- " Kerupuk merah putih"
- " Jeruk nipis"
- " Sambal"
recipeinstructions:
- "Potong ayam menjadi 4 bagian jika ayamnya masih utuh, kemudian cuci dan beri perasan air jeruk nipis dan garam lalu biarkan 5 menit kemudian bilas kembali hingga bersih dan sisihkan."
- "Didihkan air, lalu masukkan ayam bersama daun salam, lengkuas, serai, merica, cengkeh, kapulaga, bunga Lawang, kulit manis, pala yang sudah di geprek, penyedap, dan juga garam.  Lalu masak ayam hingga benar-benar empuk."
- "Sementara ayam di rebus, blender semua bumbu-bumbu yang akan di haluskan. Lalu tumis bersama daun jeruk dengan sedikit minyak goreng."
- "Setelah ayam benar-benar empuk, keluarkan ayam dari dalam panci lalu sisihkan. Kemudian masukkan bumbu halus yang sudah di tumis sebelumnya dan biarkan hingga mendidih hingga 5 menit."
- "Kemudian masukkan santan dan tetap di aduk agar santan tidak pecah.  Lakukan hingga santan terlihat mengembang kira-kira 10 menit dan terakhir masukkan tomat juga daun bawang yang sudah di iris, dan biarkan mendidih sebentar saja lalu matikan kompor."
- "Kemudian untuk ayam yang sebelumnya sudah di masak, goreng ayam sebentar saja dalam minyak panas lalu angkat. Setelah dingin pisahkan daging ayam dari tulang,kemudian sisihkan."
- "Terakhir, tata semua bahan pelengkap dalam mangkuk seperti mie hun, tauge, kubis, telur rebus, ayam suwir lalu siram dengan kuah soto. Lalu taburi dengan bawang goreng, daun sup serta perasan jeruk nipis dan juga sambal. Kalau mau lebih lengkap boleh buat pergedel kentang agar lebih nikmat 🤗"
categories:
- Resep
tags:
- soto
- ayam
- khas

katakunci: soto ayam khas 
nutrition: 146 calories
recipecuisine: Indonesian
preptime: "PT32M"
cooktime: "PT47M"
recipeyield: "3"
recipecategory: Lunch

---


![Soto Ayam Khas Medan](https://img-global.cpcdn.com/recipes/1a92c8cbcaab2a48/751x532cq70/soto-ayam-khas-medan-foto-resep-utama.jpg)


soto ayam khas medan ini yaitu hidangan tanah air yang mantap dan harus untuk kita coba. Cita rasanya yang sedap membuat siapa pun menantikan kehadirannya di meja makan.
Kamu Lagi mencari inspirasi resep soto ayam khas medan untuk jualan atau dikonsumsi sendiri yang Lezat? Cara Bikinnya memang tidak terlalu sulit namun tidak gampang juga. semisal salah mengolah maka hasilnya tidak akan memuaskan dan justru cenderung tidak enak. Padahal soto ayam khas medan yang enak seharusnya punya aroma dan cita rasa yang mampu memancing selera kita.



Ada beberapa hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari soto ayam khas medan, pertama dari jenis bahan, lalu pemilihan bahan segar sampai cara membuat dan menghidangkannya. Tak perlu pusing jika ingin menyiapkan soto ayam khas medan yang enak di rumah, karena asal sudah tahu triknya maka hidangan ini dapat menjadi suguhan spesial.


Di bawah ini ada beberapa cara mudah dan praktis dalam mengolah soto ayam khas medan yang siap dikreasikan. Anda bisa membuat Soto Ayam Khas Medan menggunakan 32 jenis bahan dan 7 tahap pembuatan. Berikut ini cara dalam menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk menyiapkan Soto Ayam Khas Medan:

1. Ambil 1 kg ayam
1. Ambil 1/2 liter Santan kental
1. Sediakan 1.2 liter Air untuk merebus ayam
1. Sediakan  Bumbu halus :
1. Ambil 30 gr Bawang merah
1. Gunakan 5 siung Bawang putih
1. Siapkan 2 ruas kunyit
1. Sediakan 2 ruas jahe
1. Gunakan 3 buah cabai keriting
1. Sediakan  Bumbu rempah :
1. Sediakan 5 cm lengkuas (geprek)
1. Ambil 3 batang serai (geprek)
1. Ambil 4 buah kapulaga
1. Ambil 1/2 buah pala (rendam beberapa menit lalu geprek/di haluskan)
1. Siapkan 3 buah bunga Lawang
1. Ambil 5 buah cengkeh
1. Siapkan 5 cm kulit manis
1. Gunakan 3 lembar Daun salam
1. Siapkan 7 lembar Daun jeruk
1. Siapkan 2 buah Tomat iris
1. Gunakan 2 batang daun bawang iris
1. Gunakan Secukupnya Garam
1. Gunakan Secukupnya merica
1. Ambil Secukupnya Penyedap
1. Sediakan  Bahan pelengkap:
1. Ambil  Tauge di kukus atau di siram air panas hingga setengah matang
1. Siapkan  Telur rebus
1. Siapkan  Kubis di kukus atau di siram air panas hingga setengah matang
1. Sediakan  Mie hun yang sudah di rendam air panas hingga lunak
1. Gunakan  Kerupuk merah putih
1. Sediakan  Jeruk nipis
1. Ambil  Sambal




<!--inarticleads2-->

##### Langkah-langkah membuat Soto Ayam Khas Medan:

1. Potong ayam menjadi 4 bagian jika ayamnya masih utuh, kemudian cuci dan beri perasan air jeruk nipis dan garam lalu biarkan 5 menit kemudian bilas kembali hingga bersih dan sisihkan.
1. Didihkan air, lalu masukkan ayam bersama daun salam, lengkuas, serai, merica, cengkeh, kapulaga, bunga Lawang, kulit manis, pala yang sudah di geprek, penyedap, dan juga garam.  - Lalu masak ayam hingga benar-benar empuk.
1. Sementara ayam di rebus, blender semua bumbu-bumbu yang akan di haluskan. Lalu tumis bersama daun jeruk dengan sedikit minyak goreng.
1. Setelah ayam benar-benar empuk, keluarkan ayam dari dalam panci lalu sisihkan. Kemudian masukkan bumbu halus yang sudah di tumis sebelumnya dan biarkan hingga mendidih hingga 5 menit.
1. Kemudian masukkan santan dan tetap di aduk agar santan tidak pecah.  - Lakukan hingga santan terlihat mengembang kira-kira 10 menit dan terakhir masukkan tomat juga daun bawang yang sudah di iris, dan biarkan mendidih sebentar saja lalu matikan kompor.
1. Kemudian untuk ayam yang sebelumnya sudah di masak, goreng ayam sebentar saja dalam minyak panas lalu angkat. Setelah dingin pisahkan daging ayam dari tulang,kemudian sisihkan.
1. Terakhir, tata semua bahan pelengkap dalam mangkuk seperti mie hun, tauge, kubis, telur rebus, ayam suwir lalu siram dengan kuah soto. Lalu taburi dengan bawang goreng, daun sup serta perasan jeruk nipis dan juga sambal. - Kalau mau lebih lengkap boleh buat pergedel kentang agar lebih nikmat 🤗




Bagaimana? Gampang kan? Itulah cara membuat soto ayam khas medan yang bisa Anda praktikkan di rumah. Selamat mencoba!
