---
description: "Resep Donat gula pandan | Cara Bikin Donat gula pandan Yang Enak Dan Lezat"
title: "Resep Donat gula pandan | Cara Bikin Donat gula pandan Yang Enak Dan Lezat"
slug: 184-resep-donat-gula-pandan-cara-bikin-donat-gula-pandan-yang-enak-dan-lezat
date: 2020-11-01T07:53:56.600Z
image: https://img-global.cpcdn.com/recipes/58399b955a77e757/751x532cq70/donat-gula-pandan-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/58399b955a77e757/751x532cq70/donat-gula-pandan-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/58399b955a77e757/751x532cq70/donat-gula-pandan-foto-resep-utama.jpg
author: Florence Ruiz
ratingvalue: 3.1
reviewcount: 13
recipeingredient:
- " Bahan A"
- "250 grm tepung terigu protein sedang"
- "30 grm gula pasir"
- "2 butir kuning telur"
- "1 sdt fermipan"
- "1 bks Santan kara sachet"
- "130 ml air"
- " Pasta pandan secukup nya"
- " Bahan B"
- "1/4 garam"
- "30 gram margarin"
recipeinstructions:
- "Campur semua bahan A aduk hingga rata kemudian campurkan pasta pandan ke dalam santan (utk uk santan +air cukup 130 ml)"
- "Aduk hingga tercampur kemudian tmbhkan santan pandan sedikit demi sedikit hingga adonan kalis...kemudian masukkan bahan B dan aduk hingga lembut"
- "Setelah kalis adonan di bentuk bulat dan kemudian di diamkan selama 25 menit (tutup dengan serbet dan taburkan sedikit tepung)"
- "Setelah mengembang kemudian kita bentuk dengan cetakan donat..🍩🍩lalu kita goreng dengan api kecil ya..."
- "Taburi donat dengan toping yg kamu suka...🍽🍽🍩🍩selamat mencoba"
categories:
- Resep
tags:
- donat
- gula
- pandan

katakunci: donat gula pandan 
nutrition: 185 calories
recipecuisine: Indonesian
preptime: "PT35M"
cooktime: "PT40M"
recipeyield: "2"
recipecategory: Lunch

---


![Donat gula pandan](https://img-global.cpcdn.com/recipes/58399b955a77e757/751x532cq70/donat-gula-pandan-foto-resep-utama.jpg)


donat gula pandan ini yaitu suguhan tanah air yang lezat dan perlu untuk kita coba. Cita rasanya yang enak membuat siapa pun menantikan kehadirannya di meja makan.
Kamu Sedang mencari inspirasi resep donat gula pandan untuk jualan atau dikonsumsi sendiri yang Lezat? Cara membuatnya memang tidak terlalu sulit namun tidak gampang juga. seandainya keliru mengolah maka hasilnya akan hambar dan justru cenderung tidak enak. Padahal donat gula pandan yang enak selayaknya memiliki aroma dan cita rasa yang bisa memancing selera kita.

Banyak hal yang sedikit banyak mempengaruhi kualitas rasa dari donat gula pandan, pertama dari jenis bahan, lalu pemilihan bahan segar, sampai cara membuat dan menghidangkannya. Tidak usah pusing jika mau menyiapkan donat gula pandan yang enak di rumah, karena asal sudah tahu triknya maka hidangan ini mampu menjadi sajian istimewa.




Di bawah ini ada beberapa tips dan trik praktis yang dapat diterapkan untuk mengolah donat gula pandan yang siap dikreasikan. Anda bisa membuat Donat gula pandan menggunakan 11 bahan dan 5 langkah pembuatan. Berikut ini langkah-langkah untuk membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk menyiapkan Donat gula pandan:

1. Gunakan  Bahan A
1. Siapkan 250 grm tepung terigu (protein sedang)
1. Gunakan 30 grm gula pasir
1. Ambil 2 butir kuning telur
1. Siapkan 1 sdt fermipan
1. Gunakan 1 bks Santan kara sachet
1. Sediakan 130 ml air
1. Siapkan  Pasta pandan secukup nya
1. Sediakan  Bahan B
1. Gunakan 1/4 garam
1. Siapkan 30 gram margarin




<!--inarticleads2-->

##### Langkah-langkah membuat Donat gula pandan:

1. Campur semua bahan A aduk hingga rata kemudian campurkan pasta pandan ke dalam santan (utk uk santan +air cukup 130 ml)
1. Aduk hingga tercampur kemudian tmbhkan santan pandan sedikit demi sedikit hingga adonan kalis...kemudian masukkan bahan B dan aduk hingga lembut
1. Setelah kalis adonan di bentuk bulat dan kemudian di diamkan selama 25 menit (tutup dengan serbet dan taburkan sedikit tepung)
1. Setelah mengembang kemudian kita bentuk dengan cetakan donat..🍩🍩lalu kita goreng dengan api kecil ya...
1. Taburi donat dengan toping yg kamu suka...🍽🍽🍩🍩selamat mencoba




Terima kasih telah membaca resep yang tim kami tampilkan di sini. Besar harapan kami, olahan Donat gula pandan yang mudah di atas dapat membantu Anda menyiapkan makanan yang lezat untuk keluarga/teman ataupun menjadi inspirasi untuk berjualan makanan. Selamat mencoba!
