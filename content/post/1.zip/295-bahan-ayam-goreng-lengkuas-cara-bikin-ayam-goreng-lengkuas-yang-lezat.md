---
description: "Bahan Ayam Goreng Lengkuas | Cara Bikin Ayam Goreng Lengkuas Yang Lezat"
title: "Bahan Ayam Goreng Lengkuas | Cara Bikin Ayam Goreng Lengkuas Yang Lezat"
slug: 295-bahan-ayam-goreng-lengkuas-cara-bikin-ayam-goreng-lengkuas-yang-lezat
date: 2020-09-26T10:24:09.432Z
image: https://img-global.cpcdn.com/recipes/efa643597c022009/751x532cq70/ayam-goreng-lengkuas-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/efa643597c022009/751x532cq70/ayam-goreng-lengkuas-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/efa643597c022009/751x532cq70/ayam-goreng-lengkuas-foto-resep-utama.jpg
author: Shane Burton
ratingvalue: 4
reviewcount: 11
recipeingredient:
- "1 ekor ayam kampung"
- "3 laos besar parut"
- "2 batang serai"
- "4 daun salam"
- "4 daun jeruk"
- "600 ml air"
- "Secukupnya garam"
- "Secukupnya penyedap"
- "Secukupnya gula"
- " Bumbu Halus"
- "2 sdm ketumbar"
- "1 sdt merica"
- "6 siung bawang putih"
- "4 butir kemiri"
- "2 ruas jahe"
- "2 ruas kunyit"
recipeinstructions:
- "Bersihkan ayam, siapkan wajan beri sdikit minyak tumis bumbu halus, laos, kemudian masukan daun2 dan serai, tunggu hingga harum kemudian masukan air masukan ayam beri garam dan penyedap.. tunggu hingga susut sesekali di aduk.."
- "Di wajan lain, panaskan minyak. Goreng ayam, goreng nya sampe ayamnya kerendem minyak ya biar mateng nya merata dan ga lengket di wajan. Kalo udah ke coklatan angkat dan sajikan.."
categories:
- Resep
tags:
- ayam
- goreng
- lengkuas

katakunci: ayam goreng lengkuas 
nutrition: 264 calories
recipecuisine: Indonesian
preptime: "PT26M"
cooktime: "PT59M"
recipeyield: "4"
recipecategory: Dinner

---


![Ayam Goreng Lengkuas](https://img-global.cpcdn.com/recipes/efa643597c022009/751x532cq70/ayam-goreng-lengkuas-foto-resep-utama.jpg)


ayam goreng lengkuas ini yakni suguhan nusantara yang lezat dan perlu untuk kita coba. Cita rasanya yang lezat membuat siapa pun menantikan kehadirannya di meja makan.
Sedang mencari ide resep ayam goreng lengkuas untuk jualan atau dikonsumsi sendiri yang Lezat? Cara menyiapkannya memang susah-susah gampang. bila salah mengolah maka hasilnya Tidak Memuaskan dan justru cenderung tidak enak. Padahal ayam goreng lengkuas yang enak harusnya sih mempunyai aroma dan cita rasa yang dapat memancing selera kita.

Ada beberapa hal yang sedikit banyak mempengaruhi kualitas rasa dari ayam goreng lengkuas, pertama dari jenis bahan, selanjutnya pemilihan bahan segar, sampai cara mengolah dan menyajikannya. Tidak usah pusing kalau mau menyiapkan ayam goreng lengkuas yang enak di rumah, karena asal sudah tahu triknya maka hidangan ini mampu jadi suguhan spesial.




Di bawah ini ada beberapa tips dan trik praktis untuk membuat ayam goreng lengkuas yang siap dikreasikan. Anda bisa membuat Ayam Goreng Lengkuas menggunakan 16 jenis bahan dan 2 tahap pembuatan. Berikut ini langkah-langkah dalam menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam pembuatan Ayam Goreng Lengkuas:

1. Sediakan 1 ekor ayam kampung
1. Siapkan 3 laos besar parut
1. Gunakan 2 batang serai
1. Siapkan 4 daun salam
1. Ambil 4 daun jeruk
1. Ambil 600 ml air
1. Sediakan Secukupnya garam
1. Sediakan Secukupnya penyedap
1. Sediakan Secukupnya gula
1. Ambil  Bumbu Halus
1. Ambil 2 sdm ketumbar
1. Sediakan 1 sdt merica
1. Ambil 6 siung bawang putih
1. Gunakan 4 butir kemiri
1. Siapkan 2 ruas jahe
1. Gunakan 2 ruas kunyit




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Ayam Goreng Lengkuas:

1. Bersihkan ayam, siapkan wajan beri sdikit minyak tumis bumbu halus, laos, kemudian masukan daun2 dan serai, tunggu hingga harum kemudian masukan air masukan ayam beri garam dan penyedap.. tunggu hingga susut sesekali di aduk..
1. Di wajan lain, panaskan minyak. Goreng ayam, goreng nya sampe ayamnya kerendem minyak ya biar mateng nya merata dan ga lengket di wajan. Kalo udah ke coklatan angkat dan sajikan..




Terima kasih telah menggunakan resep yang tim kami tampilkan di sini. Harapan kami, olahan Ayam Goreng Lengkuas yang mudah di atas dapat membantu Anda menyiapkan makanan yang lezat untuk keluarga/teman ataupun menjadi inspirasi untuk berbisnis kuliner. Selamat mencoba!
