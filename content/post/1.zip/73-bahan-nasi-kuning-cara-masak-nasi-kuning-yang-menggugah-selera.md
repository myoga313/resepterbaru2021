---
description: "Bahan Nasi Kuning | Cara Masak Nasi Kuning Yang Menggugah Selera"
title: "Bahan Nasi Kuning | Cara Masak Nasi Kuning Yang Menggugah Selera"
slug: 73-bahan-nasi-kuning-cara-masak-nasi-kuning-yang-menggugah-selera
date: 2020-12-12T14:46:53.104Z
image: https://img-global.cpcdn.com/recipes/39f9ccb7f391f412/751x532cq70/nasi-kuning-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/39f9ccb7f391f412/751x532cq70/nasi-kuning-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/39f9ccb7f391f412/751x532cq70/nasi-kuning-foto-resep-utama.jpg
author: Marc Francis
ratingvalue: 4.5
reviewcount: 8
recipeingredient:
- " beras"
- " santan instan"
- " air"
- " kunyit tua parut peras airnya"
- " daun jeruk"
- " sereh geprek"
- " daun pandan tambahan sy"
- " lengkuas tambahan sy"
- " daun salam tambahan sy"
- " garam"
recipeinstructions:
- "Cuci bersih beras, tiriskan. Masukan beras ke dalam panci magiccom. Tuang santan, tambahkan air hingga mencukupi air seperti memasak nasi biasa. Masukan semua bahan daun dan garam. Tuang perasan kunyit sambil disaring. Aduk rata."
- "Tekan tombol cook pada magiccom, biarkan hingga matang dan tombol berpindah ke warm."
- "Aduk² nasi setelah matang. Dan nasi kuning siap disajikan dengan lauk kesukaan."
categories:
- Resep
tags:
- nasi
- kuning

katakunci: nasi kuning 
nutrition: 133 calories
recipecuisine: Indonesian
preptime: "PT22M"
cooktime: "PT35M"
recipeyield: "2"
recipecategory: Dinner

---


![Nasi Kuning](https://img-global.cpcdn.com/recipes/39f9ccb7f391f412/751x532cq70/nasi-kuning-foto-resep-utama.jpg)


nasi kuning ini yakni kuliner nusantara yang unik dan harus untuk kita coba. Cita rasanya yang lezat membuat siapa pun menantikan kehadirannya di meja makan.
Bunda Sedang mencari inspirasi resep nasi kuning untuk jualan atau dikonsumsi sendiri yang Lezat Sekali? Cara Buatnya memang susah-susah gampang. andaikan salah mengolah maka hasilnya Tidak Memuaskan dan justru cenderung tidak enak. Padahal nasi kuning yang enak seharusnya memiliki aroma dan cita rasa yang bisa memancing selera kita.



Ada beberapa hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari nasi kuning, pertama dari jenis bahan, kemudian pemilihan bahan segar hingga cara membuat dan menyajikannya. Tidak usah pusing kalau hendak menyiapkan nasi kuning enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini bisa jadi sajian spesial.


Nah, kali ini kita coba, yuk, kreasikan nasi kuning sendiri di rumah. Tetap berbahan sederhana, sajian ini bisa memberi manfaat dalam membantu menjaga kesehatan tubuhmu sekeluarga. Anda bisa menyiapkan Nasi Kuning menggunakan 10 bahan dan 3 langkah pembuatan. Berikut ini langkah-langkah dalam menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam menyiapkan Nasi Kuning:

1. Sediakan  beras
1. Ambil  santan instan
1. Sediakan  air
1. Siapkan  kunyit tua, parut, peras airnya
1. Gunakan  daun jeruk
1. Siapkan  sereh, geprek
1. Gunakan  daun pandan (tambahan sy)
1. Ambil  lengkuas (tambahan sy)
1. Sediakan  daun salam (tambahan sy)
1. Sediakan  garam




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Nasi Kuning:

1. Cuci bersih beras, tiriskan. Masukan beras ke dalam panci magiccom. Tuang santan, tambahkan air hingga mencukupi air seperti memasak nasi biasa. Masukan semua bahan daun dan garam. Tuang perasan kunyit sambil disaring. Aduk rata.
1. Tekan tombol cook pada magiccom, biarkan hingga matang dan tombol berpindah ke warm.
1. Aduk² nasi setelah matang. Dan nasi kuning siap disajikan dengan lauk kesukaan.




Gimana nih? Gampang kan? Itulah cara membuat nasi kuning yang bisa Anda praktikkan di rumah. Selamat mencoba!
