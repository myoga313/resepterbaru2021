---
description: "Resep Soto Ayam Simpel | Cara Bikin Soto Ayam Simpel Yang Bisa Manjain Lidah"
title: "Resep Soto Ayam Simpel | Cara Bikin Soto Ayam Simpel Yang Bisa Manjain Lidah"
slug: 432-resep-soto-ayam-simpel-cara-bikin-soto-ayam-simpel-yang-bisa-manjain-lidah
date: 2020-11-03T23:25:42.579Z
image: https://img-global.cpcdn.com/recipes/dc865cf2333ac35e/751x532cq70/soto-ayam-simpel-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/dc865cf2333ac35e/751x532cq70/soto-ayam-simpel-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/dc865cf2333ac35e/751x532cq70/soto-ayam-simpel-foto-resep-utama.jpg
author: Mamie Maldonado
ratingvalue: 4.3
reviewcount: 9
recipeingredient:
- " ayam potongan dadapaha"
- " Bumbu halus"
- " Kunyit ukuran kelingking"
- " Bawang merah 6 siung ukuran sedangbesar"
- " Bawang putih 2 siung ukuran besar"
- " jahe 1cm"
- " Kemiri"
- " Merica"
- " Ketumbar"
- " Pala bubuk"
- " Serai 2 batang 1 batang untuk rebus ayam 1batang untuk menumis"
- " Daun Salam 4 lembar 2 rebus ayam 2menumis"
- " Daun jeruk purut"
- " lengkuas geprekiris"
- " Bawang merah goreng kemasan"
- " Daun bawang dan seledri"
- " Gula garam penyedap"
- " Pelengkapnya"
- " Cabe 6 dan 1btr kemiri untuk sambal"
- " Kecap"
- " Cukajeruk nipis"
- " Kecambah kecil"
- " Seledri iris halus"
recipeinstructions:
- "Potong ayam dan rebus ayam untuk membuang kotoran lemak pada ayam dgn menambahkan satu btg serai, 2 lembar daun salam, 1 sdt garam"
- "Setelah mendidih dan ayam dirasa empuk, angkat dan tiriskan. Cabut tulang ayam untuk kaldu pada kuah soto. Sisihkan daging ayam untuk digoreng basah."
- "Haluskan bumbu. Setelah halus, tumis bumbu halus dengan 2 SDM minyak goreng hingga wangi. Tambahkan 2 daun salam, 2 lembar jeruk purut, lengkuas, 1 btg serai. Jangan sampai gosong, tambahkan air 1.5 L dan masukan tulang ayam. Rebus hingga matang. Tambahkan gula, garam, penyedap rasa sesuai selera."
- "Setelah mendidih dan rasa sesuai selera, tambahkan irisan daun bawang, seledri dan bawang goreng."
- "Matikan kompor. Baluri daging ayam dengan garam. Goreng basah daging ayam. Setelah cukup angkat tiriskan."
- "Sajikan nasi bersama daging ayam yang sudah digoreng."
categories:
- Resep
tags:
- soto
- ayam
- simpel

katakunci: soto ayam simpel 
nutrition: 142 calories
recipecuisine: Indonesian
preptime: "PT19M"
cooktime: "PT53M"
recipeyield: "1"
recipecategory: Lunch

---


![Soto Ayam Simpel](https://img-global.cpcdn.com/recipes/dc865cf2333ac35e/751x532cq70/soto-ayam-simpel-foto-resep-utama.jpg)


soto ayam simpel ini ialah sajian tanah air yang lezat dan wajib untuk kita coba. Cita rasanya yang lezat membuat siapa pun menantikan kehadirannya di meja makan.
Anda sedang mencari inspirasi resep soto ayam simpel untuk jualan atau dikonsumsi sendiri yang Enak Dan Lezat? Cara menyiapkannya memang tidak terlalu sulit namun tidak gampang juga. andaikata salah mengolah maka hasilnya akan hambar dan bahkan tidak sedap. Padahal soto ayam simpel yang enak seharusnya mempunyai aroma dan rasa yang bisa memancing selera kita.



Banyak hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari soto ayam simpel, pertama dari jenis bahan, kemudian pemilihan bahan segar sampai cara membuat dan menghidangkannya. Tak perlu pusing kalau hendak menyiapkan soto ayam simpel enak di rumah, karena asal sudah tahu triknya maka hidangan ini bisa menjadi sajian istimewa.


Nah, kali ini kita coba, yuk, kreasikan soto ayam simpel sendiri di rumah. Tetap berbahan sederhana, hidangan ini dapat memberi manfaat dalam membantu menjaga kesehatan tubuhmu sekeluarga. Anda bisa membuat Soto Ayam Simpel menggunakan 23 jenis bahan dan 6 langkah pembuatan. Berikut ini cara dalam menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk menyiapkan Soto Ayam Simpel:

1. Gunakan  ayam (potongan dada/paha)
1. Ambil  Bumbu halus:
1. Ambil  Kunyit ukuran kelingking
1. Gunakan  Bawang merah 6 siung (ukuran sedang/besar)
1. Ambil  Bawang putih 2 siung ukuran besar
1. Ambil  jahe 1cm
1. Gunakan  Kemiri
1. Siapkan  Merica
1. Gunakan  Ketumbar
1. Ambil  Pala bubuk
1. Gunakan  Serai 2 batang (1 batang untuk rebus ayam, 1batang untuk menumis
1. Ambil  Daun Salam 4 lembar (2 rebus ayam, 2menumis)
1. Siapkan  Daun jeruk purut
1. Sediakan  lengkuas geprek/iris
1. Gunakan  Bawang merah goreng kemasan
1. Ambil  Daun bawang dan seledri
1. Siapkan  Gula, garam, penyedap
1. Siapkan  Pelengkapnya:
1. Sediakan  Cabe 6 dan 1btr kemiri untuk sambal
1. Siapkan  Kecap
1. Ambil  Cuka/jeruk nipis
1. Sediakan  Kecambah kecil
1. Gunakan  Seledri iris halus




<!--inarticleads2-->

##### Cara membuat Soto Ayam Simpel:

1. Potong ayam dan rebus ayam untuk membuang kotoran lemak pada ayam dgn menambahkan satu btg serai, 2 lembar daun salam, 1 sdt garam
1. Setelah mendidih dan ayam dirasa empuk, angkat dan tiriskan. Cabut tulang ayam untuk kaldu pada kuah soto. Sisihkan daging ayam untuk digoreng basah.
1. Haluskan bumbu. Setelah halus, tumis bumbu halus dengan 2 SDM minyak goreng hingga wangi. Tambahkan 2 daun salam, 2 lembar jeruk purut, lengkuas, 1 btg serai. Jangan sampai gosong, tambahkan air 1.5 L dan masukan tulang ayam. Rebus hingga matang. Tambahkan gula, garam, penyedap rasa sesuai selera.
1. Setelah mendidih dan rasa sesuai selera, tambahkan irisan daun bawang, seledri dan bawang goreng.
1. Matikan kompor. Baluri daging ayam dengan garam. Goreng basah daging ayam. Setelah cukup angkat tiriskan.
1. Sajikan nasi bersama daging ayam yang sudah digoreng.




Bagaimana? Gampang kan? Itulah cara menyiapkan soto ayam simpel yang bisa Anda lakukan di rumah. Semoga bermanfaat dan selamat mencoba!
