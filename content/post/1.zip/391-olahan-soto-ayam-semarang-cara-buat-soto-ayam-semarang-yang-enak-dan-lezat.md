---
description: "Olahan Soto Ayam Semarang | Cara Buat Soto Ayam Semarang Yang Enak Dan Lezat"
title: "Olahan Soto Ayam Semarang | Cara Buat Soto Ayam Semarang Yang Enak Dan Lezat"
slug: 391-olahan-soto-ayam-semarang-cara-buat-soto-ayam-semarang-yang-enak-dan-lezat
date: 2020-11-08T11:51:33.284Z
image: https://img-global.cpcdn.com/recipes/5e8334aef6f7d864/751x532cq70/soto-ayam-semarang-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/5e8334aef6f7d864/751x532cq70/soto-ayam-semarang-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/5e8334aef6f7d864/751x532cq70/soto-ayam-semarang-foto-resep-utama.jpg
author: Laura Long
ratingvalue: 3.5
reviewcount: 7
recipeingredient:
- "1/2 potong dada Ayam"
- " Air sucukupmnya"
- " Minyak goreng"
- "2 sdt Garam"
- "5 siung bawang merah"
- "7 siung bawang putih"
- "2 buah kemiri"
- "2 cm jahe"
- "2 cm kunyit"
- "5 cm lengkuas diiris dipis"
- "3 lembar daun jeruk"
- "1 lembar daun salam"
- "1 batang sereh"
- "2 batang daun seledri"
- "2 batang daun bawang"
- "2 cabai setan"
- "2 buh jeruk nipis"
- "2 sdt ketumbar bubuk"
- "secukupnya Sohun"
recipeinstructions:
- "Bersihkan dan cuci ayam dengan perasan jeruk nipis lalu potong sesuai selera dan rebus ayam hingga mendidih, ganti air rebusannya dengan air yang akan digunakan membuat kuah kaldu ayam, ayamnya goreng"
- "Haluskan bumbu kuning (bawang putih / merah, jahet, kunyit, ketumbar dll) lalu panaskan minyak untuk menumis bumbu kuning tambahakn sereh, daun salam, daun jeruk setelah itu masukkan tumisan bumbu ke panci yang berisi kuah kaldu ayam aduk rata dan tes rasa"
- "Untuk membuat sambalnya 1 siung bawang merah dan cabai setan di uleg dan siap sajikan jika ingin menambah kecap juga bisa"
categories:
- Resep
tags:
- soto
- ayam
- semarang

katakunci: soto ayam semarang 
nutrition: 180 calories
recipecuisine: Indonesian
preptime: "PT36M"
cooktime: "PT49M"
recipeyield: "4"
recipecategory: Dinner

---


![Soto Ayam Semarang](https://img-global.cpcdn.com/recipes/5e8334aef6f7d864/751x532cq70/soto-ayam-semarang-foto-resep-utama.jpg)


soto ayam semarang ini merupakan makanan nusantara yang mantap dan harus untuk kita coba. Cita rasanya yang lezat membuat siapa pun menantikan kehadirannya di meja makan.
Anda sedang mencari ide resep soto ayam semarang untuk jualan atau dikonsumsi sendiri yang Sedap? Cara Bikinnya memang susah-susah gampang. andaikan salah mengolah maka hasilnya akan hambar dan justru cenderung tidak enak. Padahal soto ayam semarang yang enak selayaknya memiliki aroma dan rasa yang mampu memancing selera kita.

Banyak hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari soto ayam semarang, mulai dari jenis bahan, selanjutnya pemilihan bahan segar, sampai cara mengolah dan menghidangkannya. Tak perlu pusing kalau mau menyiapkan soto ayam semarang enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini mampu menjadi suguhan istimewa.




Nah, kali ini kita coba, yuk, siapkan soto ayam semarang sendiri di rumah. Tetap berbahan yang sederhana, sajian ini bisa memberi manfaat untuk membantu menjaga kesehatan tubuh kita. Anda dapat menyiapkan Soto Ayam Semarang menggunakan 19 jenis bahan dan 3 tahap pembuatan. Berikut ini cara dalam menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam pembuatan Soto Ayam Semarang:

1. Ambil 1/2 potong dada Ayam
1. Siapkan  Air sucukupmnya
1. Ambil  Minyak goreng
1. Gunakan 2 sdt Garam
1. Sediakan 5 siung bawang merah
1. Siapkan 7 siung bawang putih
1. Siapkan 2 buah kemiri
1. Gunakan 2 cm jahe
1. Sediakan 2 cm kunyit
1. Ambil 5 cm lengkuas diiris dipis
1. Sediakan 3 lembar daun jeruk
1. Gunakan 1 lembar daun salam
1. Siapkan 1 batang sereh
1. Sediakan 2 batang daun seledri
1. Siapkan 2 batang daun bawang
1. Siapkan 2 cabai setan
1. Sediakan 2 buh jeruk nipis
1. Siapkan 2 sdt ketumbar bubuk
1. Sediakan secukupnya Sohun




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Soto Ayam Semarang:

1. Bersihkan dan cuci ayam dengan perasan jeruk nipis lalu potong sesuai selera dan rebus ayam hingga mendidih, ganti air rebusannya dengan air yang akan digunakan membuat kuah kaldu ayam, ayamnya goreng
1. Haluskan bumbu kuning (bawang putih / merah, jahet, kunyit, ketumbar dll) lalu panaskan minyak untuk menumis bumbu kuning tambahakn sereh, daun salam, daun jeruk setelah itu masukkan tumisan bumbu ke panci yang berisi kuah kaldu ayam aduk rata dan tes rasa
1. Untuk membuat sambalnya 1 siung bawang merah dan cabai setan di uleg dan siap sajikan jika ingin menambah kecap juga bisa




Bagaimana? Gampang kan? Itulah cara membuat soto ayam semarang yang bisa Anda lakukan di rumah. Semoga bermanfaat dan selamat mencoba!
