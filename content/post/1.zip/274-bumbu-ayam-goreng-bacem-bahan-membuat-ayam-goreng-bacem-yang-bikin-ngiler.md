---
description: "Bumbu Ayam Goreng Bacem | Bahan Membuat Ayam Goreng Bacem Yang Bikin Ngiler"
title: "Bumbu Ayam Goreng Bacem | Bahan Membuat Ayam Goreng Bacem Yang Bikin Ngiler"
slug: 274-bumbu-ayam-goreng-bacem-bahan-membuat-ayam-goreng-bacem-yang-bikin-ngiler
date: 2021-01-16T05:53:21.636Z
image: https://img-global.cpcdn.com/recipes/5858a47677e6a98f/751x532cq70/ayam-goreng-bacem-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/5858a47677e6a98f/751x532cq70/ayam-goreng-bacem-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/5858a47677e6a98f/751x532cq70/ayam-goreng-bacem-foto-resep-utama.jpg
author: Roger Floyd
ratingvalue: 3.1
reviewcount: 6
recipeingredient:
- "1/2 ekor ayam potong 4"
- " BUMBU HALUS "
- "9 butir kemiri"
- "7 siung baput"
- "3 cm jahe"
- "3 cm kencur"
- "3 cm lengkuas"
- "3 lembar daun salam"
- "5 lembar daun jeruk"
- "5 sdm kecap manis"
- "3 sdm gula putih"
- "1 sdm garam"
- "1 sdt kaldu jamur"
- "1 L air"
- "250 ml minyak goreng"
recipeinstructions:
- "Siapkan bahan&#34; untuk di haluskan, saya menggunakan blender dgn tambahan 100 ml air. Setelah halus sisihkan."
- "Panaskan air (900 ml) sampai mendidih, baru masukkan bumbu halus beserta daun salam, sereh geprek, daun jeruk, kecap, gula putih, garam &amp; kaldu jamur. Aduk rata, baru masukkan ayam (bisa jg di tambah tahu &amp; tempe)."
- "Masak sampai air menyusut, matikan api. Panaskan minyak goreng, goreng baceman ayam sampai kecoklatan. Angkat &amp; tiriskan. Siap di nikmati sebagai lauk / cemilan, pokok&#39;e...maknyuzzz 😉"
categories:
- Resep
tags:
- ayam
- goreng
- bacem

katakunci: ayam goreng bacem 
nutrition: 235 calories
recipecuisine: Indonesian
preptime: "PT14M"
cooktime: "PT38M"
recipeyield: "2"
recipecategory: Dinner

---


![Ayam Goreng Bacem](https://img-global.cpcdn.com/recipes/5858a47677e6a98f/751x532cq70/ayam-goreng-bacem-foto-resep-utama.jpg)


ayam goreng bacem ini merupakan kuliner tanah air yang ekslusif dan perlu untuk kita coba. Cita rasanya yang lezat membuat siapa pun menantikan kehadirannya di meja makan.
Sedang mencari inspirasi resep ayam goreng bacem untuk jualan atau dikonsumsi sendiri yang Enak Banget? Cara membuatnya memang tidak terlalu sulit namun tidak gampang juga. semisal keliru mengolah maka hasilnya tidak akan memuaskan dan justru cenderung tidak enak. Padahal ayam goreng bacem yang enak harusnya sih mempunyai aroma dan cita rasa yang mampu memancing selera kita.

Ada beberapa hal yang sedikit banyak mempengaruhi kualitas rasa dari ayam goreng bacem, pertama dari jenis bahan, lalu pemilihan bahan segar, sampai cara membuat dan menghidangkannya. Tidak usah pusing jika hendak menyiapkan ayam goreng bacem enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini dapat menjadi sajian spesial.




Nah, kali ini kita coba, yuk, ciptakan ayam goreng bacem sendiri di rumah. Tetap dengan bahan yang sederhana, hidangan ini dapat memberi manfaat dalam membantu menjaga kesehatan tubuhmu sekeluarga. Anda bisa membuat Ayam Goreng Bacem menggunakan 15 jenis bahan dan 3 langkah pembuatan. Berikut ini langkah-langkah dalam menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk menyiapkan Ayam Goreng Bacem:

1. Ambil 1/2 ekor ayam, potong 4
1. Siapkan  BUMBU HALUS :
1. Gunakan 9 butir kemiri
1. Ambil 7 siung baput
1. Ambil 3 cm jahe
1. Gunakan 3 cm kencur
1. Gunakan 3 cm lengkuas
1. Sediakan 3 lembar daun salam
1. Gunakan 5 lembar daun jeruk
1. Siapkan 5 sdm kecap manis
1. Gunakan 3 sdm gula putih
1. Sediakan 1 sdm garam
1. Sediakan 1 sdt kaldu jamur
1. Ambil 1 L air
1. Siapkan 250 ml minyak goreng




<!--inarticleads2-->

##### Cara membuat Ayam Goreng Bacem:

1. Siapkan bahan&#34; untuk di haluskan, saya menggunakan blender dgn tambahan 100 ml air. Setelah halus sisihkan.
1. Panaskan air (900 ml) sampai mendidih, baru masukkan bumbu halus beserta daun salam, sereh geprek, daun jeruk, kecap, gula putih, garam &amp; kaldu jamur. Aduk rata, baru masukkan ayam (bisa jg di tambah tahu &amp; tempe).
1. Masak sampai air menyusut, matikan api. Panaskan minyak goreng, goreng baceman ayam sampai kecoklatan. Angkat &amp; tiriskan. Siap di nikmati sebagai lauk / cemilan, pokok&#39;e...maknyuzzz 😉




Gimana nih? Gampang kan? Itulah cara membuat ayam goreng bacem yang bisa Anda lakukan di rumah. Selamat mencoba!
