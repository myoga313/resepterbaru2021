---
description: "Olahan Ayam Kecap ala Warung Gajebo | Resep Bumbu Ayam Kecap ala Warung Gajebo Yang Enak Dan Mudah"
title: "Olahan Ayam Kecap ala Warung Gajebo | Resep Bumbu Ayam Kecap ala Warung Gajebo Yang Enak Dan Mudah"
slug: 381-olahan-ayam-kecap-ala-warung-gajebo-resep-bumbu-ayam-kecap-ala-warung-gajebo-yang-enak-dan-mudah
date: 2020-12-22T02:47:49.140Z
image: https://img-global.cpcdn.com/recipes/221ac3487504aae4/751x532cq70/ayam-kecap-ala-warung-gajebo-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/221ac3487504aae4/751x532cq70/ayam-kecap-ala-warung-gajebo-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/221ac3487504aae4/751x532cq70/ayam-kecap-ala-warung-gajebo-foto-resep-utama.jpg
author: Bruce Beck
ratingvalue: 4.1
reviewcount: 9
recipeingredient:
- " ayam goreng tepung"
- " kubis"
- " terong"
- " Bumbu"
- " bawang putih"
- " cabai keriting merah"
- " cabai rawit"
- " kaldu jamur"
- " lada bubuk"
- " kecap"
- " gula pasir"
- " air"
recipeinstructions:
- "Geprek ayam goreng tepung (saya beli jadi; bisa pakai ayam olive, mcd, kfc atau apapun—kalau mau bikin sendiri pun nggak masalah. Yg penting sudah berbumbu)"
- "Potong terong menjadi potongan bulat tipis (disini saya ganti terong dengan jamur champignon). Potong kubis. Sisihkan."
- "Uleg kasar bawang putih &amp; cabai. Lalu tumis hingga harum."
- "Setelah bumbu harum, tambahkan sedikit air. Masukan terong. Tambahkan kaldu, gula, lada, dan kecap. Aduk rata."
- "Masukkan ayam yang sudah digeprek dan kubis. Aduk rata. Koreksi rasa. Siap disajikan."
categories:
- Resep
tags:
- ayam
- kecap
- ala

katakunci: ayam kecap ala 
nutrition: 137 calories
recipecuisine: Indonesian
preptime: "PT21M"
cooktime: "PT53M"
recipeyield: "2"
recipecategory: Dinner

---


![Ayam Kecap ala Warung Gajebo](https://img-global.cpcdn.com/recipes/221ac3487504aae4/751x532cq70/ayam-kecap-ala-warung-gajebo-foto-resep-utama.jpg)


ayam kecap ala warung gajebo ini ialah makanan nusantara yang ekslusif dan wajib untuk kita coba. Cita rasanya yang sedap membuat siapa pun menantikan kehadirannya di meja makan.
Lagi mencari inspirasi resep ayam kecap ala warung gajebo untuk jualan atau dikonsumsi sendiri yang Enak Dan Mudah? Cara Memasaknya memang tidak susah dan tidak juga mudah. andaikata salah mengolah maka hasilnya akan hambar dan bahkan tidak sedap. Padahal ayam kecap ala warung gajebo yang enak selayaknya punya aroma dan rasa yang bisa memancing selera kita.

Ada beberapa hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari ayam kecap ala warung gajebo, pertama dari jenis bahan, lalu pemilihan bahan segar, sampai cara mengolah dan menghidangkannya. Tidak usah pusing kalau hendak menyiapkan ayam kecap ala warung gajebo yang enak di rumah, karena asal sudah tahu triknya maka hidangan ini dapat jadi sajian spesial.




Berikut ini ada beberapa cara mudah dan praktis dalam mengolah ayam kecap ala warung gajebo yang siap dikreasikan. Anda dapat menyiapkan Ayam Kecap ala Warung Gajebo memakai 12 bahan dan 5 tahap pembuatan. Berikut ini cara untuk menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam pembuatan Ayam Kecap ala Warung Gajebo:

1. Siapkan  ayam goreng tepung
1. Siapkan  kubis
1. Gunakan  terong
1. Ambil  Bumbu
1. Siapkan  bawang putih
1. Sediakan  cabai keriting merah
1. Ambil  cabai rawit
1. Ambil  kaldu jamur
1. Gunakan  lada bubuk
1. Sediakan  kecap
1. Gunakan  gula pasir
1. Gunakan  air




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Ayam Kecap ala Warung Gajebo:

1. Geprek ayam goreng tepung (saya beli jadi; bisa pakai ayam olive, mcd, kfc atau apapun—kalau mau bikin sendiri pun nggak masalah. Yg penting sudah berbumbu)
1. Potong terong menjadi potongan bulat tipis (disini saya ganti terong dengan jamur champignon). Potong kubis. Sisihkan.
1. Uleg kasar bawang putih &amp; cabai. Lalu tumis hingga harum.
1. Setelah bumbu harum, tambahkan sedikit air. Masukan terong. Tambahkan kaldu, gula, lada, dan kecap. Aduk rata.
1. Masukkan ayam yang sudah digeprek dan kubis. Aduk rata. Koreksi rasa. Siap disajikan.




Gimana nih? Mudah bukan? Itulah cara membuat ayam kecap ala warung gajebo yang bisa Anda praktikkan di rumah. Semoga bermanfaat dan selamat mencoba!
