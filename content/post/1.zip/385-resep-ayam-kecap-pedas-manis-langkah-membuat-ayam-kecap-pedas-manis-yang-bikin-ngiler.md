---
description: "Resep Ayam Kecap Pedas Manis | Langkah Membuat Ayam Kecap Pedas Manis Yang Bikin Ngiler"
title: "Resep Ayam Kecap Pedas Manis | Langkah Membuat Ayam Kecap Pedas Manis Yang Bikin Ngiler"
slug: 385-resep-ayam-kecap-pedas-manis-langkah-membuat-ayam-kecap-pedas-manis-yang-bikin-ngiler
date: 2020-07-29T21:09:26.848Z
image: https://img-global.cpcdn.com/recipes/1190e8c2cbb1b966/751x532cq70/ayam-kecap-pedas-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/1190e8c2cbb1b966/751x532cq70/ayam-kecap-pedas-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/1190e8c2cbb1b966/751x532cq70/ayam-kecap-pedas-manis-foto-resep-utama.jpg
author: Nellie Lee
ratingvalue: 3.2
reviewcount: 6
recipeingredient:
- " ayam"
- " jeruk kencinipis"
- " garam"
- " kaldu jamur"
- " kecap manis"
- " kecap asin"
- " saus tiram"
- " Minyak"
- " Bumbu Tumis "
- " bawang merah iris"
- " bawang putih iris"
- " bawang bombay iris"
- " cabe rawit iris"
- " cabe merah iris"
- " daun bawang iris"
- " jahe iris"
recipeinstructions:
- "Potong ayam sesuai selera, cuci bersih, baluri dengan jeruk kunci/nipis dan garam sekitar 10 menit, tiriskan"
- "Goreng ayam hingga matang kecoklatan, tiriskan"
- "Tumis bumbu irisan hingga harum dan matang, masukkan ayam, aduk~aduk merata"
- "Tambahkan kecap manis, kecap asin, saus tiram, dan kaldu jamur, aduk meresap"
- "Angkat dan sajikan dengan perasaan yang hangat 😄"
categories:
- Resep
tags:
- ayam
- kecap
- pedas

katakunci: ayam kecap pedas 
nutrition: 107 calories
recipecuisine: Indonesian
preptime: "PT29M"
cooktime: "PT35M"
recipeyield: "4"
recipecategory: Lunch

---


![Ayam Kecap Pedas Manis](https://img-global.cpcdn.com/recipes/1190e8c2cbb1b966/751x532cq70/ayam-kecap-pedas-manis-foto-resep-utama.jpg)


ayam kecap pedas manis ini yaitu kuliner nusantara yang unik dan perlu untuk kita coba. Cita rasanya yang lezat membuat siapa pun menantikan kehadirannya di meja makan.
Kamu Lagi mencari ide resep ayam kecap pedas manis untuk jualan atau dikonsumsi sendiri yang Bisa Manjain Lidah? Cara menyiapkannya memang tidak terlalu sulit namun tidak gampang juga. andaikata keliru mengolah maka hasilnya tidak akan memuaskan dan justru cenderung tidak enak. Padahal ayam kecap pedas manis yang enak harusnya sih memiliki aroma dan rasa yang dapat memancing selera kita.



Banyak hal yang sedikit banyak mempengaruhi kualitas rasa dari ayam kecap pedas manis, pertama dari jenis bahan, kemudian pemilihan bahan segar hingga cara mengolah dan menghidangkannya. Tidak usah pusing kalau hendak menyiapkan ayam kecap pedas manis yang enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini mampu menjadi sajian istimewa.


Nah, kali ini kita coba, yuk, variasikan ayam kecap pedas manis sendiri di rumah. Tetap dengan bahan yang sederhana, hidangan ini dapat memberi manfaat untuk membantu menjaga kesehatan tubuh kita. Anda bisa membuat Ayam Kecap Pedas Manis memakai 16 bahan dan 5 langkah pembuatan. Berikut ini langkah-langkah untuk membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk menyiapkan Ayam Kecap Pedas Manis:

1. Siapkan  ayam
1. Siapkan  jeruk kenci/nipis
1. Ambil  garam
1. Sediakan  kaldu jamur
1. Ambil  kecap manis
1. Siapkan  kecap asin
1. Gunakan  saus tiram
1. Siapkan  Minyak
1. Sediakan  Bumbu Tumis :
1. Gunakan  bawang merah, iris
1. Sediakan  bawang putih, iris
1. Ambil  bawang bombay, iris
1. Ambil  cabe rawit, iris
1. Siapkan  cabe merah, iris
1. Siapkan  daun bawang, iris
1. Sediakan  jahe, iris




<!--inarticleads2-->

##### Cara menyiapkan Ayam Kecap Pedas Manis:

1. Potong ayam sesuai selera, cuci bersih, baluri dengan jeruk kunci/nipis dan garam sekitar 10 menit, tiriskan
1. Goreng ayam hingga matang kecoklatan, tiriskan
1. Tumis bumbu irisan hingga harum dan matang, masukkan ayam, aduk~aduk merata
1. Tambahkan kecap manis, kecap asin, saus tiram, dan kaldu jamur, aduk meresap
1. Angkat dan sajikan dengan perasaan yang hangat 😄




Terima kasih telah membaca resep yang tim kami tampilkan di sini. Besar harapan kami, olahan Ayam Kecap Pedas Manis yang mudah di atas dapat membantu Anda menyiapkan hidangan yang menarik untuk keluarga/teman ataupun menjadi ide bagi Anda yang berkeinginan untuk berjualan makanan. Semoga bermanfaat dan selamat mencoba!
