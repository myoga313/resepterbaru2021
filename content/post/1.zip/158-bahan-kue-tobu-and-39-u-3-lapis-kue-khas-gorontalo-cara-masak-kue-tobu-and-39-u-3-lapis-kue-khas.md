---
description: "Bahan Kue Tobu &amp;#39;u 3 lapis (Kue Khas Gorontalo) | Cara Masak Kue Tobu &amp;#39;u 3 lapis (Kue Khas Gorontalo) Yang Bisa Manjain Lidah"
title: "Bahan Kue Tobu &amp;#39;u 3 lapis (Kue Khas Gorontalo) | Cara Masak Kue Tobu &amp;#39;u 3 lapis (Kue Khas Gorontalo) Yang Bisa Manjain Lidah"
slug: 158-bahan-kue-tobu-and-39-u-3-lapis-kue-khas-gorontalo-cara-masak-kue-tobu-and-39-u-3-lapis-kue-khas-gorontalo-yang-bisa-manjain-lidah
date: 2020-11-09T04:25:02.289Z
image: https://img-global.cpcdn.com/recipes/bd373c3f472eb7d9/751x532cq70/kue-tobu-u-3-lapis-kue-khas-gorontalo-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/bd373c3f472eb7d9/751x532cq70/kue-tobu-u-3-lapis-kue-khas-gorontalo-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/bd373c3f472eb7d9/751x532cq70/kue-tobu-u-3-lapis-kue-khas-gorontalo-foto-resep-utama.jpg
author: Blanche Schneider
ratingvalue: 3
reviewcount: 10
recipeingredient:
- " Bahan bahan"
- " Daun pisang di sesuaikan penggunaannya"
- "2 lembar daun pandan dipotong potong di jadikan alas takir"
- "5 sdm tepung terigu serbaguna"
- "2 sdm tepung beras tambahan saya"
- "4 sdm gula pasir semula 2 sdm"
- "300 ml santan dari segitiga snatan 65m 235 ml air semula 270ml"
- "100 gram gula jawa serut2 tipis"
- "2 tetes pasta pandan"
- "Seujung sdt garam"
recipeinstructions:
- "Sebelum di bentuk menjadi takir, jemur dulu di sinar matahari atau panaskan di atas api kompor daun pisangnya supaya menjadi lemas tdk kaku, sehingga memudahkan untk membuat takir. Bentuk menjadi takir dng mengunci menggunakan steples,. Baru potong2 daun pandan sesuai panjang takir, tata di atasnya"
- "Lalu cairkan segitiga santan dng air 235 ml, setelah itu campurkan tepung terigu dan tepung beras dan gula pasir, aduk merata, lalu tuang santan kedalamnya sambil diaduk aduk"
- "Setelah itu saring supaya menghilangkan yg bergerindil. Lalu bagi menjadi 2, yg pertama biarkan putih, lalu beri garam,aduk aduk dan bagian berikutnya beri pasta pandan, aduk aduk."
- "Panaskan panci kukusan, lalu sambil menunggu mendidih airnya, beri masing masing takir serutan gula merah secukupnya, lalu masukan adonan putih diatas serutan gula merah, tutup panci jng lupa dibungkus kain serbet bersih, setelah 7 menit, tuang adonan hijau, kukus 15 mwnit, hati2 yah dng menuangkan adonan putih atau hijau, krn takir cenderung lembek sehingga mempengaruhi dari bentuk takir."
- "Kue Tobu &#39;u ini ternyata kue khas dari Gorontalo, wah lumayan jauh yah kotanya, kue ini hampir sama dng bubur sumsum di jawa, hanya yg membedakan yaitu wadah takir dan bahan mayoritas nya terigu, kl bubur sumsum mayoritas bahannya tepung beras. Tp sama2 enak😍😍"
categories:
- Resep
tags:
- kue
- tobu
- u

katakunci: kue tobu u 
nutrition: 188 calories
recipecuisine: Indonesian
preptime: "PT11M"
cooktime: "PT34M"
recipeyield: "1"
recipecategory: Dinner

---


![Kue Tobu &#39;u 3 lapis (Kue Khas Gorontalo)](https://img-global.cpcdn.com/recipes/bd373c3f472eb7d9/751x532cq70/kue-tobu-u-3-lapis-kue-khas-gorontalo-foto-resep-utama.jpg)


kue tobu &#39;u 3 lapis (kue khas gorontalo) ini yaitu kuliner tanah air yang nikmat dan harus untuk kita coba. Cita rasanya yang mantap membuat siapa pun menantikan kehadirannya di meja makan.
Kamu Sedang mencari ide resep kue tobu &#39;u 3 lapis (kue khas gorontalo) untuk jualan atau dikonsumsi sendiri yang Enak Banget? Cara menyiapkannya memang susah-susah gampang. Jika keliru mengolah maka hasilnya tidak akan memuaskan dan bahkan tidak sedap. Padahal kue tobu &#39;u 3 lapis (kue khas gorontalo) yang enak seharusnya memiliki aroma dan cita rasa yang dapat memancing selera kita.

Ada beberapa hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari kue tobu &#39;u 3 lapis (kue khas gorontalo), mulai dari jenis bahan, lalu pemilihan bahan segar, sampai cara membuat dan menyajikannya. Tak perlu pusing jika mau menyiapkan kue tobu &#39;u 3 lapis (kue khas gorontalo) enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini mampu jadi suguhan spesial.




Nah, kali ini kita coba, yuk, buat kue tobu &#39;u 3 lapis (kue khas gorontalo) sendiri di rumah. Tetap berbahan sederhana, hidangan ini dapat memberi manfaat untuk membantu menjaga kesehatan tubuhmu sekeluarga. Anda dapat membuat Kue Tobu &#39;u 3 lapis (Kue Khas Gorontalo) memakai 10 bahan dan 5 tahap pembuatan. Berikut ini langkah-langkah dalam menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk menyiapkan Kue Tobu &#39;u 3 lapis (Kue Khas Gorontalo):

1. Ambil  ☘️Bahan bahan
1. Sediakan  Daun pisang di sesuaikan penggunaannya
1. Siapkan 2 lembar daun pandan, dipotong potong di jadikan alas takir
1. Gunakan 5 sdm tepung terigu serbaguna
1. Ambil 2 sdm tepung beras (tambahan saya)
1. Siapkan 4 sdm gula pasir (semula 2 sdm)
1. Gunakan 300 ml santan dari segitiga snatan 65m +235 ml air, semula 270ml
1. Sediakan 100 gram gula jawa, serut2 tipis
1. Gunakan 2 tetes pasta pandan
1. Gunakan Seujung sdt garam




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Kue Tobu &#39;u 3 lapis (Kue Khas Gorontalo):

1. Sebelum di bentuk menjadi takir, jemur dulu di sinar matahari atau panaskan di atas api kompor daun pisangnya supaya menjadi lemas tdk kaku, sehingga memudahkan untk membuat takir. Bentuk menjadi takir dng mengunci menggunakan steples,. Baru potong2 daun pandan sesuai panjang takir, tata di atasnya
1. Lalu cairkan segitiga santan dng air 235 ml, setelah itu campurkan tepung terigu dan tepung beras dan gula pasir, aduk merata, lalu tuang santan kedalamnya sambil diaduk aduk
1. Setelah itu saring supaya menghilangkan yg bergerindil. Lalu bagi menjadi 2, yg pertama biarkan putih, lalu beri garam,aduk aduk dan bagian berikutnya beri pasta pandan, aduk aduk.
1. Panaskan panci kukusan, lalu sambil menunggu mendidih airnya, beri masing masing takir serutan gula merah secukupnya, lalu masukan adonan putih diatas serutan gula merah, tutup panci jng lupa dibungkus kain serbet bersih, setelah 7 menit, tuang adonan hijau, kukus 15 mwnit, hati2 yah dng menuangkan adonan putih atau hijau, krn takir cenderung lembek sehingga mempengaruhi dari bentuk takir.
1. Kue Tobu &#39;u ini ternyata kue khas dari Gorontalo, wah lumayan jauh yah kotanya, kue ini hampir sama dng bubur sumsum di jawa, hanya yg membedakan yaitu wadah takir dan bahan mayoritas nya terigu, kl bubur sumsum mayoritas bahannya tepung beras. Tp sama2 enak😍😍




Terima kasih telah menggunakan resep yang kami tampilkan di halaman ini. Besar harapan kami, olahan Kue Tobu &#39;u 3 lapis (Kue Khas Gorontalo) yang mudah di atas dapat membantu Anda menyiapkan makanan yang enak untuk keluarga/teman maupun menjadi inspirasi bagi Anda yang berkeinginan untuk berjualan makanan. Selamat mencoba!
