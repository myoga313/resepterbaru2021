---
description: "Bumbu Bolu Kukus Semangka | Cara Membuat Bolu Kukus Semangka Yang Mudah Dan Praktis"
title: "Bumbu Bolu Kukus Semangka | Cara Membuat Bolu Kukus Semangka Yang Mudah Dan Praktis"
slug: 224-bumbu-bolu-kukus-semangka-cara-membuat-bolu-kukus-semangka-yang-mudah-dan-praktis
date: 2020-10-27T04:20:49.131Z
image: https://img-global.cpcdn.com/recipes/8af05f5b1da6cb4f/751x532cq70/bolu-kukus-semangka-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/8af05f5b1da6cb4f/751x532cq70/bolu-kukus-semangka-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/8af05f5b1da6cb4f/751x532cq70/bolu-kukus-semangka-foto-resep-utama.jpg
author: Theodore Wright
ratingvalue: 3.8
reviewcount: 14
recipeingredient:
- "2 butir telur"
- "125 gr gula pasir"
- "1/3 sdt SP"
- "1/4 sdt garam"
- "1/2 sdt vanili bubuk"
- "150 gr tepung terigu"
- "100 ml susu uht plain resep asli  santan"
- "50 ml minyak goreng baru"
- "1 sdm Meises"
- " Pewarna makanan hijau dan merah"
recipeinstructions:
- "Mixer telur, gula, garam, vanili dan SP sampai kental, putih berjejak. Tambahkan tepung terigu yang telah diayak. Mixer dengan kecepatan rendah asal rata saja. Masukkan susu dan minyak. Mixer asal rata saja."
- "Bagi adonan menjadi 3 warna hijau untuk kulit semangka, putih untuk daging semangka, dan merah untuk daging semangka yang manis. Untuk warna putih dan hijau cukup sedikit saja. Untuk warna merah, bisa dicampur Meises sebagai biji. Kemudian aduk balik dengan spatula (Gambar terakhir pakai Blitz motonya jadi warna kurang jelas)."
- "Siapkan kukusan dengan tutup yang diberi serbet agar air tidak menetes. Setelah panas. Masukkan loyang yang telah dioles minyak, tuang warna hijau. Tutup selama 5 menit. Tuang warna putih. Tutup lagi 5 menit. Yang terakhir tuang warna merah masak selama 15 menit. Angkat setelah matang dinginkan."
- "Siap dipotong-potong dan disajikan."
categories:
- Resep
tags:
- bolu
- kukus
- semangka

katakunci: bolu kukus semangka 
nutrition: 151 calories
recipecuisine: Indonesian
preptime: "PT18M"
cooktime: "PT43M"
recipeyield: "4"
recipecategory: Dessert

---


![Bolu Kukus Semangka](https://img-global.cpcdn.com/recipes/8af05f5b1da6cb4f/751x532cq70/bolu-kukus-semangka-foto-resep-utama.jpg)


bolu kukus semangka ini yakni sajian tanah air yang spesial dan perlu untuk kita coba. Cita rasanya yang sedap membuat siapa pun menantikan kehadirannya di meja makan.
Anda sedang mencari inspirasi resep bolu kukus semangka untuk jualan atau dikonsumsi sendiri yang Enak Dan Mudah? Cara menyiapkannya memang tidak terlalu sulit namun tidak gampang juga. kalau salah mengolah maka hasilnya tidak akan memuaskan dan bahkan tidak sedap. Padahal bolu kukus semangka yang enak seharusnya mempunyai aroma dan rasa yang dapat memancing selera kita.



Ada beberapa hal yang sedikit banyak mempengaruhi kualitas rasa dari bolu kukus semangka, pertama dari jenis bahan, kemudian pemilihan bahan segar sampai cara mengolah dan menghidangkannya. Tidak usah pusing jika mau menyiapkan bolu kukus semangka enak di rumah, karena asal sudah tahu triknya maka hidangan ini bisa menjadi sajian istimewa.


Nah, kali ini kita coba, yuk, variasikan bolu kukus semangka sendiri di rumah. Tetap dengan bahan sederhana, hidangan ini dapat memberi manfaat untuk membantu menjaga kesehatan tubuh kita. Anda bisa menyiapkan Bolu Kukus Semangka memakai 10 jenis bahan dan 4 langkah pembuatan. Berikut ini langkah-langkah dalam menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk pembuatan Bolu Kukus Semangka:

1. Gunakan 2 butir telur
1. Gunakan 125 gr gula pasir
1. Siapkan 1/3 sdt SP
1. Ambil 1/4 sdt garam
1. Ambil 1/2 sdt vanili bubuk
1. Gunakan 150 gr tepung terigu
1. Sediakan 100 ml susu uht plain (resep asli : santan)
1. Siapkan 50 ml minyak goreng baru
1. Sediakan 1 sdm Meises
1. Ambil  Pewarna makanan: hijau dan merah




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Bolu Kukus Semangka:

1. Mixer telur, gula, garam, vanili dan SP sampai kental, putih berjejak. Tambahkan tepung terigu yang telah diayak. Mixer dengan kecepatan rendah asal rata saja. Masukkan susu dan minyak. Mixer asal rata saja.
1. Bagi adonan menjadi 3 warna hijau untuk kulit semangka, putih untuk daging semangka, dan merah untuk daging semangka yang manis. Untuk warna putih dan hijau cukup sedikit saja. Untuk warna merah, bisa dicampur Meises sebagai biji. Kemudian aduk balik dengan spatula (Gambar terakhir pakai Blitz motonya jadi warna kurang jelas).
1. Siapkan kukusan dengan tutup yang diberi serbet agar air tidak menetes. Setelah panas. Masukkan loyang yang telah dioles minyak, tuang warna hijau. Tutup selama 5 menit. Tuang warna putih. Tutup lagi 5 menit. Yang terakhir tuang warna merah masak selama 15 menit. Angkat setelah matang dinginkan.
1. Siap dipotong-potong dan disajikan.




Bagaimana? Mudah bukan? Itulah cara membuat bolu kukus semangka yang bisa Anda praktikkan di rumah. Selamat mencoba!
