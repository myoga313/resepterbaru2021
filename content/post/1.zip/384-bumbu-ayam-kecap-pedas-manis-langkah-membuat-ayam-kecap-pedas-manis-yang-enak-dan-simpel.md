---
description: "Bumbu Ayam Kecap Pedas Manis | Langkah Membuat Ayam Kecap Pedas Manis Yang Enak dan Simpel"
title: "Bumbu Ayam Kecap Pedas Manis | Langkah Membuat Ayam Kecap Pedas Manis Yang Enak dan Simpel"
slug: 384-bumbu-ayam-kecap-pedas-manis-langkah-membuat-ayam-kecap-pedas-manis-yang-enak-dan-simpel
date: 2020-12-22T11:47:33.637Z
image: https://img-global.cpcdn.com/recipes/1190e8c2cbb1b966/751x532cq70/ayam-kecap-pedas-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/1190e8c2cbb1b966/751x532cq70/ayam-kecap-pedas-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/1190e8c2cbb1b966/751x532cq70/ayam-kecap-pedas-manis-foto-resep-utama.jpg
author: Louis Barton
ratingvalue: 4.2
reviewcount: 9
recipeingredient:
- "500 gr ayam"
- "2 buah jeruk kencinipis"
- "2 sdt garam"
- "2 sdt kaldu jamur"
- "3 sdm kecap manis"
- "2 sdm kecap asin"
- "2 sdm saus tiram"
- "secukupnya Minyak"
- " Bumbu Tumis "
- "4 siung bawang merah iris"
- "2 siung bawang putih iris"
- "1/2 siung bawang bombay iris"
- "5 buah cabe rawit iris"
- "2 buah cabe merah iris"
- "1 batang daun bawang iris"
- "1 cm jahe iris"
recipeinstructions:
- "Potong ayam sesuai selera, cuci bersih, baluri dengan jeruk kunci/nipis dan garam sekitar 10 menit, tiriskan"
- "Goreng ayam hingga matang kecoklatan, tiriskan"
- "Tumis bumbu irisan hingga harum dan matang, masukkan ayam, aduk~aduk merata"
- "Tambahkan kecap manis, kecap asin, saus tiram, dan kaldu jamur, aduk meresap"
- "Angkat dan sajikan dengan perasaan yang hangat 😄"
categories:
- Resep
tags:
- ayam
- kecap
- pedas

katakunci: ayam kecap pedas 
nutrition: 244 calories
recipecuisine: Indonesian
preptime: "PT10M"
cooktime: "PT54M"
recipeyield: "2"
recipecategory: Dinner

---


![Ayam Kecap Pedas Manis](https://img-global.cpcdn.com/recipes/1190e8c2cbb1b966/751x532cq70/ayam-kecap-pedas-manis-foto-resep-utama.jpg)


ayam kecap pedas manis ini yaitu santapan nusantara yang unik dan harus untuk kita coba. Cita rasanya yang lezat membuat siapa pun menantikan kehadirannya di meja makan.
Anda sedang mencari inspirasi resep ayam kecap pedas manis untuk jualan atau dikonsumsi sendiri yang Bisa Manjain Lidah? Cara Bikinnya memang susah-susah gampang. seumpama salah mengolah maka hasilnya tidak akan memuaskan dan bahkan tidak sedap. Padahal ayam kecap pedas manis yang enak selayaknya memiliki aroma dan rasa yang dapat memancing selera kita.

Banyak hal yang sedikit banyak mempengaruhi kualitas rasa dari ayam kecap pedas manis, mulai dari jenis bahan, lalu pemilihan bahan segar, sampai cara mengolah dan menyajikannya. Tidak usah pusing kalau hendak menyiapkan ayam kecap pedas manis yang enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini mampu jadi sajian spesial.




Nah, kali ini kita coba, yuk, variasikan ayam kecap pedas manis sendiri di rumah. Tetap berbahan yang sederhana, sajian ini bisa memberi manfaat dalam membantu menjaga kesehatan tubuh kita. Anda dapat menyiapkan Ayam Kecap Pedas Manis memakai 16 jenis bahan dan 5 langkah pembuatan. Berikut ini langkah-langkah untuk menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam menyiapkan Ayam Kecap Pedas Manis:

1. Sediakan 500 gr ayam
1. Sediakan 2 buah jeruk kenci/nipis
1. Siapkan 2 sdt garam
1. Sediakan 2 sdt kaldu jamur
1. Siapkan 3 sdm kecap manis
1. Ambil 2 sdm kecap asin
1. Siapkan 2 sdm saus tiram
1. Ambil secukupnya Minyak
1. Siapkan  Bumbu Tumis :
1. Gunakan 4 siung bawang merah, iris
1. Gunakan 2 siung bawang putih, iris
1. Siapkan 1/2 siung bawang bombay, iris
1. Gunakan 5 buah cabe rawit, iris
1. Sediakan 2 buah cabe merah, iris
1. Sediakan 1 batang daun bawang, iris
1. Siapkan 1 cm jahe, iris




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Ayam Kecap Pedas Manis:

1. Potong ayam sesuai selera, cuci bersih, baluri dengan jeruk kunci/nipis dan garam sekitar 10 menit, tiriskan
1. Goreng ayam hingga matang kecoklatan, tiriskan
1. Tumis bumbu irisan hingga harum dan matang, masukkan ayam, aduk~aduk merata
1. Tambahkan kecap manis, kecap asin, saus tiram, dan kaldu jamur, aduk meresap
1. Angkat dan sajikan dengan perasaan yang hangat 😄




Terima kasih telah menggunakan resep yang kami tampilkan di halaman ini. Besar harapan kami, olahan Ayam Kecap Pedas Manis yang mudah di atas dapat membantu Anda menyiapkan makanan yang menarik untuk keluarga/teman ataupun menjadi ide dalam berbisnis kuliner. Selamat mencoba!
