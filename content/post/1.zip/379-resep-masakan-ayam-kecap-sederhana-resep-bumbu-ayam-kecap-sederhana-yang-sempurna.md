---
description: "Resep masakan Ayam Kecap sederhana | Resep Bumbu Ayam Kecap sederhana Yang Sempurna"
title: "Resep masakan Ayam Kecap sederhana | Resep Bumbu Ayam Kecap sederhana Yang Sempurna"
slug: 379-resep-masakan-ayam-kecap-sederhana-resep-bumbu-ayam-kecap-sederhana-yang-sempurna
date: 2020-09-01T07:00:38.055Z
image: https://img-global.cpcdn.com/recipes/fe567c4d08cfa524/751x532cq70/ayam-kecap-sederhana-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/fe567c4d08cfa524/751x532cq70/ayam-kecap-sederhana-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/fe567c4d08cfa524/751x532cq70/ayam-kecap-sederhana-foto-resep-utama.jpg
author: Emma Dunn
ratingvalue: 3.4
reviewcount: 8
recipeingredient:
- " Ayam potongpotong sesuai selera"
- " tahu iris serong lalu goreng setengah kering"
- " Bumbu Uleg"
- " cabe rawit bisa ditambah jika suka pedas"
- " cabe merah besar"
- " bawang putih"
- " bawang merah"
- " kemiri"
- " tomat"
- " Bumbu Cemplung"
- " daun jeruk"
- " daun salam"
- " daun sereh"
- " Kecap Manis"
- " cabe rawit hijau"
- " garam"
- " penyedap jamur"
- " santan kental kr"
recipeinstructions:
- "Cuci bersih ayam lalu masak sebentar. Angkat lalu tiriskan"
- "Goreng ayam hingga setengah matang"
- "Haluskan semua bumbu"
- "Panaskan minyak lalu goreng bumbu hingga harum, kasih air aduk rata biarkan mendidih"
- "Kemudian masukkan ayam, tahu dan bumbu lainnya (daun salam, daun jeruk, serai, cabe rawit hijau, garam penyedap jamur, kecap dan santan). Aduk rata, tunggu sampai mendidih. koreksi rasa. dan angkat"
- "Ayam siap dihidangkan dengan nasi hangat.. Selamat mencoba"
categories:
- Resep
tags:
- ayam
- kecap
- sederhana

katakunci: ayam kecap sederhana 
nutrition: 174 calories
recipecuisine: Indonesian
preptime: "PT32M"
cooktime: "PT48M"
recipeyield: "4"
recipecategory: Dessert

---


![Ayam Kecap sederhana](https://img-global.cpcdn.com/recipes/fe567c4d08cfa524/751x532cq70/ayam-kecap-sederhana-foto-resep-utama.jpg)


ayam kecap sederhana ini merupakan sajian nusantara yang enak dan wajib untuk kita coba. Cita rasanya yang lezat membuat siapa pun menantikan kehadirannya di meja makan.
Bunda lagi mencari ide resep ayam kecap sederhana untuk jualan atau dikonsumsi sendiri yang Enak Banget? Cara membuatnya memang tidak terlalu sulit namun tidak gampang juga. andaikan keliru mengolah maka hasilnya Tidak Memuaskan dan bahkan tidak sedap. Padahal ayam kecap sederhana yang enak selayaknya mempunyai aroma dan cita rasa yang bisa memancing selera kita.



Ada beberapa hal yang sedikit banyak mempengaruhi kualitas rasa dari ayam kecap sederhana, mulai dari jenis bahan, lalu pemilihan bahan segar hingga cara membuat dan menyajikannya. Tak perlu pusing jika ingin menyiapkan ayam kecap sederhana yang enak di rumah, karena asal sudah tahu triknya maka hidangan ini mampu jadi suguhan istimewa.


Nah, kali ini kita coba, yuk, siapkan ayam kecap sederhana sendiri di rumah. Tetap berbahan sederhana, hidangan ini dapat memberi manfaat untuk membantu menjaga kesehatan tubuh kita. Anda bisa menyiapkan Ayam Kecap sederhana memakai 18 bahan dan 6 langkah pembuatan. Berikut ini langkah-langkah untuk menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk pembuatan Ayam Kecap sederhana:

1. Sediakan  Ayam potong-potong sesuai selera
1. Gunakan  tahu iris serong lalu goreng setengah kering
1. Sediakan  Bumbu Uleg
1. Siapkan  cabe rawit (bisa ditambah jika suka pedas)
1. Gunakan  cabe merah besar
1. Ambil  bawang putih
1. Ambil  bawang merah
1. Siapkan  kemiri
1. Sediakan  tomat
1. Ambil  Bumbu Cemplung
1. Ambil  daun jeruk
1. Sediakan  daun salam
1. Gunakan  daun sereh
1. Sediakan  Kecap Manis
1. Gunakan  cabe rawit hijau
1. Ambil  garam
1. Ambil  penyedap jamur
1. Ambil  santan kental (k*r*)




<!--inarticleads2-->

##### Cara membuat Ayam Kecap sederhana:

1. Cuci bersih ayam lalu masak sebentar. Angkat lalu tiriskan
1. Goreng ayam hingga setengah matang
1. Haluskan semua bumbu
1. Panaskan minyak lalu goreng bumbu hingga harum, kasih air aduk rata biarkan mendidih
1. Kemudian masukkan ayam, tahu dan bumbu lainnya (daun salam, daun jeruk, serai, cabe rawit hijau, garam penyedap jamur, kecap dan santan). Aduk rata, tunggu sampai mendidih. koreksi rasa. dan angkat
1. Ayam siap dihidangkan dengan nasi hangat.. Selamat mencoba




Terima kasih telah membaca resep yang kami tampilkan di halaman ini. Besar harapan kami, olahan Ayam Kecap sederhana yang mudah di atas dapat membantu Anda menyiapkan hidangan yang enak untuk keluarga/teman ataupun menjadi ide bagi Anda yang berkeinginan untuk berjualan makanan. Semoga bermanfaat dan selamat mencoba!
