---
description: "Olahan Bolu Kukus Ice Cream | Cara Masak Bolu Kukus Ice Cream Yang Menggugah Selera"
title: "Olahan Bolu Kukus Ice Cream | Cara Masak Bolu Kukus Ice Cream Yang Menggugah Selera"
slug: 217-olahan-bolu-kukus-ice-cream-cara-masak-bolu-kukus-ice-cream-yang-menggugah-selera
date: 2020-08-10T17:09:52.383Z
image: https://img-global.cpcdn.com/recipes/774d62e18a9891a9/751x532cq70/bolu-kukus-ice-cream-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/774d62e18a9891a9/751x532cq70/bolu-kukus-ice-cream-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/774d62e18a9891a9/751x532cq70/bolu-kukus-ice-cream-foto-resep-utama.jpg
author: Amy Price
ratingvalue: 4.9
reviewcount: 13
recipeingredient:
- "150 gram tepung terigu"
- "75 ml santan"
- "75 ml minyak goreng"
- "1 sdt bubuk coklat"
- " Pasta sesuai selerastrawberry coklat pandan pewarna kuning"
- " Kacang tanah sangrai cincang kasar"
recipeinstructions:
- "Panaskan kukusan. Alasi tutup dengan kain bersih. (Sy pakai klakat) Lapisi cetakan cone dengan baking paper."
- "Mixer telur, gula pasir dan sp dengan kecepatan tinggi sampai mengembang, putih dan berjejak."
- "Masukkan tepung terigu, aduk balik dengan spatula hingga rata."
- "Masukkan santan dan minyak, aduk balik perlahan dengan spatula."
- "Bagi jadi beberapa adonan. Beri setiap Adonan dengan warna pasta yg diinginkan. Masukkan tiap adonan ke dalam piping bag."
- "Tuang dalam cetakan secara berurutan: setiap warna adonan yg diinginkan"
- "Kukus dengan api sedang cenderung kecil selama 15 menit. Angkat dan dinginkan. Bolu jangan dilepas dulu dari baking paper, karena akan diberi topping."
- "Setelah dingin, permukaan atas bolu diberi topping coklat blok yang dilelehkan (bisa gunakan piping bag supaya rapi). Lalu taburi kacang sangrai."
- "Setelah topping kering, lepaskan baking paper, dan sajikan."
categories:
- Resep
tags:
- bolu
- kukus
- ice

katakunci: bolu kukus ice 
nutrition: 294 calories
recipecuisine: Indonesian
preptime: "PT11M"
cooktime: "PT56M"
recipeyield: "3"
recipecategory: Dessert

---


![Bolu Kukus Ice Cream](https://img-global.cpcdn.com/recipes/774d62e18a9891a9/751x532cq70/bolu-kukus-ice-cream-foto-resep-utama.jpg)


bolu kukus ice cream ini merupakan santapan nusantara yang mantap dan harus untuk kita coba. Cita rasanya yang sedap membuat siapa pun menantikan kehadirannya di meja makan.
Sedang mencari ide resep bolu kukus ice cream untuk jualan atau dikonsumsi sendiri yang Mudah Dan Praktis? Cara membuatnya memang susah-susah gampang. Jika salah mengolah maka hasilnya Tidak Memuaskan dan justru cenderung tidak enak. Padahal bolu kukus ice cream yang enak seharusnya punya aroma dan rasa yang mampu memancing selera kita.

Banyak hal yang sedikit banyak mempengaruhi kualitas rasa dari bolu kukus ice cream, mulai dari jenis bahan, lalu pemilihan bahan segar, sampai cara membuat dan menyajikannya. Tidak usah pusing jika hendak menyiapkan bolu kukus ice cream enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini dapat jadi sajian istimewa.




Di bawah ini ada beberapa tips dan trik praktis dalam mengolah bolu kukus ice cream yang siap dikreasikan. Anda dapat membuat Bolu Kukus Ice Cream memakai 6 jenis bahan dan 9 langkah pembuatan. Berikut ini cara dalam menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam menyiapkan Bolu Kukus Ice Cream:

1. Siapkan 150 gram tepung terigu
1. Ambil 75 ml santan
1. Gunakan 75 ml minyak goreng
1. Gunakan 1 sdt bubuk coklat
1. Gunakan  Pasta sesuai selera(strawberry, coklat, pandan, pewarna kuning)
1. Sediakan  Kacang tanah (sangrai, cincang kasar)




<!--inarticleads2-->

##### Langkah-langkah membuat Bolu Kukus Ice Cream:

1. Panaskan kukusan. Alasi tutup dengan kain bersih. (Sy pakai klakat) Lapisi cetakan cone dengan baking paper.
1. Mixer telur, gula pasir dan sp dengan kecepatan tinggi sampai mengembang, putih dan berjejak.
1. Masukkan tepung terigu, aduk balik dengan spatula hingga rata.
1. Masukkan santan dan minyak, aduk balik perlahan dengan spatula.
1. Bagi jadi beberapa adonan. Beri setiap Adonan dengan warna pasta yg diinginkan. Masukkan tiap adonan ke dalam piping bag.
1. Tuang dalam cetakan secara berurutan: setiap warna adonan yg diinginkan
1. Kukus dengan api sedang cenderung kecil selama 15 menit. Angkat dan dinginkan. Bolu jangan dilepas dulu dari baking paper, karena akan diberi topping.
1. Setelah dingin, permukaan atas bolu diberi topping coklat blok yang dilelehkan (bisa gunakan piping bag supaya rapi). Lalu taburi kacang sangrai.
1. Setelah topping kering, lepaskan baking paper, dan sajikan.




Bagaimana? Gampang kan? Itulah cara membuat bolu kukus ice cream yang bisa Anda lakukan di rumah. Selamat mencoba!
