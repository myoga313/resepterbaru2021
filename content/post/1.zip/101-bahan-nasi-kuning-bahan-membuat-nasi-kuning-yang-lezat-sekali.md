---
description: "Bahan Nasi kuning | Bahan Membuat Nasi kuning Yang Lezat Sekali"
title: "Bahan Nasi kuning | Bahan Membuat Nasi kuning Yang Lezat Sekali"
slug: 101-bahan-nasi-kuning-bahan-membuat-nasi-kuning-yang-lezat-sekali
date: 2020-12-05T01:02:43.337Z
image: https://img-global.cpcdn.com/recipes/0ce78f2dade268d6/751x532cq70/nasi-kuning-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/0ce78f2dade268d6/751x532cq70/nasi-kuning-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/0ce78f2dade268d6/751x532cq70/nasi-kuning-foto-resep-utama.jpg
author: Evan Gilbert
ratingvalue: 3.1
reviewcount: 15
recipeingredient:
- " beras"
- " santan kara"
- " air"
- " kunyit bubuk"
- " serai geprek"
- " lb daun salam"
- " Garam"
- " Gula"
- " Bumbu halus "
- " bawang putih"
- " bawang merah"
- " jahe"
recipeinstructions:
- "Tumis bumbu halus hingga harum. Tambahkan serai dan daun salam. Tumis."
- "Tambahkan kunyit bubuk, air, garam, gula, dan santan ke dalam tumisan bumbu. Tes rasa. Jika pas, matikan api."
- "Cuci beras, tuanglan air bumbu ke beras yg sudah dicuci."
- "Masak hingga matang seperti masak nasi biasa pakai rice cooker."
- "Aduk aduk jika nasi sudah matang."
categories:
- Resep
tags:
- nasi
- kuning

katakunci: nasi kuning 
nutrition: 163 calories
recipecuisine: Indonesian
preptime: "PT30M"
cooktime: "PT47M"
recipeyield: "1"
recipecategory: Dessert

---


![Nasi kuning](https://img-global.cpcdn.com/recipes/0ce78f2dade268d6/751x532cq70/nasi-kuning-foto-resep-utama.jpg)


nasi kuning ini ialah suguhan nusantara yang lezat dan harus untuk kita coba. Cita rasanya yang nikmat membuat siapa pun menantikan kehadirannya di meja makan.
Bunda lagi mencari inspirasi resep nasi kuning untuk jualan atau dikonsumsi sendiri yang Sedap? Cara Memasaknya memang tidak terlalu sulit namun tidak gampang juga. kalau salah mengolah maka hasilnya akan hambar dan justru cenderung tidak enak. Padahal nasi kuning yang enak selayaknya memiliki aroma dan cita rasa yang bisa memancing selera kita.



Ada beberapa hal yang sedikit banyak mempengaruhi kualitas rasa dari nasi kuning, pertama dari jenis bahan, kemudian pemilihan bahan segar hingga cara mengolah dan menyajikannya. Tidak usah pusing jika mau menyiapkan nasi kuning enak di rumah, karena asal sudah tahu triknya maka hidangan ini mampu jadi sajian istimewa.


Berikut ini ada beberapa cara mudah dan praktis untuk membuat nasi kuning yang siap dikreasikan. Anda dapat membuat Nasi kuning menggunakan 12 bahan dan 5 tahap pembuatan. Berikut ini langkah-langkah untuk membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk pembuatan Nasi kuning:

1. Gunakan  beras
1. Sediakan  santan kara
1. Ambil  air
1. Siapkan  kunyit bubuk
1. Gunakan  serai geprek
1. Gunakan  lb daun salam
1. Gunakan  Garam
1. Gunakan  Gula
1. Sediakan  Bumbu halus :
1. Gunakan  bawang putih
1. Ambil  bawang merah
1. Ambil  jahe




<!--inarticleads2-->

##### Cara menyiapkan Nasi kuning:

1. Tumis bumbu halus hingga harum. Tambahkan serai dan daun salam. Tumis.
1. Tambahkan kunyit bubuk, air, garam, gula, dan santan ke dalam tumisan bumbu. Tes rasa. Jika pas, matikan api.
1. Cuci beras, tuanglan air bumbu ke beras yg sudah dicuci.
1. Masak hingga matang seperti masak nasi biasa pakai rice cooker.
1. Aduk aduk jika nasi sudah matang.




Gimana nih? Gampang kan? Itulah cara menyiapkan nasi kuning yang bisa Anda lakukan di rumah. Selamat mencoba!
