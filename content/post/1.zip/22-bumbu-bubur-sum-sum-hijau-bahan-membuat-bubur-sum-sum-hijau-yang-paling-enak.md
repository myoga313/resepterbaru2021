---
description: "Bumbu Bubur Sum-sum Hijau | Bahan Membuat Bubur Sum-sum Hijau Yang Paling Enak"
title: "Bumbu Bubur Sum-sum Hijau | Bahan Membuat Bubur Sum-sum Hijau Yang Paling Enak"
slug: 22-bumbu-bubur-sum-sum-hijau-bahan-membuat-bubur-sum-sum-hijau-yang-paling-enak
date: 2020-08-03T07:53:54.518Z
image: https://img-global.cpcdn.com/recipes/b01b3ba56fa6ae4e/751x532cq70/bubur-sum-sum-hijau-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/b01b3ba56fa6ae4e/751x532cq70/bubur-sum-sum-hijau-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/b01b3ba56fa6ae4e/751x532cq70/bubur-sum-sum-hijau-foto-resep-utama.jpg
author: Howard Washington
ratingvalue: 3.3
reviewcount: 15
recipeingredient:
- "10 sdm 100 gr tepung beras"
- "1 bks santan kara uk 65 ml"
- "1 lbr daun pandan me 23 tetes perasa pandan warna hijau"
- "1 sdt garam"
- "800 ml air"
- " Kinca sirup gula "
- "100 gram gula merah"
- "11/2 gelas air100 ml"
- "1 lbr daun pandan me 1 tetes perasa pandan"
- "Sejumput garam"
recipeinstructions:
- "Siapkan bahan2. Campur 800 ml air dengan santan kara dan perasa pandan, aduk rata. Sisihkan santan 300 ml dan tuangkan ke tepung beras sedikit2 sambil diaduk agar tidak bergerindil. Sisihkan."
- "Masak 500 ml santan sampai hampir mendidih, kecilkan api. Tuang cairan tepung beras ke dalam santan sambil diaduk sampai santan habis dan adonan meletup- letup. Matikan api, sisihkan."
- "Masak gula merah dengan air, daun pandan dan sejumput garam sampai mendidih. Matikan api. Dinginkan lalu saring."
- "Sajikan bubur dengan kincanya."
categories:
- Resep
tags:
- bubur
- sumsum
- hijau

katakunci: bubur sumsum hijau 
nutrition: 281 calories
recipecuisine: Indonesian
preptime: "PT37M"
cooktime: "PT54M"
recipeyield: "3"
recipecategory: Dinner

---


![Bubur Sum-sum Hijau](https://img-global.cpcdn.com/recipes/b01b3ba56fa6ae4e/751x532cq70/bubur-sum-sum-hijau-foto-resep-utama.jpg)


bubur sum-sum hijau ini ialah suguhan nusantara yang istimewa dan wajib untuk kita coba. Cita rasanya yang lezat membuat siapa pun menantikan kehadirannya di meja makan.
Kamu Sedang mencari ide resep bubur sum-sum hijau untuk jualan atau dikonsumsi sendiri yang Enak Banget? Cara Buatnya memang susah-susah gampang. seandainya salah mengolah maka hasilnya akan hambar dan bahkan tidak sedap. Padahal bubur sum-sum hijau yang enak selayaknya punya aroma dan cita rasa yang dapat memancing selera kita.



Ada beberapa hal yang sedikit banyak mempengaruhi kualitas rasa dari bubur sum-sum hijau, pertama dari jenis bahan, lalu pemilihan bahan segar sampai cara membuat dan menghidangkannya. Tidak usah pusing kalau mau menyiapkan bubur sum-sum hijau yang enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini bisa menjadi sajian istimewa.


Nah, kali ini kita coba, yuk, siapkan bubur sum-sum hijau sendiri di rumah. Tetap berbahan sederhana, hidangan ini bisa memberi manfaat untuk membantu menjaga kesehatan tubuh kita. Anda bisa membuat Bubur Sum-sum Hijau menggunakan 10 bahan dan 4 langkah pembuatan. Berikut ini langkah-langkah untuk menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk pembuatan Bubur Sum-sum Hijau:

1. Gunakan 10 sdm/ 100 gr tepung beras
1. Siapkan 1 bks santan kara uk 65 ml
1. Ambil 1 lbr daun pandan (me: 2-3 tetes perasa pandan warna hijau)
1. Ambil 1 sdt garam
1. Siapkan 800 ml air
1. Siapkan  Kinca (sirup gula) :
1. Ambil 100 gram gula merah
1. Gunakan 11/2 gelas air/100 ml
1. Siapkan 1 lbr daun pandan (me: 1 tetes perasa pandan)
1. Gunakan Sejumput garam




<!--inarticleads2-->

##### Cara membuat Bubur Sum-sum Hijau:

1. Siapkan bahan2. Campur 800 ml air dengan santan kara dan perasa pandan, aduk rata. Sisihkan santan 300 ml dan tuangkan ke tepung beras sedikit2 sambil diaduk agar tidak bergerindil. Sisihkan.
1. Masak 500 ml santan sampai hampir mendidih, kecilkan api. Tuang cairan tepung beras ke dalam santan sambil diaduk sampai santan habis dan adonan meletup- letup. Matikan api, sisihkan.
1. Masak gula merah dengan air, daun pandan dan sejumput garam sampai mendidih. Matikan api. Dinginkan lalu saring.
1. Sajikan bubur dengan kincanya.




Terima kasih telah membaca resep yang kami tampilkan di sini. Besar harapan kami, olahan Bubur Sum-sum Hijau yang mudah di atas dapat membantu Anda menyiapkan makanan yang sedap untuk keluarga/teman ataupun menjadi inspirasi untuk berbisnis kuliner. Selamat mencoba!
