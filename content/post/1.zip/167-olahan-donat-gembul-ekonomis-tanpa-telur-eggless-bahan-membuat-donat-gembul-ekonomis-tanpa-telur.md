---
description: "Olahan Donat Gembul Ekonomis Tanpa Telur (Eggless) | Bahan Membuat Donat Gembul Ekonomis Tanpa Telur (Eggless) Yang Lezat"
title: "Olahan Donat Gembul Ekonomis Tanpa Telur (Eggless) | Bahan Membuat Donat Gembul Ekonomis Tanpa Telur (Eggless) Yang Lezat"
slug: 167-olahan-donat-gembul-ekonomis-tanpa-telur-eggless-bahan-membuat-donat-gembul-ekonomis-tanpa-telur-eggless-yang-lezat
date: 2020-10-29T15:39:36.742Z
image: https://img-global.cpcdn.com/recipes/8ec3a12772777525/751x532cq70/donat-gembul-ekonomis-tanpa-telur-eggless-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/8ec3a12772777525/751x532cq70/donat-gembul-ekonomis-tanpa-telur-eggless-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/8ec3a12772777525/751x532cq70/donat-gembul-ekonomis-tanpa-telur-eggless-foto-resep-utama.jpg
author: Sadie Wallace
ratingvalue: 4.2
reviewcount: 13
recipeingredient:
- " Tepung Terigu"
- " Gula Pasir"
- " Susu Bubuk Me SKM"
- " Margarin"
- " Ragi Instan"
- " Air Hangat"
- " Garam"
- " Topping Optional "
- " Meses Coklat"
- " Keju Parut"
- " Cream"
recipeinstructions:
- "Campurkan gula dan ragi instan dalam gelas, tambahkan air hangat kuku hingga 1 gelas penuh (jangan air panas yaa, punya saya tidak penuh karena ukuran gelas lebih besar dari gelas belimbing). Aduk rata, lalu diamkan selama 10-15 menit hingga berbuih."
- "Setelah 10-15 menit, air ragi akan berbuih banyak dan tinggi. Jika tidak berbuih, artinya ragi tidak aktif, ganti ragi dan ulangi langkah pertama kembali."
- "Tuang air ragi ke dalam tepung terigu sedikit demi sedikit, aduk terus hingga tercampur merata dan air habis."
- "Tambahkan susu, mentega dan garam, uleni adonan hingga kalis elastis. (Punya saya tidak sampai elastis tapi lumayan kalis, karena yang ngulenin suami jadi dimaklumi) 😁 Istirahatkan adonan selama 45-50 menit. Tutup atas wadah dengan lap bersih ya, adonan nanti akan mengembang 2x lipat."
- "Setelah mengembang, pukul-pukul adonan dan uleni sebentar saja untuk mengeluarkan udara di dalamnya."
- "Ambil adonan secukupnya, bulatkan lalu pipihkan dan beri lubang di tengahnya. Lakukan hingga adonan habis. Selagi proses ini, adonan yang dibentuk pertama akan mengembang kembali nantinya."
- "Panaskan minyak, goreng adonan yang sudah kembali mengembang dengan api sedang. Balik sekali saja, agar tidak terlalu berminyak. Jika sudah matang, angkat lalu tiriskan. Saya baru ngeh kalau ada white ring-nya 😁"
- "Oleskan cream di bagian atas donat untuk melekatkan topping, jika tidak ada bisa diganti dengan margarin + skm yang diaduk rata. Sajikan selagi hangat. Donat gembul ini renyah waktu digigit, tapi lembut di dalam. Love banget lah pokoknya. 💕"
categories:
- Resep
tags:
- donat
- gembul
- ekonomis

katakunci: donat gembul ekonomis 
nutrition: 197 calories
recipecuisine: Indonesian
preptime: "PT38M"
cooktime: "PT34M"
recipeyield: "1"
recipecategory: Dinner

---


![Donat Gembul Ekonomis Tanpa Telur (Eggless)](https://img-global.cpcdn.com/recipes/8ec3a12772777525/751x532cq70/donat-gembul-ekonomis-tanpa-telur-eggless-foto-resep-utama.jpg)


donat gembul ekonomis tanpa telur (eggless) ini ialah makanan tanah air yang spesial dan wajib untuk kita coba. Cita rasanya yang sedap membuat siapa pun menantikan kehadirannya di meja makan.
Bunda lagi mencari ide resep donat gembul ekonomis tanpa telur (eggless) untuk jualan atau dikonsumsi sendiri yang Enak Dan Lezat? Cara Bikinnya memang tidak susah dan tidak juga mudah. andaikan keliru mengolah maka hasilnya Tidak Memuaskan dan bahkan tidak sedap. Padahal donat gembul ekonomis tanpa telur (eggless) yang enak harusnya sih memiliki aroma dan cita rasa yang bisa memancing selera kita.



Ada beberapa hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari donat gembul ekonomis tanpa telur (eggless), pertama dari jenis bahan, kemudian pemilihan bahan segar hingga cara membuat dan menghidangkannya. Tidak usah pusing jika ingin menyiapkan donat gembul ekonomis tanpa telur (eggless) yang enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini dapat menjadi suguhan istimewa.


Nah, kali ini kita coba, yuk, variasikan donat gembul ekonomis tanpa telur (eggless) sendiri di rumah. Tetap dengan bahan yang sederhana, sajian ini dapat memberi manfaat dalam membantu menjaga kesehatan tubuhmu sekeluarga. Anda bisa membuat Donat Gembul Ekonomis Tanpa Telur (Eggless) menggunakan 11 bahan dan 8 tahap pembuatan. Berikut ini cara untuk menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk pembuatan Donat Gembul Ekonomis Tanpa Telur (Eggless):

1. Gunakan  Tepung Terigu
1. Siapkan  Gula Pasir
1. Sediakan  Susu Bubuk (Me: SKM)
1. Gunakan  Margarin
1. Siapkan  Ragi Instan
1. Gunakan  Air Hangat
1. Sediakan  Garam
1. Siapkan  Topping (Optional) :
1. Siapkan  Meses Coklat
1. Siapkan  Keju Parut
1. Siapkan  Cream




<!--inarticleads2-->

##### Langkah-langkah membuat Donat Gembul Ekonomis Tanpa Telur (Eggless):

1. Campurkan gula dan ragi instan dalam gelas, tambahkan air hangat kuku hingga 1 gelas penuh (jangan air panas yaa, punya saya tidak penuh karena ukuran gelas lebih besar dari gelas belimbing). Aduk rata, lalu diamkan selama 10-15 menit hingga berbuih.
1. Setelah 10-15 menit, air ragi akan berbuih banyak dan tinggi. Jika tidak berbuih, artinya ragi tidak aktif, ganti ragi dan ulangi langkah pertama kembali.
1. Tuang air ragi ke dalam tepung terigu sedikit demi sedikit, aduk terus hingga tercampur merata dan air habis.
1. Tambahkan susu, mentega dan garam, uleni adonan hingga kalis elastis. (Punya saya tidak sampai elastis tapi lumayan kalis, karena yang ngulenin suami jadi dimaklumi) 😁 Istirahatkan adonan selama 45-50 menit. Tutup atas wadah dengan lap bersih ya, adonan nanti akan mengembang 2x lipat.
1. Setelah mengembang, pukul-pukul adonan dan uleni sebentar saja untuk mengeluarkan udara di dalamnya.
1. Ambil adonan secukupnya, bulatkan lalu pipihkan dan beri lubang di tengahnya. Lakukan hingga adonan habis. Selagi proses ini, adonan yang dibentuk pertama akan mengembang kembali nantinya.
1. Panaskan minyak, goreng adonan yang sudah kembali mengembang dengan api sedang. Balik sekali saja, agar tidak terlalu berminyak. Jika sudah matang, angkat lalu tiriskan. Saya baru ngeh kalau ada white ring-nya 😁
1. Oleskan cream di bagian atas donat untuk melekatkan topping, jika tidak ada bisa diganti dengan margarin + skm yang diaduk rata. Sajikan selagi hangat. Donat gembul ini renyah waktu digigit, tapi lembut di dalam. Love banget lah pokoknya. 💕




Gimana nih? Mudah bukan? Itulah cara menyiapkan donat gembul ekonomis tanpa telur (eggless) yang bisa Anda lakukan di rumah. Semoga bermanfaat dan selamat mencoba!
