---
description: "Olahan Ayam goreng lengkuas | Cara Bikin Ayam goreng lengkuas Yang Bisa Manjain Lidah"
title: "Olahan Ayam goreng lengkuas | Cara Bikin Ayam goreng lengkuas Yang Bisa Manjain Lidah"
slug: 246-olahan-ayam-goreng-lengkuas-cara-bikin-ayam-goreng-lengkuas-yang-bisa-manjain-lidah
date: 2020-10-03T08:46:57.351Z
image: https://img-global.cpcdn.com/recipes/721067b06014b2aa/751x532cq70/ayam-goreng-lengkuas-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/721067b06014b2aa/751x532cq70/ayam-goreng-lengkuas-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/721067b06014b2aa/751x532cq70/ayam-goreng-lengkuas-foto-resep-utama.jpg
author: Beatrice Campbell
ratingvalue: 3.9
reviewcount: 12
recipeingredient:
- "1 kg ayam potong2 jadi 10"
- " lengkuas pilih yang gak keras 5bj seukuran jari"
- " bumbu halus"
- "6 btr bawang putih"
- " garam"
- "1/2 jari kunyit"
recipeinstructions:
- "Bersihkan ayam"
- "Parut lengkuas"
- "Haluskan bumbu halus"
- "Campur ayam dan bumbu halus beserta lengkuas parut kasih air secukupnya"
- "Ungkep ayam yg sudah dicampur bumbu sampai air menyusut"
- "Koreksi rasa"
- "Setelah menyusut airnya, matikan kompor"
- "Goreng ayam beserta bumbunya"
- "Siap disajikan"
categories:
- Resep
tags:
- ayam
- goreng
- lengkuas

katakunci: ayam goreng lengkuas 
nutrition: 253 calories
recipecuisine: Indonesian
preptime: "PT22M"
cooktime: "PT58M"
recipeyield: "4"
recipecategory: Lunch

---


![Ayam goreng lengkuas](https://img-global.cpcdn.com/recipes/721067b06014b2aa/751x532cq70/ayam-goreng-lengkuas-foto-resep-utama.jpg)


ayam goreng lengkuas ini yakni suguhan nusantara yang spesial dan wajib untuk kita coba. Cita rasanya yang sedap membuat siapa pun menantikan kehadirannya di meja makan.
Sedang mencari inspirasi resep ayam goreng lengkuas untuk jualan atau dikonsumsi sendiri yang Lezat? Cara Bikinnya memang tidak terlalu sulit namun tidak gampang juga. sekiranya keliru mengolah maka hasilnya tidak akan memuaskan dan justru cenderung tidak enak. Padahal ayam goreng lengkuas yang enak selayaknya memiliki aroma dan cita rasa yang dapat memancing selera kita.

Banyak hal yang sedikit banyak mempengaruhi kualitas rasa dari ayam goreng lengkuas, mulai dari jenis bahan, lalu pemilihan bahan segar, hingga cara mengolah dan menghidangkannya. Tak perlu pusing kalau ingin menyiapkan ayam goreng lengkuas enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini dapat jadi suguhan istimewa.




Nah, kali ini kita coba, yuk, siapkan ayam goreng lengkuas sendiri di rumah. Tetap dengan bahan sederhana, hidangan ini dapat memberi manfaat untuk membantu menjaga kesehatan tubuh kita. Anda bisa menyiapkan Ayam goreng lengkuas menggunakan 6 bahan dan 9 tahap pembuatan. Berikut ini langkah-langkah untuk membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk menyiapkan Ayam goreng lengkuas:

1. Siapkan 1 kg ayam potong2 jadi 10
1. Ambil  lengkuas pilih yang gak keras 5bj seukuran jari
1. Sediakan  bumbu halus
1. Siapkan 6 btr bawang putih
1. Ambil  garam
1. Siapkan 1/2 jari kunyit




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Ayam goreng lengkuas:

1. Bersihkan ayam
1. Parut lengkuas
1. Haluskan bumbu halus
1. Campur ayam dan bumbu halus beserta lengkuas parut kasih air secukupnya
1. Ungkep ayam yg sudah dicampur bumbu sampai air menyusut
1. Koreksi rasa
1. Setelah menyusut airnya, matikan kompor
1. Goreng ayam beserta bumbunya
1. Siap disajikan




Terima kasih telah membaca resep yang tim kami tampilkan di halaman ini. Harapan kami, olahan Ayam goreng lengkuas yang mudah di atas dapat membantu Anda menyiapkan makanan yang lezat untuk keluarga/teman maupun menjadi ide bagi Anda yang berkeinginan untuk berjualan makanan. Selamat mencoba!
