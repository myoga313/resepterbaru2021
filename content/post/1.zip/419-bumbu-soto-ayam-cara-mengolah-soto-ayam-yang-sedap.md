---
description: "Bumbu Soto Ayam | Cara Mengolah Soto Ayam Yang Sedap"
title: "Bumbu Soto Ayam | Cara Mengolah Soto Ayam Yang Sedap"
slug: 419-bumbu-soto-ayam-cara-mengolah-soto-ayam-yang-sedap
date: 2020-08-29T18:57:15.960Z
image: https://img-global.cpcdn.com/recipes/35b16c13b18021e3/751x532cq70/soto-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/35b16c13b18021e3/751x532cq70/soto-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/35b16c13b18021e3/751x532cq70/soto-ayam-foto-resep-utama.jpg
author: Lillian Ellis
ratingvalue: 3.7
reviewcount: 9
recipeingredient:
- "1 kg ayam"
- "2 bungkus touge"
- " Bumbu Halus"
- "5 siung bawang putih"
- "3 butir bawang merah"
- "3 butir kemiri"
- "1/2 sdt merica butiran"
- "1/8 butir pala"
- "1/4 sdt jinten"
- "2 cm kunyit"
- "1/2 cm jahe"
- "2 sdt garam"
- "1 batang daun bawang"
- "1/2 butir jeruk nipis"
- "secukupnya Bawang merah goreng"
- " Rempah Lain"
- "1 batang serai geprek"
- "2 lembar daun jeruk"
- "2 lembar daun salam"
- "1/2 cm lengkuas"
recipeinstructions:
- "Didihkan air secukupnya."
- "Cuci dan potong ayam sesuai selera."
- "Masukkan daging kedalam air mendidih. Rebus hingga empuk."
- "Panaskan 3 sdm minyak, tumis bumbu yang dihaluskan hingga harum dan berbutir halus."
- "Tambahkan rempah lainnya, aduk hingga layu"
- "Masukkan bumbu kedalam rebusan ayam dan masak terus hingga empuk"
- "Setelah empuk dan kuah sedikit menyusut, matikan api."
- "Soto ayam siap disajikan dengan tauge, daun bawang yang diiris kasar, jeruk nipis dan bawang merah goreng"
categories:
- Resep
tags:
- soto
- ayam

katakunci: soto ayam 
nutrition: 270 calories
recipecuisine: Indonesian
preptime: "PT31M"
cooktime: "PT49M"
recipeyield: "1"
recipecategory: Dinner

---


![Soto Ayam](https://img-global.cpcdn.com/recipes/35b16c13b18021e3/751x532cq70/soto-ayam-foto-resep-utama.jpg)


soto ayam ini yaitu santapan tanah air yang nikmat dan perlu untuk kita coba. Cita rasanya yang nikmat membuat siapa pun menantikan kehadirannya di meja makan.
Kamu Lagi mencari ide resep soto ayam untuk jualan atau dikonsumsi sendiri yang Enak Dan Lezat? Cara membuatnya memang tidak susah dan tidak juga mudah. semisal keliru mengolah maka hasilnya tidak akan memuaskan dan justru cenderung tidak enak. Padahal soto ayam yang enak seharusnya mempunyai aroma dan cita rasa yang dapat memancing selera kita.



Ada beberapa hal yang sedikit banyak mempengaruhi kualitas rasa dari soto ayam, mulai dari jenis bahan, kemudian pemilihan bahan segar sampai cara mengolah dan menghidangkannya. Tak perlu pusing kalau hendak menyiapkan soto ayam yang enak di rumah, karena asal sudah tahu triknya maka hidangan ini mampu menjadi suguhan istimewa.


Di bawah ini ada beberapa tips dan trik praktis untuk membuat soto ayam yang siap dikreasikan. Anda dapat membuat Soto Ayam memakai 20 bahan dan 8 tahap pembuatan. Berikut ini cara untuk membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam menyiapkan Soto Ayam:

1. Sediakan 1 kg ayam
1. Ambil 2 bungkus touge
1. Siapkan  Bumbu Halus
1. Gunakan 5 siung bawang putih
1. Siapkan 3 butir bawang merah
1. Sediakan 3 butir kemiri
1. Sediakan 1/2 sdt merica butiran
1. Siapkan 1/8 butir pala
1. Siapkan 1/4 sdt jinten
1. Gunakan 2 cm kunyit
1. Sediakan 1/2 cm jahe
1. Ambil 2 sdt garam
1. Siapkan 1 batang daun bawang
1. Ambil 1/2 butir jeruk nipis
1. Ambil secukupnya Bawang merah goreng
1. Gunakan  Rempah Lain
1. Sediakan 1 batang serai (geprek)
1. Gunakan 2 lembar daun jeruk
1. Gunakan 2 lembar daun salam
1. Gunakan 1/2 cm lengkuas




<!--inarticleads2-->

##### Cara membuat Soto Ayam:

1. Didihkan air secukupnya.
1. Cuci dan potong ayam sesuai selera.
1. Masukkan daging kedalam air mendidih. Rebus hingga empuk.
1. Panaskan 3 sdm minyak, tumis bumbu yang dihaluskan hingga harum dan berbutir halus.
1. Tambahkan rempah lainnya, aduk hingga layu
1. Masukkan bumbu kedalam rebusan ayam dan masak terus hingga empuk
1. Setelah empuk dan kuah sedikit menyusut, matikan api.
1. Soto ayam siap disajikan dengan tauge, daun bawang yang diiris kasar, jeruk nipis dan bawang merah goreng




Gimana nih? Mudah bukan? Itulah cara menyiapkan soto ayam yang bisa Anda praktikkan di rumah. Selamat mencoba!
