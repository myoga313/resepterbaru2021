---
description: "Resep masakan Bolu Pandan Lapis Coklat Kukus | Cara Bikin Bolu Pandan Lapis Coklat Kukus Yang Lezat Sekali"
title: "Resep masakan Bolu Pandan Lapis Coklat Kukus | Cara Bikin Bolu Pandan Lapis Coklat Kukus Yang Lezat Sekali"
slug: 226-resep-masakan-bolu-pandan-lapis-coklat-kukus-cara-bikin-bolu-pandan-lapis-coklat-kukus-yang-lezat-sekali
date: 2021-01-05T06:11:09.910Z
image: https://img-global.cpcdn.com/recipes/8af707a2c3ffc0c3/751x532cq70/bolu-pandan-lapis-coklat-kukus-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/8af707a2c3ffc0c3/751x532cq70/bolu-pandan-lapis-coklat-kukus-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/8af707a2c3ffc0c3/751x532cq70/bolu-pandan-lapis-coklat-kukus-foto-resep-utama.jpg
author: Lily Alvarado
ratingvalue: 4.6
reviewcount: 3
recipeingredient:
- " telur uk besar"
- " gula pasir"
- " terigu pro sedang"
- " santan mekaraair"
- " minyak sayur"
- " garam halus"
- " vanili bubuk"
- " spovalet"
- " Lapis pandan"
- " pasta pandan"
- " Lapis coklat"
- " coklat bubuk sedikit air hangat dijadikan pasta"
- " pasta coklat"
- " kental manis coklat"
recipeinstructions:
- "Kocok telur, gula, sp, garam hingga kental putih berjejak dengan mixer kec tinggi."
- "Masukkan campuran tepung, vanili bergantian dengan minyak+santan. Aduk balik atau gunakan mixer speed rendah, aduk rata sebentar saja ya."
- "Bagi 2 adonan, masing-masing beri pasta sesuai petunjuk resep atau takaran pastanya disesuaikan dengan selera."
- "Siapkan loyang persegi uk 18cm. Olesi carlo, tuang adonan coklat lebih dulu. Kukus 15 menit. Resep asli kukus 6 menit, awalnya saya coba kukus 8 menit ternyata adonan pandan bocor ke lapisan coklat. Bikinan ke 2x coba lagi kukus 10 menit adonan masih bocor jg yang menyebabkan lapisan bawah kue jadi lembab seperti belum matang. Jadi, 15 menit lebih aman. Jangan lupa hentakkan loyang sebelum masuk kukusan."
- "Setelah 15 menit, tuang adonan pandan. Kukus lagi 30 menit, pakai api sedang cenderung kecil."
- "Tes tusuk lebih dulu, karena kue cukup tinggi jadi proses pengukusannya harus diperhatikan agar matang sampai bawah. Hasil kuenya lembut, harum, gurih santannya terasa, ini saya yang paling banyak makan 😅 hasil bolunya tinggi ya."
categories:
- Resep
tags:
- bolu
- pandan
- lapis

katakunci: bolu pandan lapis 
nutrition: 177 calories
recipecuisine: Indonesian
preptime: "PT20M"
cooktime: "PT49M"
recipeyield: "3"
recipecategory: Lunch

---


![Bolu Pandan Lapis Coklat Kukus](https://img-global.cpcdn.com/recipes/8af707a2c3ffc0c3/751x532cq70/bolu-pandan-lapis-coklat-kukus-foto-resep-utama.jpg)


bolu pandan lapis coklat kukus ini yakni hidangan tanah air yang spesial dan harus untuk kita coba. Cita rasanya yang nikmat membuat siapa pun menantikan kehadirannya di meja makan.
Anda sedang mencari inspirasi resep bolu pandan lapis coklat kukus untuk jualan atau dikonsumsi sendiri yang Lezat? Cara Bikinnya memang tidak terlalu sulit namun tidak gampang juga. jikalau keliru mengolah maka hasilnya Tidak Memuaskan dan justru cenderung tidak enak. Padahal bolu pandan lapis coklat kukus yang enak seharusnya mempunyai aroma dan cita rasa yang dapat memancing selera kita.

Bolu kukus susu santan lapis cokelat memiliki tekstur yang lembut dan rasanya sangat khas. Cara membuat: - Siapkan loyang olesi mentega dan taburi tepung terigu. Penjelasan lengkap seputar Resep Bolu Kukus Anti Gagal dan Bantet.

Banyak hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari bolu pandan lapis coklat kukus, mulai dari jenis bahan, kedua pemilihan bahan segar sampai cara mengolah dan menghidangkannya. Tidak usah pusing jika hendak menyiapkan bolu pandan lapis coklat kukus enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini bisa menjadi suguhan istimewa.


Nah, kali ini kita coba, yuk, siapkan bolu pandan lapis coklat kukus sendiri di rumah. Tetap dengan bahan yang sederhana, sajian ini bisa memberi manfaat untuk membantu menjaga kesehatan tubuhmu sekeluarga. Anda dapat membuat Bolu Pandan Lapis Coklat Kukus menggunakan 14 jenis bahan dan 6 tahap pembuatan. Berikut ini langkah-langkah dalam menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam menyiapkan Bolu Pandan Lapis Coklat Kukus:

1. Siapkan  telur uk besar
1. Siapkan  gula pasir
1. Gunakan  terigu pro sedang
1. Ambil  santan (me:kara+air)
1. Gunakan  minyak sayur
1. Ambil  garam halus
1. Sediakan  vanili bubuk
1. Sediakan  sp/ovalet
1. Sediakan  Lapis pandan:
1. Ambil  pasta pandan
1. Sediakan  Lapis coklat:
1. Siapkan  coklat bubuk+ sedikit air hangat dijadikan pasta
1. Siapkan  pasta coklat
1. Siapkan  kental manis coklat


Caranya juga nggak terlalu ribet kok Bolu kukus sendiri memiliki berbagai macam variasi rasa, salah satunya yaitu rasa pandan. Bukan hanya membuat tampilannya lebih menarik, pandan. Bolu kukus adalah menu wajib di setiap besek syukuran. Kamu bisa bikin yang lebih nikmat di rumah dengan resep dan cara membuat bolu kukus berikut ini! 

<!--inarticleads2-->

##### Langkah-langkah membuat Bolu Pandan Lapis Coklat Kukus:

1. Kocok telur, gula, sp, garam hingga kental putih berjejak dengan mixer kec tinggi.
1. Masukkan campuran tepung, vanili bergantian dengan minyak+santan. Aduk balik atau gunakan mixer speed rendah, aduk rata sebentar saja ya.
1. Bagi 2 adonan, masing-masing beri pasta sesuai petunjuk resep atau takaran pastanya disesuaikan dengan selera.
1. Siapkan loyang persegi uk 18cm. Olesi carlo, tuang adonan coklat lebih dulu. Kukus 15 menit. Resep asli kukus 6 menit, awalnya saya coba kukus 8 menit ternyata adonan pandan bocor ke lapisan coklat. Bikinan ke 2x coba lagi kukus 10 menit adonan masih bocor jg yang menyebabkan lapisan bawah kue jadi lembab seperti belum matang. Jadi, 15 menit lebih aman. Jangan lupa hentakkan loyang sebelum masuk kukusan.
1. Setelah 15 menit, tuang adonan pandan. Kukus lagi 30 menit, pakai api sedang cenderung kecil.
1. Tes tusuk lebih dulu, karena kue cukup tinggi jadi proses pengukusannya harus diperhatikan agar matang sampai bawah. Hasil kuenya lembut, harum, gurih santannya terasa, ini saya yang paling banyak makan 😅 hasil bolunya tinggi ya.


Apa lagi kalau bukan bolu kukus pandan. Pastinya, bolu pandan ini cocok disajikan kapan pun. Cara Membuat Bolu Kukus - Anda tentu akan setuju jika jenis kue yang ada di Indonesia dan juga di seluruh dunia sangatlah banyak. Sebelum dipanggang ataupun dikukus, adonan akan diberikan berbagai bahan perasa sesuai selera, seperti bubuk coklat, bumbu kue lapis, daun pandan, pisang. Bolu kukus yang berlapis selai nanas pada bagian tengahnya dan memiliki dua warna lapis yang berbeda. 

Bagaimana? Gampang kan? Itulah cara membuat bolu pandan lapis coklat kukus yang bisa Anda lakukan di rumah. Selamat mencoba!
