---
description: "Resep masakan Bubur sum sum gula merah | Langkah Membuat Bubur sum sum gula merah Yang Enak Dan Lezat"
title: "Resep masakan Bubur sum sum gula merah | Langkah Membuat Bubur sum sum gula merah Yang Enak Dan Lezat"
slug: 15-resep-masakan-bubur-sum-sum-gula-merah-langkah-membuat-bubur-sum-sum-gula-merah-yang-enak-dan-lezat
date: 2020-09-29T12:13:47.686Z
image: https://img-global.cpcdn.com/recipes/f65d64d9c2a5da46/751x532cq70/bubur-sum-sum-gula-merah-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/f65d64d9c2a5da46/751x532cq70/bubur-sum-sum-gula-merah-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/f65d64d9c2a5da46/751x532cq70/bubur-sum-sum-gula-merah-foto-resep-utama.jpg
author: Austin Kelly
ratingvalue: 4.4
reviewcount: 13
recipeingredient:
- "5 sdm tepung beras"
- "1 santan kara di campur air"
- " Garam"
- " Daun pandan"
- " Kuah "
- "1/4 gula aren"
- " Garam"
- " Gula"
recipeinstructions:
- "Larutkan santan pada air bagi 2"
- "Masak santan dan masukkan daun pandan smpai mendidih"
- "Campur santan yg telah di bagi 2 tadi dg tepung beras.. larutkan"
- "Setelah santan yg di masak mendidih, masukkan larutan tepung beras dan santan tdi, tambahkan garam sdikit. Masak sampai bubur meletup&#34; dan angkat."
- "Kuah : cincang gula merah 1/4 dan masak dg daun pandan.. masukkan garam dan gula sedikit. Tunggu sampai mendidih"
- "Sajikan bubur sumsum dan sirah kuah gula merah"
categories:
- Resep
tags:
- bubur
- sum
- sum

katakunci: bubur sum sum 
nutrition: 196 calories
recipecuisine: Indonesian
preptime: "PT27M"
cooktime: "PT30M"
recipeyield: "3"
recipecategory: Dessert

---


![Bubur sum sum gula merah](https://img-global.cpcdn.com/recipes/f65d64d9c2a5da46/751x532cq70/bubur-sum-sum-gula-merah-foto-resep-utama.jpg)


bubur sum sum gula merah ini merupakan santapan tanah air yang khas dan harus untuk kita coba. Cita rasanya yang mantap membuat siapa pun menantikan kehadirannya di meja makan.
Kamu Lagi mencari inspirasi resep bubur sum sum gula merah untuk jualan atau dikonsumsi sendiri yang Sempurna? Cara Buatnya memang tidak terlalu sulit namun tidak gampang juga. misalnya salah mengolah maka hasilnya akan hambar dan bahkan tidak sedap. Padahal bubur sum sum gula merah yang enak harusnya sih memiliki aroma dan rasa yang dapat memancing selera kita.

Resep Masakan Bubur Sum-Sum Gula Merah selamat datang di resep masakan rumahan.chanel resep masakan rumahan ini berisikan informasi resep masakan sederhana. Bubur sumsum ini rasanya enak dan gurih dengan tambahan saus gula merah yang manis, cocok disajikan untuk menu buka puasa. Bubur sumsum itu sendiri terbuat dari tepung beras, kemudian dimasak dengan santan lalu dinikmati dengan tambahan saus gula sehingga rasanya semakin lezat.

Ada beberapa hal yang sedikit banyak mempengaruhi kualitas rasa dari bubur sum sum gula merah, mulai dari jenis bahan, kedua pemilihan bahan segar sampai cara membuat dan menghidangkannya. Tak perlu pusing jika hendak menyiapkan bubur sum sum gula merah yang enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini dapat menjadi suguhan spesial.


Di bawah ini ada beberapa cara mudah dan praktis dalam mengolah bubur sum sum gula merah yang siap dikreasikan. Anda dapat menyiapkan Bubur sum sum gula merah memakai 8 bahan dan 6 langkah pembuatan. Berikut ini cara untuk menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk pembuatan Bubur sum sum gula merah:

1. Gunakan 5 sdm tepung beras
1. Siapkan 1 santan kara (di campur air)
1. Siapkan  Garam
1. Gunakan  Daun pandan
1. Sediakan  Kuah :
1. Ambil 1/4 gula aren
1. Ambil  Garam
1. Siapkan  Gula


Bubur sumsum terbuat dari campuran tepung beras dan santan. Disajikan bersama saus kinca atau saus gula merah. Saus gula merah: campur gula merah, gula pasir, air, dan daun pandan pada panci. Saus gula merah: Masak air, gula merah, gula pasir sampai mendidih dan gula larut. 

<!--inarticleads2-->

##### Cara membuat Bubur sum sum gula merah:

1. Larutkan santan pada air bagi 2
1. Masak santan dan masukkan daun pandan smpai mendidih
1. Campur santan yg telah di bagi 2 tadi dg tepung beras.. larutkan
1. Setelah santan yg di masak mendidih, masukkan larutan tepung beras dan santan tdi, tambahkan garam sdikit. Masak sampai bubur meletup&#34; dan angkat.
1. Kuah : cincang gula merah 1/4 dan masak dg daun pandan.. masukkan garam dan gula sedikit. Tunggu sampai mendidih
1. Sajikan bubur sumsum dan sirah kuah gula merah


Masukkan larutan maizena, aduk rata hingga agak kental. Untuk membuat bubur sum sum dengan warna hijau biasanya menggunakan daun suji atau pasta pandan. Bubur sum sum termasuk jajanan tradisional yang masih mudah kita jumpai. Biasanya dihidangkan bersama kuah gula merah dicampur dengan gempol dan candil. Cara penyajian bubur sum-sum ini mudah, Kamu hanya perlu siapkan mangkuk yang cantik, tuangkan bubur ke dalamnya lalu siramkan saus gula merah di atasnya. 

Bagaimana? Mudah bukan? Itulah cara menyiapkan bubur sum sum gula merah yang bisa Anda praktikkan di rumah. Selamat mencoba!
