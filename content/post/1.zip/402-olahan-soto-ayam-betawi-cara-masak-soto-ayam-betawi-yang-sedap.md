---
description: "Olahan Soto Ayam Betawi | Cara Masak Soto Ayam Betawi Yang Sedap"
title: "Olahan Soto Ayam Betawi | Cara Masak Soto Ayam Betawi Yang Sedap"
slug: 402-olahan-soto-ayam-betawi-cara-masak-soto-ayam-betawi-yang-sedap
date: 2020-12-01T05:42:59.208Z
image: https://img-global.cpcdn.com/recipes/ed0287e6d3739286/751x532cq70/soto-ayam-betawi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/ed0287e6d3739286/751x532cq70/soto-ayam-betawi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/ed0287e6d3739286/751x532cq70/soto-ayam-betawi-foto-resep-utama.jpg
author: Jon Hale
ratingvalue: 4.8
reviewcount: 6
recipeingredient:
- " paha ayam"
- " susu cair full cream"
- " santan dr 300gr klpa parut"
- " air"
- " daun jeruk buang tulangnya"
- " daun salam"
- " sereh geprek"
- " lengkuas geprek"
- " Secukupnya gula garam dn kaldu bubuk"
- " minyak untk menumis"
- " Bumbu Halus"
- " bwg merah"
- " bwg putih uk besar"
- " kemiri"
- " ketumbar butir"
- " lada butir"
- " jahe"
- " Pelengkap"
- " Telur rebus"
- " Emping"
- " Bwg goreng"
- " daun bwg dn seledri"
- " Smbal cabe rebus"
- " Kentang goreng"
- " tomat"
recipeinstructions:
- "Rebus ayam hingga keluar kaldu&#39;a dn mendidih (yg sdh di marinasi dgn garam dn perasan jeruk nipis)"
- "Haluskan bumbu. Tumis bumbu bersama daun jeruk, salam, sereh dn lengkuas hingga tanak"
- "Masukkan bumbu tumisan kedalam rebusan ayam aduk rata"
- "Tambahkan santan dn susu cair aduk rata masak hingga mendidih. Lalu bumbui dgn garam, gula dn kaldu bubuk icip rasa"
- "Jika ayam sdh empuk, angkat dn tiriskan dn goreng hingga berubah warna"
- "Penyajian : suwir² ayam yg sdh digoreng, tata di mangkuk saji brsama bahan pelengkap"
- "Lalu siram dgn kuah soto panas². Dn soto siap dinikmati hngat²..komplit dgn nasi putih 🤤😋"
categories:
- Resep
tags:
- soto
- ayam
- betawi

katakunci: soto ayam betawi 
nutrition: 222 calories
recipecuisine: Indonesian
preptime: "PT22M"
cooktime: "PT58M"
recipeyield: "1"
recipecategory: Dinner

---


![Soto Ayam Betawi](https://img-global.cpcdn.com/recipes/ed0287e6d3739286/751x532cq70/soto-ayam-betawi-foto-resep-utama.jpg)


soto ayam betawi ini yaitu kuliner tanah air yang spesial dan harus untuk kita coba. Cita rasanya yang lezat membuat siapa pun menantikan kehadirannya di meja makan.
Kamu Lagi mencari inspirasi resep soto ayam betawi untuk jualan atau dikonsumsi sendiri yang Paling Enak? Cara membuatnya memang tidak terlalu sulit namun tidak gampang juga. sekiranya salah mengolah maka hasilnya Tidak Memuaskan dan justru cenderung tidak enak. Padahal soto ayam betawi yang enak harusnya sih punya aroma dan rasa yang bisa memancing selera kita.



Banyak hal yang sedikit banyak mempengaruhi kualitas rasa dari soto ayam betawi, mulai dari jenis bahan, kemudian pemilihan bahan segar sampai cara mengolah dan menyajikannya. Tidak usah pusing jika mau menyiapkan soto ayam betawi enak di rumah, karena asal sudah tahu triknya maka hidangan ini dapat menjadi sajian spesial.


Nah, kali ini kita coba, yuk, buat soto ayam betawi sendiri di rumah. Tetap berbahan yang sederhana, hidangan ini dapat memberi manfaat dalam membantu menjaga kesehatan tubuh kita. Anda bisa menyiapkan Soto Ayam Betawi memakai 25 jenis bahan dan 7 tahap pembuatan. Berikut ini cara untuk menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk menyiapkan Soto Ayam Betawi:

1. Ambil  paha ayam
1. Ambil  susu cair full cream
1. Ambil  santan dr 300gr klpa parut
1. Gunakan  air
1. Ambil  daun jeruk, buang tulangnya
1. Sediakan  daun salam
1. Gunakan  sereh, geprek
1. Siapkan  lengkuas, geprek
1. Ambil  Secukupnya, gula, garam dn kaldu bubuk
1. Gunakan  minyak untk menumis
1. Siapkan  Bumbu Halus
1. Sediakan  bwg merah
1. Sediakan  bwg putih uk besar
1. Ambil  kemiri
1. Gunakan  ketumbar butir
1. Siapkan  lada butir
1. Sediakan  jahe
1. Ambil  Pelengkap
1. Siapkan  Telur rebus
1. Gunakan  Emping
1. Ambil  Bwg goreng
1. Sediakan  daun bwg dn seledri
1. Siapkan  Smbal cabe rebus
1. Sediakan  Kentang goreng
1. Sediakan  tomat




<!--inarticleads2-->

##### Cara menyiapkan Soto Ayam Betawi:

1. Rebus ayam hingga keluar kaldu&#39;a dn mendidih (yg sdh di marinasi dgn garam dn perasan jeruk nipis)
1. Haluskan bumbu. Tumis bumbu bersama daun jeruk, salam, sereh dn lengkuas hingga tanak
1. Masukkan bumbu tumisan kedalam rebusan ayam aduk rata
1. Tambahkan santan dn susu cair aduk rata masak hingga mendidih. Lalu bumbui dgn garam, gula dn kaldu bubuk icip rasa
1. Jika ayam sdh empuk, angkat dn tiriskan dn goreng hingga berubah warna
1. Penyajian : suwir² ayam yg sdh digoreng, tata di mangkuk saji brsama bahan pelengkap
1. Lalu siram dgn kuah soto panas². Dn soto siap dinikmati hngat²..komplit dgn nasi putih 🤤😋




Terima kasih telah membaca resep yang tim kami tampilkan di halaman ini. Besar harapan kami, olahan Soto Ayam Betawi yang mudah di atas dapat membantu Anda menyiapkan makanan yang lezat untuk keluarga/teman ataupun menjadi ide dalam berbisnis kuliner. Semoga bermanfaat dan selamat mencoba!
