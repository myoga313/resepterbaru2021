---
description: "Bumbu Bubur Sum-Sum Kemerdekaan | Bahan Membuat Bubur Sum-Sum Kemerdekaan Yang Bisa Manjain Lidah"
title: "Bumbu Bubur Sum-Sum Kemerdekaan | Bahan Membuat Bubur Sum-Sum Kemerdekaan Yang Bisa Manjain Lidah"
slug: 24-bumbu-bubur-sum-sum-kemerdekaan-bahan-membuat-bubur-sum-sum-kemerdekaan-yang-bisa-manjain-lidah
date: 2020-10-09T14:12:45.235Z
image: https://img-global.cpcdn.com/recipes/a88b2ad537741b42/751x532cq70/bubur-sum-sum-kemerdekaan-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/a88b2ad537741b42/751x532cq70/bubur-sum-sum-kemerdekaan-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/a88b2ad537741b42/751x532cq70/bubur-sum-sum-kemerdekaan-foto-resep-utama.jpg
author: Leroy McCarthy
ratingvalue: 4.2
reviewcount: 4
recipeingredient:
- " Bahan bubur putih "
- "50 gr tepung beras"
- "500 ml santan saya kara 65 ml  air"
- "1/2 sdt garam"
- "1 lembar daun pandan"
- " Bahan bubur merah "
- "50 gr tepung beras"
- "500 ml santan kara 65ml  air"
- "1/2 sdt garam"
- "1 lembar daun pandan"
- "Secukupnya pewarna merah tua"
- " Bahan kuah kinca "
- "100 gr gula meraharen"
- "200 ml air"
- "1 lembar Daun pandan"
- "5 cm kayu manis"
recipeinstructions:
- "Dimasing² panci campur semua bahan bubur di panci berbeda"
- "Masak dengan api kecil sambil diaduk² sampai meletup² sisihkan"
- "Di panci berbeda lagi masukkan bahan kuah kinca,masak sampai gula larut dan mendidih"
- "Masukkan bubur tadi ke plastik lalu potong ujungnya dan masukkan kegelas secara bergantian agar membentuk layer seperti bendera negara kita."
categories:
- Resep
tags:
- bubur
- sumsum
- kemerdekaan

katakunci: bubur sumsum kemerdekaan 
nutrition: 196 calories
recipecuisine: Indonesian
preptime: "PT23M"
cooktime: "PT57M"
recipeyield: "4"
recipecategory: Dessert

---


![Bubur Sum-Sum Kemerdekaan](https://img-global.cpcdn.com/recipes/a88b2ad537741b42/751x532cq70/bubur-sum-sum-kemerdekaan-foto-resep-utama.jpg)


bubur sum-sum kemerdekaan ini yakni kuliner tanah air yang unik dan wajib untuk kita coba. Cita rasanya yang nikmat membuat siapa pun menantikan kehadirannya di meja makan.
Anda sedang mencari inspirasi resep bubur sum-sum kemerdekaan untuk jualan atau dikonsumsi sendiri yang Lezat Sekali? Cara Memasaknya memang tidak susah dan tidak juga mudah. Jika salah mengolah maka hasilnya tidak akan memuaskan dan bahkan tidak sedap. Padahal bubur sum-sum kemerdekaan yang enak selayaknya memiliki aroma dan rasa yang bisa memancing selera kita.



Ada beberapa hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari bubur sum-sum kemerdekaan, pertama dari jenis bahan, kemudian pemilihan bahan segar hingga cara mengolah dan menyajikannya. Tak perlu pusing jika hendak menyiapkan bubur sum-sum kemerdekaan yang enak di rumah, karena asal sudah tahu triknya maka hidangan ini mampu jadi suguhan spesial.


Nah, kali ini kita coba, yuk, variasikan bubur sum-sum kemerdekaan sendiri di rumah. Tetap dengan bahan sederhana, sajian ini dapat memberi manfaat dalam membantu menjaga kesehatan tubuhmu sekeluarga. Anda bisa menyiapkan Bubur Sum-Sum Kemerdekaan menggunakan 16 bahan dan 4 langkah pembuatan. Berikut ini langkah-langkah dalam membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam pembuatan Bubur Sum-Sum Kemerdekaan:

1. Siapkan  Bahan bubur putih :
1. Sediakan 50 gr tepung beras
1. Siapkan 500 ml santan (saya kara @65 ml + air)
1. Gunakan 1/2 sdt garam
1. Ambil 1 lembar daun pandan
1. Siapkan  Bahan bubur merah ?
1. Sediakan 50 gr tepung beras
1. Siapkan 500 ml santan (kara @65ml + air)
1. Gunakan 1/2 sdt garam
1. Gunakan 1 lembar daun pandan
1. Ambil Secukupnya pewarna merah tua
1. Ambil  Bahan kuah kinca :
1. Gunakan 100 gr gula merah/aren
1. Gunakan 200 ml air
1. Siapkan 1 lembar Daun pandan
1. Sediakan 5 cm kayu manis




<!--inarticleads2-->

##### Langkah-langkah membuat Bubur Sum-Sum Kemerdekaan:

1. Dimasing² panci campur semua bahan bubur di panci berbeda
1. Masak dengan api kecil sambil diaduk² sampai meletup² sisihkan
1. Di panci berbeda lagi masukkan bahan kuah kinca,masak sampai gula larut dan mendidih
1. Masukkan bubur tadi ke plastik lalu potong ujungnya dan masukkan kegelas secara bergantian agar membentuk layer seperti bendera negara kita.




Bagaimana? Gampang kan? Itulah cara membuat bubur sum-sum kemerdekaan yang bisa Anda praktikkan di rumah. Semoga bermanfaat dan selamat mencoba!
