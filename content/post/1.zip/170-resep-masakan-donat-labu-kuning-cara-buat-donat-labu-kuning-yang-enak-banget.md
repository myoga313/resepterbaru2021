---
description: "Resep masakan Donat labu kuning | Cara Buat Donat labu kuning Yang Enak Banget"
title: "Resep masakan Donat labu kuning | Cara Buat Donat labu kuning Yang Enak Banget"
slug: 170-resep-masakan-donat-labu-kuning-cara-buat-donat-labu-kuning-yang-enak-banget
date: 2020-07-28T05:56:09.035Z
image: https://img-global.cpcdn.com/recipes/3e207e508fa4194b/751x532cq70/donat-labu-kuning-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/3e207e508fa4194b/751x532cq70/donat-labu-kuning-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/3e207e508fa4194b/751x532cq70/donat-labu-kuning-foto-resep-utama.jpg
author: Mario Delgado
ratingvalue: 4.2
reviewcount: 12
recipeingredient:
- "30 sdm  300 gr tepung terigu pro tinggi"
- "1/2 sdt garam"
- "150 gr labu kuning yg sudah dikukus dan dihaluskan"
- "1 sdm margarin"
- " Bahan biang 100 ml air hangat3 sdm gula pasir1 sdm ragi instant"
recipeinstructions:
- "Campur bahan biang aduk rata diamkan 10 menit"
- "Siapkan wadah masukkan terigu dan garam aduk rata"
- "Masukkan labu kuning aduk rata"
- "Masukkan bahan biang aduk rata"
- "Uleni hingga setengah kalis lalu tambahkan margarin uleni hingga kalis"
- "Istirahatkan adonan sambil ditutup kain 1 jam"
- "Bulatkan adonan lalu diamkan 15 menit"
- "Cetak donat bisa pakai cetakan atau dilubangi manual"
- "Tutup lagi diamkan 10 menit"
- "Panaskan minyak masukkan donat goreng api sedang cenderung kecil, balik 1 kali saja"
- "Jika sudah kecoklatan angkat tiriskan, beri toping gula donat atau yg lainnya"
categories:
- Resep
tags:
- donat
- labu
- kuning

katakunci: donat labu kuning 
nutrition: 169 calories
recipecuisine: Indonesian
preptime: "PT32M"
cooktime: "PT46M"
recipeyield: "1"
recipecategory: Dessert

---


![Donat labu kuning](https://img-global.cpcdn.com/recipes/3e207e508fa4194b/751x532cq70/donat-labu-kuning-foto-resep-utama.jpg)


donat labu kuning ini merupakan suguhan nusantara yang istimewa dan perlu untuk kita coba. Cita rasanya yang nikmat membuat siapa pun menantikan kehadirannya di meja makan.
Bunda Sedang mencari inspirasi resep donat labu kuning untuk jualan atau dikonsumsi sendiri yang Enak Dan Lezat? Cara membuatnya memang tidak susah dan tidak juga mudah. jikalau keliru mengolah maka hasilnya akan hambar dan justru cenderung tidak enak. Padahal donat labu kuning yang enak harusnya sih memiliki aroma dan rasa yang mampu memancing selera kita.



Banyak hal yang sedikit banyak mempengaruhi kualitas rasa dari donat labu kuning, mulai dari jenis bahan, kedua pemilihan bahan segar sampai cara mengolah dan menyajikannya. Tak perlu pusing jika mau menyiapkan donat labu kuning yang enak di rumah, karena asal sudah tahu triknya maka hidangan ini mampu menjadi sajian istimewa.


Nah, kali ini kita coba, yuk, buat donat labu kuning sendiri di rumah. Tetap berbahan yang sederhana, hidangan ini dapat memberi manfaat dalam membantu menjaga kesehatan tubuh kita. Anda bisa membuat Donat labu kuning memakai 5 bahan dan 11 langkah pembuatan. Berikut ini cara dalam menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk pembuatan Donat labu kuning:

1. Sediakan 30 sdm / 300 gr tepung terigu pro tinggi
1. Sediakan 1/2 sdt garam
1. Gunakan 150 gr labu kuning yg sudah dikukus dan dihaluskan
1. Gunakan 1 sdm margarin
1. Sediakan  Bahan biang 100 ml air hangat3 sdm gula pasir1 sdm ragi instant




<!--inarticleads2-->

##### Cara menyiapkan Donat labu kuning:

1. Campur bahan biang aduk rata diamkan 10 menit
1. Siapkan wadah masukkan terigu dan garam aduk rata
1. Masukkan labu kuning aduk rata
1. Masukkan bahan biang aduk rata
1. Uleni hingga setengah kalis lalu tambahkan margarin uleni hingga kalis
1. Istirahatkan adonan sambil ditutup kain 1 jam
1. Bulatkan adonan lalu diamkan 15 menit
1. Cetak donat bisa pakai cetakan atau dilubangi manual
1. Tutup lagi diamkan 10 menit
1. Panaskan minyak masukkan donat goreng api sedang cenderung kecil, balik 1 kali saja
1. Jika sudah kecoklatan angkat tiriskan, beri toping gula donat atau yg lainnya




Terima kasih telah membaca resep yang tim kami tampilkan di halaman ini. Harapan kami, olahan Donat labu kuning yang mudah di atas dapat membantu Anda menyiapkan makanan yang enak untuk keluarga/teman ataupun menjadi ide untuk berbisnis kuliner. Selamat mencoba!
