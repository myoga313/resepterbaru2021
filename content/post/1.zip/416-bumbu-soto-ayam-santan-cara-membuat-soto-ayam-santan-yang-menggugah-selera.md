---
description: "Bumbu Soto Ayam Santan | Cara Membuat Soto Ayam Santan Yang Menggugah Selera"
title: "Bumbu Soto Ayam Santan | Cara Membuat Soto Ayam Santan Yang Menggugah Selera"
slug: 416-bumbu-soto-ayam-santan-cara-membuat-soto-ayam-santan-yang-menggugah-selera
date: 2020-08-17T12:28:00.534Z
image: https://img-global.cpcdn.com/recipes/9ebff85a7a415e86/751x532cq70/soto-ayam-santan-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/9ebff85a7a415e86/751x532cq70/soto-ayam-santan-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/9ebff85a7a415e86/751x532cq70/soto-ayam-santan-foto-resep-utama.jpg
author: Pearl Nelson
ratingvalue: 4.4
reviewcount: 11
recipeingredient:
- " Ayam"
- " Tauge"
- " Kol putih"
- " Bihun me  skip"
- " Daun salam"
- " Daun jeruk"
- " Bumbu halus"
- " Jahe"
- " kunyit"
- " Lengkuas geprek"
- " Sereh geprek"
- " bawang merah"
- " bawang putih"
- " Bahan tambahan"
- " Daun bawang"
- " Bawang goreng"
- " Tomat"
- " Jeruk nipis"
- " Garam gula kaldu bubuk"
- " santan kara segitiga"
recipeinstructions:
- "Rebus ayam dengan bumbu atau tanpa bumbu ungkep (sesuai selera), sebentar jangan sampai air nya terlalu habis"
- "Angkat ayam, tiriskan, lalu tambahkan air 1,5 liter ke dalam air bekas rebusan ayam tadi.. rebus sampai mendidih"
- "Sambil menunggu air rebusan mendidih, haluskan bahan bumbu halus.. dan goreng ayam dengan tingkat kematangan sesuai selera"
- "Lalu Rebus tauge setengah matang, angkat tiriskan.. tumis bumbu halus sebentar, hingga wangi nya tercium"
- "Setelah air mendidih, masukan bumbu halus yang sudah di tumis, dengan api kompor sedang aduk rata dan tunggu sampai mendidih lagi"
- "Larutkan santan dengan 1/2 gelas air, dan masukkan ke dalam kuah soto yang sudah mendidih.. tambahkan gula, garam, kaldu bubuk.. tes rasa"
- "Setelah matang sempurna, sajikan pada mangkuk.. Tauge,kol,ayam,tomat,daun bawang, siram dengan kuah soto, taburkan bawang goreng, jeruk nipis dan sajikan selagi hangat🤤"
categories:
- Resep
tags:
- soto
- ayam
- santan

katakunci: soto ayam santan 
nutrition: 195 calories
recipecuisine: Indonesian
preptime: "PT31M"
cooktime: "PT44M"
recipeyield: "1"
recipecategory: Lunch

---


![Soto Ayam Santan](https://img-global.cpcdn.com/recipes/9ebff85a7a415e86/751x532cq70/soto-ayam-santan-foto-resep-utama.jpg)


soto ayam santan ini merupakan kuliner tanah air yang istimewa dan wajib untuk kita coba. Cita rasanya yang mantap membuat siapa pun menantikan kehadirannya di meja makan.
Anda sedang mencari ide resep soto ayam santan untuk jualan atau dikonsumsi sendiri yang Menggugah Selera? Cara Bikinnya memang tidak terlalu sulit namun tidak gampang juga. kalau salah mengolah maka hasilnya akan hambar dan justru cenderung tidak enak. Padahal soto ayam santan yang enak harusnya sih mempunyai aroma dan rasa yang mampu memancing selera kita.



Banyak hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari soto ayam santan, mulai dari jenis bahan, kedua pemilihan bahan segar hingga cara membuat dan menghidangkannya. Tidak usah pusing jika ingin menyiapkan soto ayam santan yang enak di rumah, karena asal sudah tahu triknya maka hidangan ini mampu menjadi sajian spesial.


Nah, kali ini kita coba, yuk, siapkan soto ayam santan sendiri di rumah. Tetap dengan bahan sederhana, hidangan ini dapat memberi manfaat dalam membantu menjaga kesehatan tubuhmu sekeluarga. Anda dapat membuat Soto Ayam Santan menggunakan 20 bahan dan 7 langkah pembuatan. Berikut ini langkah-langkah dalam menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk menyiapkan Soto Ayam Santan:

1. Ambil  Ayam
1. Sediakan  Tauge
1. Ambil  Kol putih
1. Gunakan  Bihun (me : skip)
1. Ambil  Daun salam
1. Sediakan  Daun jeruk
1. Sediakan  Bumbu halus
1. Sediakan  Jahe
1. Ambil  kunyit
1. Gunakan  Lengkuas (geprek)
1. Siapkan  Sereh (geprek)
1. Gunakan  bawang merah
1. Sediakan  bawang putih
1. Sediakan  Bahan tambahan
1. Sediakan  Daun bawang
1. Sediakan  Bawang goreng
1. Sediakan  Tomat
1. Siapkan  Jeruk nipis
1. Sediakan  Garam, gula, kaldu bubuk
1. Siapkan  santan kara segitiga




<!--inarticleads2-->

##### Langkah-langkah membuat Soto Ayam Santan:

1. Rebus ayam dengan bumbu atau tanpa bumbu ungkep (sesuai selera), sebentar jangan sampai air nya terlalu habis
1. Angkat ayam, tiriskan, lalu tambahkan air 1,5 liter ke dalam air bekas rebusan ayam tadi.. rebus sampai mendidih
1. Sambil menunggu air rebusan mendidih, haluskan bahan bumbu halus.. dan goreng ayam dengan tingkat kematangan sesuai selera
1. Lalu Rebus tauge setengah matang, angkat tiriskan.. tumis bumbu halus sebentar, hingga wangi nya tercium
1. Setelah air mendidih, masukan bumbu halus yang sudah di tumis, dengan api kompor sedang aduk rata dan tunggu sampai mendidih lagi
1. Larutkan santan dengan 1/2 gelas air, dan masukkan ke dalam kuah soto yang sudah mendidih.. tambahkan gula, garam, kaldu bubuk.. tes rasa
1. Setelah matang sempurna, sajikan pada mangkuk.. Tauge,kol,ayam,tomat,daun bawang, siram dengan kuah soto, taburkan bawang goreng, jeruk nipis dan sajikan selagi hangat🤤




Terima kasih telah menggunakan resep yang tim kami tampilkan di halaman ini. Harapan kami, olahan Soto Ayam Santan yang mudah di atas dapat membantu Anda menyiapkan makanan yang lezat untuk keluarga/teman ataupun menjadi inspirasi bagi Anda yang berkeinginan untuk berjualan makanan. Semoga bermanfaat dan selamat mencoba!
