---
description: "Resep masakan Soto Ayam | Langkah Membuat Soto Ayam Yang Enak dan Simpel"
title: "Resep masakan Soto Ayam | Langkah Membuat Soto Ayam Yang Enak dan Simpel"
slug: 412-resep-masakan-soto-ayam-langkah-membuat-soto-ayam-yang-enak-dan-simpel
date: 2021-01-10T18:43:28.459Z
image: https://img-global.cpcdn.com/recipes/45b9a1c1514bfe93/751x532cq70/soto-ayam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/45b9a1c1514bfe93/751x532cq70/soto-ayam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/45b9a1c1514bfe93/751x532cq70/soto-ayam-foto-resep-utama.jpg
author: Jimmy Curtis
ratingvalue: 4.8
reviewcount: 12
recipeingredient:
- " ayam potong sesuai selera"
- " air"
- " pipih gula pasir"
- " lada bubuk"
- " garam"
- " Bumbu Marinasi"
- " pipih garam"
- " kunyit bubuk"
- " ketumbar bubuk"
- " Bahan Bumbu"
- " bawang putih iris"
- " bawang merah iris"
- " daun bawang iris"
- " jahe haluskan"
- " lengkuas haluskanmemarkan"
- " sereh memarkan"
- " daun jeruk sobek"
recipeinstructions:
- "Marinasi ayam dengan bumbu marinasi, diamkan kurleb 3 jam."
- "Tumis bawang merah, bawang putih sebentar, masukkan jahe, lengkuas, sereh, daun jeruk, lanjutkan menumis hingga harum, kemudian masukkan daun bawang. Tumis hingga agak sedikit layu."
- "Kecilkan api, masukkan ayam dan seluruh bumbu marinasi (jika tersisa). Aduk rata, masak hingga ayam berubah warna."
- "Tambahkan 250ml air, masak hingga air agak menyusut dan bumbu meresap, kurleb 5-7 menit dengan api sedang atau 10 menit dengan api agak kecil."
- "Tambahkan 750ml air, aduk rata. Masak hingga mendidih dengan api kecil. Masukkan gula, lada dan garam. Boleh tambah kaldu bubuk jika biasa menggunakan kaldu bubuk. Masak hingga ayam empuk, aduk sesekali."
- "Test/koreksi rasa, matikan api. Angkat dan sajikan selagi hangat."
categories:
- Resep
tags:
- soto
- ayam

katakunci: soto ayam 
nutrition: 112 calories
recipecuisine: Indonesian
preptime: "PT24M"
cooktime: "PT42M"
recipeyield: "1"
recipecategory: Dinner

---


![Soto Ayam](https://img-global.cpcdn.com/recipes/45b9a1c1514bfe93/751x532cq70/soto-ayam-foto-resep-utama.jpg)


soto ayam ini merupakan suguhan nusantara yang spesial dan wajib untuk kita coba. Cita rasanya yang enak membuat siapa pun menantikan kehadirannya di meja makan.
Bunda Sedang mencari ide resep soto ayam untuk jualan atau dikonsumsi sendiri yang Enak Dan Lezat? Cara menyiapkannya memang tidak terlalu sulit namun tidak gampang juga. jikalau keliru mengolah maka hasilnya Tidak Memuaskan dan bahkan tidak sedap. Padahal soto ayam yang enak selayaknya memiliki aroma dan rasa yang mampu memancing selera kita.

Ada beberapa hal yang sedikit banyak mempengaruhi kualitas rasa dari soto ayam, mulai dari jenis bahan, selanjutnya pemilihan bahan segar, hingga cara mengolah dan menghidangkannya. Tidak usah pusing kalau ingin menyiapkan soto ayam yang enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini bisa jadi sajian istimewa.




Nah, kali ini kita coba, yuk, ciptakan soto ayam sendiri di rumah. Tetap dengan bahan yang sederhana, hidangan ini dapat memberi manfaat untuk membantu menjaga kesehatan tubuhmu sekeluarga. Anda dapat membuat Soto Ayam menggunakan 17 jenis bahan dan 6 langkah pembuatan. Berikut ini cara dalam menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk pembuatan Soto Ayam:

1. Gunakan  ayam, potong sesuai selera
1. Gunakan  air
1. Sediakan  pipih gula pasir
1. Ambil  lada bubuk
1. Siapkan  garam
1. Siapkan  Bumbu Marinasi
1. Sediakan  pipih garam
1. Gunakan  kunyit bubuk
1. Siapkan  ketumbar bubuk
1. Ambil  Bahan Bumbu
1. Sediakan  bawang putih, iris
1. Sediakan  bawang merah, iris
1. Sediakan  daun bawang, iris
1. Ambil  jahe, haluskan
1. Ambil  lengkuas, haluskan/memarkan
1. Ambil  sereh, memarkan
1. Siapkan  daun jeruk, sobek




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Soto Ayam:

1. Marinasi ayam dengan bumbu marinasi, diamkan kurleb 3 jam.
1. Tumis bawang merah, bawang putih sebentar, masukkan jahe, lengkuas, sereh, daun jeruk, lanjutkan menumis hingga harum, kemudian masukkan daun bawang. Tumis hingga agak sedikit layu.
1. Kecilkan api, masukkan ayam dan seluruh bumbu marinasi (jika tersisa). Aduk rata, masak hingga ayam berubah warna.
1. Tambahkan 250ml air, masak hingga air agak menyusut dan bumbu meresap, kurleb 5-7 menit dengan api sedang atau 10 menit dengan api agak kecil.
1. Tambahkan 750ml air, aduk rata. Masak hingga mendidih dengan api kecil. Masukkan gula, lada dan garam. Boleh tambah kaldu bubuk jika biasa menggunakan kaldu bubuk. Masak hingga ayam empuk, aduk sesekali.
1. Test/koreksi rasa, matikan api. Angkat dan sajikan selagi hangat.




Bagaimana? Gampang kan? Itulah cara menyiapkan soto ayam yang bisa Anda lakukan di rumah. Semoga bermanfaat dan selamat mencoba!
