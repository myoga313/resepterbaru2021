---
description: "Resep masakan Ayam Kecap Pedas Manis | Cara Bikin Ayam Kecap Pedas Manis Yang Sedap"
title: "Resep masakan Ayam Kecap Pedas Manis | Cara Bikin Ayam Kecap Pedas Manis Yang Sedap"
slug: 389-resep-masakan-ayam-kecap-pedas-manis-cara-bikin-ayam-kecap-pedas-manis-yang-sedap
date: 2020-10-29T22:14:24.617Z
image: https://img-global.cpcdn.com/recipes/d8af7c10124546a6/751x532cq70/ayam-kecap-pedas-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/d8af7c10124546a6/751x532cq70/ayam-kecap-pedas-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/d8af7c10124546a6/751x532cq70/ayam-kecap-pedas-manis-foto-resep-utama.jpg
author: Maude Roberts
ratingvalue: 3.7
reviewcount: 11
recipeingredient:
- "500 gr ayam sayap"
- " Bahan rebusan "
- "1 cm lengkuas"
- "1 cm jahe"
- "2 lembar daun salam"
- " Bumbu Iris "
- "4 butir bawang merah"
- "3 siung bawang putih"
- "5 buah cabai rawit merah"
- "2 lembar daun jeruk"
- " Bahan tambahan "
- "150 ml air"
- "2 lembar daun salam"
- "2 sdm kecap manis"
- "1 sdm saus tiram"
- "2 sdm sau cabai"
- "1/2 sdt merica bubuk"
- "1/2 sdt garam"
- "1 sdt kaldu bubuk"
- "1 sdm gula merah"
recipeinstructions:
- "Rebus ayam dengan jahe, lengkuas dan daun salam hingga tercium bau harum. Lalu angkat dan cuci bersih. Kemudian goreng ayam sampai kecoklatan. Sisihkan."
- "Tumis bawang merah dan bawang putih, lalu masukkan irisan cabai dan daun jeruk. Tumis hingga layu."
- "Masukkan ayam, tuang air dan daun salam. Aduk."
- "Beri saus cabai, saus tiram, kecap manis, garam, gula, merica dan kaldu bubuk. Aduk rata, masak hingga kuah sedikit berkurang. Matikan kompor dan sajikan."
categories:
- Resep
tags:
- ayam
- kecap
- pedas

katakunci: ayam kecap pedas 
nutrition: 125 calories
recipecuisine: Indonesian
preptime: "PT30M"
cooktime: "PT36M"
recipeyield: "4"
recipecategory: Dinner

---


![Ayam Kecap Pedas Manis](https://img-global.cpcdn.com/recipes/d8af7c10124546a6/751x532cq70/ayam-kecap-pedas-manis-foto-resep-utama.jpg)


ayam kecap pedas manis ini yakni santapan tanah air yang istimewa dan wajib untuk kita coba. Cita rasanya yang mantap membuat siapa pun menantikan kehadirannya di meja makan.
Anda sedang mencari ide resep ayam kecap pedas manis untuk jualan atau dikonsumsi sendiri yang Mudah Dan Praktis? Cara Buatnya memang susah-susah gampang. apabila keliru mengolah maka hasilnya Tidak Memuaskan dan bahkan tidak sedap. Padahal ayam kecap pedas manis yang enak seharusnya mempunyai aroma dan cita rasa yang bisa memancing selera kita.



Ada beberapa hal yang sedikit banyak mempengaruhi kualitas rasa dari ayam kecap pedas manis, pertama dari jenis bahan, kemudian pemilihan bahan segar sampai cara mengolah dan menghidangkannya. Tidak usah pusing jika hendak menyiapkan ayam kecap pedas manis yang enak di rumah, karena asal sudah tahu triknya maka hidangan ini bisa jadi suguhan istimewa.


Berikut ini ada beberapa cara mudah dan praktis dalam mengolah ayam kecap pedas manis yang siap dikreasikan. Anda dapat menyiapkan Ayam Kecap Pedas Manis menggunakan 20 jenis bahan dan 4 tahap pembuatan. Berikut ini langkah-langkah dalam membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam menyiapkan Ayam Kecap Pedas Manis:

1. Sediakan 500 gr ayam sayap
1. Sediakan  Bahan rebusan :
1. Ambil 1 cm lengkuas
1. Ambil 1 cm jahe
1. Sediakan 2 lembar daun salam
1. Sediakan  Bumbu Iris :
1. Siapkan 4 butir bawang merah
1. Ambil 3 siung bawang putih
1. Ambil 5 buah cabai rawit merah
1. Gunakan 2 lembar daun jeruk
1. Ambil  Bahan tambahan :
1. Sediakan 150 ml air
1. Sediakan 2 lembar daun salam
1. Gunakan 2 sdm kecap manis
1. Siapkan 1 sdm saus tiram
1. Ambil 2 sdm sau cabai
1. Siapkan 1/2 sdt merica bubuk
1. Sediakan 1/2 sdt garam
1. Sediakan 1 sdt kaldu bubuk
1. Siapkan 1 sdm gula merah




<!--inarticleads2-->

##### Langkah-langkah membuat Ayam Kecap Pedas Manis:

1. Rebus ayam dengan jahe, lengkuas dan daun salam hingga tercium bau harum. Lalu angkat dan cuci bersih. Kemudian goreng ayam sampai kecoklatan. Sisihkan.
1. Tumis bawang merah dan bawang putih, lalu masukkan irisan cabai dan daun jeruk. Tumis hingga layu.
1. Masukkan ayam, tuang air dan daun salam. Aduk.
1. Beri saus cabai, saus tiram, kecap manis, garam, gula, merica dan kaldu bubuk. Aduk rata, masak hingga kuah sedikit berkurang. Matikan kompor dan sajikan.




Terima kasih telah menggunakan resep yang tim kami tampilkan di sini. Harapan kami, olahan Ayam Kecap Pedas Manis yang mudah di atas dapat membantu Anda menyiapkan makanan yang menarik untuk keluarga/teman ataupun menjadi inspirasi untuk berjualan makanan. Semoga bermanfaat dan selamat mencoba!
