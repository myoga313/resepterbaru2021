---
description: "Bumbu Soto Ayam Madura | Cara Membuat Soto Ayam Madura Yang Enak Dan Mudah"
title: "Bumbu Soto Ayam Madura | Cara Membuat Soto Ayam Madura Yang Enak Dan Mudah"
slug: 422-bumbu-soto-ayam-madura-cara-membuat-soto-ayam-madura-yang-enak-dan-mudah
date: 2020-08-06T23:57:51.025Z
image: https://img-global.cpcdn.com/recipes/c5c069b577a65a99/751x532cq70/soto-ayam-madura-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/c5c069b577a65a99/751x532cq70/soto-ayam-madura-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/c5c069b577a65a99/751x532cq70/soto-ayam-madura-foto-resep-utama.jpg
author: Fannie Pittman
ratingvalue: 4.7
reviewcount: 14
recipeingredient:
- " ayam"
- " air"
- " serehambil bagian putihnya lalu geprek"
- " daun bawangbiarkan utuh"
- " seledribiarkan utuh"
- " daun salam"
- " daun jeruk"
- " cengkeh"
- " kaldu bubuk"
- " gula dan garam"
- " Bumbu Yang Di Haluskan "
- " bawang putih"
- " kemirisangrai"
- " jahe"
- " kunyit"
- " pala bubuk"
- " merica bubuk"
- " Pelengkap "
- " Bihunseduh air panas lalu tiriskan"
- " Telur rebus"
- " seledri"
- " kol sy skip"
- " Jeruk nipis"
- " Sambal"
- " Bawang merah goreng"
recipeinstructions:
- "Rebus ayam bersama daun jeruk,daun salam,sereh,daun bawang,seledri dan cengkeh sampai mendidih dengan api kecil agar kaldu ayam bening."
- "Tumis bumbu halus sampai harum dan matang lalu masukkan ke dalam rebusan ayam,tambahkan kaldu bubuk,gula dan garam,koreksi rasa,masak sampai ayam matang."
- "Setelah ayam matang,angkat ayamnya lalu goreng dan di suwir-suwir.Angkat juga daun bawang dan seledrinya."
- "Penyelesaian : Siapkan mangkuk,tata bihun,irisan kol,ayam suwir,telur rebus,sirami kuah panas-panas,taburi irisan seledri dan bawang goreng,sajikan dengan jeruk nipis dan sambal."
categories:
- Resep
tags:
- soto
- ayam
- madura

katakunci: soto ayam madura 
nutrition: 170 calories
recipecuisine: Indonesian
preptime: "PT10M"
cooktime: "PT51M"
recipeyield: "3"
recipecategory: Dessert

---


![Soto Ayam Madura](https://img-global.cpcdn.com/recipes/c5c069b577a65a99/751x532cq70/soto-ayam-madura-foto-resep-utama.jpg)


soto ayam madura ini yakni suguhan nusantara yang ekslusif dan wajib untuk kita coba. Cita rasanya yang enak membuat siapa pun menantikan kehadirannya di meja makan.
Lagi mencari inspirasi resep soto ayam madura untuk jualan atau dikonsumsi sendiri yang Bikin Ngiler? Cara menyiapkannya memang tidak susah dan tidak juga mudah. kalau keliru mengolah maka hasilnya akan hambar dan bahkan tidak sedap. Padahal soto ayam madura yang enak seharusnya mempunyai aroma dan cita rasa yang mampu memancing selera kita.

Banyak hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari soto ayam madura, pertama dari jenis bahan, lalu pemilihan bahan segar, sampai cara mengolah dan menghidangkannya. Tidak usah pusing kalau mau menyiapkan soto ayam madura yang enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini mampu menjadi suguhan spesial.




Nah, kali ini kita coba, yuk, buat soto ayam madura sendiri di rumah. Tetap berbahan sederhana, hidangan ini bisa memberi manfaat dalam membantu menjaga kesehatan tubuh kita. Anda bisa membuat Soto Ayam Madura menggunakan 25 bahan dan 4 langkah pembuatan. Berikut ini cara dalam membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk pembuatan Soto Ayam Madura:

1. Siapkan  ayam
1. Sediakan  air
1. Ambil  sereh,ambil bagian putihnya lalu geprek
1. Siapkan  daun bawang,biarkan utuh
1. Gunakan  seledri,biarkan utuh
1. Sediakan  daun salam
1. Sediakan  daun jeruk
1. Sediakan  cengkeh
1. Ambil  kaldu bubuk
1. Sediakan  gula dan garam
1. Sediakan  √Bumbu Yang Di Haluskan :
1. Siapkan  bawang putih
1. Siapkan  kemiri,sangrai
1. Siapkan  jahe
1. Siapkan  kunyit
1. Ambil  pala bubuk
1. Siapkan  merica bubuk
1. Siapkan  √Pelengkap :
1. Gunakan  Bihun,seduh air panas lalu tiriskan
1. Gunakan  Telur rebus
1. Siapkan  seledri
1. Gunakan  kol (sy skip)
1. Siapkan  Jeruk nipis
1. Gunakan  Sambal
1. Gunakan  Bawang merah goreng




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Soto Ayam Madura:

1. Rebus ayam bersama daun jeruk,daun salam,sereh,daun bawang,seledri dan cengkeh sampai mendidih dengan api kecil agar kaldu ayam bening.
1. Tumis bumbu halus sampai harum dan matang lalu masukkan ke dalam rebusan ayam,tambahkan kaldu bubuk,gula dan garam,koreksi rasa,masak sampai ayam matang.
1. Setelah ayam matang,angkat ayamnya lalu goreng dan di suwir-suwir.Angkat juga daun bawang dan seledrinya.
1. Penyelesaian : Siapkan mangkuk,tata bihun,irisan kol,ayam suwir,telur rebus,sirami kuah panas-panas,taburi irisan seledri dan bawang goreng,sajikan dengan jeruk nipis dan sambal.




Bagaimana? Gampang kan? Itulah cara membuat soto ayam madura yang bisa Anda praktikkan di rumah. Selamat mencoba!
