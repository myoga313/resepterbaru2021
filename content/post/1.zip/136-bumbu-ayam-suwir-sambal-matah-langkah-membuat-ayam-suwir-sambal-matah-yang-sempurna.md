---
description: "Bumbu Ayam Suwir Sambal Matah | Langkah Membuat Ayam Suwir Sambal Matah Yang Sempurna"
title: "Bumbu Ayam Suwir Sambal Matah | Langkah Membuat Ayam Suwir Sambal Matah Yang Sempurna"
slug: 136-bumbu-ayam-suwir-sambal-matah-langkah-membuat-ayam-suwir-sambal-matah-yang-sempurna
date: 2020-12-23T23:15:24.817Z
image: https://img-global.cpcdn.com/recipes/4ec19428916b7fe7/751x532cq70/ayam-suwir-sambal-matah-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/4ec19428916b7fe7/751x532cq70/ayam-suwir-sambal-matah-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/4ec19428916b7fe7/751x532cq70/ayam-suwir-sambal-matah-foto-resep-utama.jpg
author: Lucille Farmer
ratingvalue: 3.4
reviewcount: 11
recipeingredient:
- "1/2 dada ayam fillet"
- "Secukupnya air untuk merebus dada ayam"
- " 3 lembar daun salam"
- " Garam"
- " Merica"
- " Penyedap rasa"
- " Bahan irisan"
- "10 cabai setan sesuai selera iris"
- "4 batang serai iris tipis"
- "6 siung bawang merah iris tipis"
- "4 lembar daun jeruk iris tipis"
- "Secukupnya minyak untuk menumis"
- "1 buah jeruk limau"
recipeinstructions:
- "Potong dada ayam (supaya lebih cepat matang merata). Didihkan air, masukan potongan dada ayam, daun salam, garam dan merica. Setelah matang, tiriskan. Lalu suwir."
- "Panaskan minyak, tumis suwiran ayam sampai agak menguning. Masukan bahan irisan (cabai, bamer, batang serai, daun jeruk). Beri seasoning (garam, merica dan penyedap rasa). Matikan api. Saya beri perasan jeruk limau. Aduk. Koreksi rasa. Sajikan."
categories:
- Resep
tags:
- ayam
- suwir
- sambal

katakunci: ayam suwir sambal 
nutrition: 240 calories
recipecuisine: Indonesian
preptime: "PT28M"
cooktime: "PT43M"
recipeyield: "2"
recipecategory: Lunch

---


![Ayam Suwir Sambal Matah](https://img-global.cpcdn.com/recipes/4ec19428916b7fe7/751x532cq70/ayam-suwir-sambal-matah-foto-resep-utama.jpg)


ayam suwir sambal matah ini ialah suguhan nusantara yang mantap dan harus untuk kita coba. Cita rasanya yang mantap membuat siapa pun menantikan kehadirannya di meja makan.
Lagi mencari inspirasi resep ayam suwir sambal matah untuk jualan atau dikonsumsi sendiri yang Menggugah Selera? Cara membuatnya memang susah-susah gampang. semisal salah mengolah maka hasilnya tidak akan memuaskan dan bahkan tidak sedap. Padahal ayam suwir sambal matah yang enak seharusnya memiliki aroma dan cita rasa yang mampu memancing selera kita.

Ada beberapa hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari ayam suwir sambal matah, pertama dari jenis bahan, kemudian pemilihan bahan segar, hingga cara membuat dan menghidangkannya. Tak perlu pusing jika mau menyiapkan ayam suwir sambal matah enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini mampu jadi suguhan istimewa.




Di bawah ini ada beberapa cara mudah dan praktis untuk membuat ayam suwir sambal matah yang siap dikreasikan. Anda bisa menyiapkan Ayam Suwir Sambal Matah memakai 13 bahan dan 2 tahap pembuatan. Berikut ini cara dalam membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam pembuatan Ayam Suwir Sambal Matah:

1. Ambil 1/2 dada ayam fillet
1. Siapkan Secukupnya air untuk merebus dada ayam
1. Gunakan  3 lembar daun salam
1. Ambil  Garam
1. Gunakan  Merica
1. Sediakan  Penyedap rasa
1. Gunakan  Bahan irisan
1. Gunakan 10 cabai setan (sesuai selera), iris
1. Sediakan 4 batang serai, iris tipis
1. Ambil 6 siung bawang merah, iris tipis
1. Sediakan 4 lembar daun jeruk (iris tipis)
1. Siapkan Secukupnya minyak untuk menumis
1. Siapkan 1 buah jeruk limau




<!--inarticleads2-->

##### Cara menyiapkan Ayam Suwir Sambal Matah:

1. Potong dada ayam (supaya lebih cepat matang merata). Didihkan air, masukan potongan dada ayam, daun salam, garam dan merica. Setelah matang, tiriskan. Lalu suwir.
1. Panaskan minyak, tumis suwiran ayam sampai agak menguning. Masukan bahan irisan (cabai, bamer, batang serai, daun jeruk). Beri seasoning (garam, merica dan penyedap rasa). Matikan api. Saya beri perasan jeruk limau. Aduk. Koreksi rasa. Sajikan.




Bagaimana? Mudah bukan? Itulah cara membuat ayam suwir sambal matah yang bisa Anda praktikkan di rumah. Selamat mencoba!
