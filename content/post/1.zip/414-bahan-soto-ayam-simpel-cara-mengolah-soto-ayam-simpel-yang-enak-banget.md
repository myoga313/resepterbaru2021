---
description: "Bahan Soto Ayam Simpel | Cara Mengolah Soto Ayam Simpel Yang Enak Banget"
title: "Bahan Soto Ayam Simpel | Cara Mengolah Soto Ayam Simpel Yang Enak Banget"
slug: 414-bahan-soto-ayam-simpel-cara-mengolah-soto-ayam-simpel-yang-enak-banget
date: 2020-09-04T03:15:25.402Z
image: https://img-global.cpcdn.com/recipes/28ebda2e986cee85/751x532cq70/soto-ayam-simpel-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/28ebda2e986cee85/751x532cq70/soto-ayam-simpel-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/28ebda2e986cee85/751x532cq70/soto-ayam-simpel-foto-resep-utama.jpg
author: Ora Perez
ratingvalue: 3.9
reviewcount: 11
recipeingredient:
- "3 potong ayam"
- " royco"
- " garam"
- " gula pasir"
- " daun bawang"
- " tomat"
- " Bumbu Halus kalo di blender pake mimyak jangan air"
- "6 bawang merah"
- "4 bawang putih"
- "4 cm kunyit kurleb"
- "1 buah kemiri yang utuh"
- "1 sdt ketumbar"
- "1/2 sdt merica"
- "sejumput pala gak pake gpp"
- " Bumbu Tambahan Tumisan"
- "1 buah sereh geprek"
- "3 helai daun salam"
- "2 helai daun jeruk sobek"
- " kurleb 4 cm lengkuas"
- " toping rebus dan tiriskan"
- " cengek kalo mau makan ulek di mangkok"
- " soun"
- " toge"
- " kol"
- " taburan"
- " daun seledri"
- " bawang goreng sumenep"
- " jeruk nipis"
recipeinstructions:
- "Rebus ayam sampai mendidih"
- "Sambil tunggu ayam mendidih tumis bumbu halus dan humbu tambahan tumisan hingga layu dan wangi dan menyusut"
- "Setelah itu masukan ke dalam kuah kaldu ayam"
- "Rebus hingga mendidih masukkan daun bawang yg sudah di potong dan tomat"
- "Setelah mendidih masukan royco garam dan gula lalu tes rasa"
- "Goreng ayam yg ada di dalam panci soto lalu suwir2"
- "Siapkan mangkok isi soun yg sudah d rebus"
- "Masukkan kol yg sudah d rebus toge dan ayam"
- "Isi dengan kuah dan potongan tahu bacem dajikan dengan nasi terpisah atau bisa juga di campur"
categories:
- Resep
tags:
- soto
- ayam
- simpel

katakunci: soto ayam simpel 
nutrition: 202 calories
recipecuisine: Indonesian
preptime: "PT31M"
cooktime: "PT54M"
recipeyield: "4"
recipecategory: Dessert

---


![Soto Ayam Simpel](https://img-global.cpcdn.com/recipes/28ebda2e986cee85/751x532cq70/soto-ayam-simpel-foto-resep-utama.jpg)


soto ayam simpel ini merupakan kuliner tanah air yang mantap dan harus untuk kita coba. Cita rasanya yang mantap membuat siapa pun menantikan kehadirannya di meja makan.
Bunda lagi mencari inspirasi resep soto ayam simpel untuk jualan atau dikonsumsi sendiri yang Bisa Manjain Lidah? Cara Bikinnya memang susah-susah gampang. misalnya keliru mengolah maka hasilnya Tidak Memuaskan dan justru cenderung tidak enak. Padahal soto ayam simpel yang enak harusnya sih punya aroma dan rasa yang bisa memancing selera kita.

Banyak hal yang sedikit banyak mempengaruhi kualitas rasa dari soto ayam simpel, pertama dari jenis bahan, lalu pemilihan bahan segar, sampai cara membuat dan menyajikannya. Tak perlu pusing jika ingin menyiapkan soto ayam simpel enak di rumah, karena asal sudah tahu triknya maka hidangan ini mampu jadi suguhan spesial.




Nah, kali ini kita coba, yuk, buat soto ayam simpel sendiri di rumah. Tetap dengan bahan yang sederhana, hidangan ini dapat memberi manfaat untuk membantu menjaga kesehatan tubuh kita. Anda bisa membuat Soto Ayam Simpel memakai 28 bahan dan 9 langkah pembuatan. Berikut ini cara dalam membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk menyiapkan Soto Ayam Simpel:

1. Siapkan 3 potong ayam
1. Ambil  royco
1. Gunakan  garam
1. Ambil  gula pasir
1. Siapkan  daun bawang
1. Gunakan  tomat
1. Siapkan  Bumbu Halus (kalo di blender pake mimyak jangan air)
1. Sediakan 6 bawang merah
1. Ambil 4 bawang putih
1. Sediakan 4 cm kunyit kurleb
1. Sediakan 1 buah kemiri (yang utuh)
1. Sediakan 1 sdt ketumbar
1. Sediakan 1/2 sdt merica
1. Ambil sejumput pala (gak pake gpp)
1. Siapkan  Bumbu Tambahan Tumisan
1. Gunakan 1 buah sereh geprek
1. Ambil 3 helai daun salam
1. Siapkan 2 helai daun jeruk sobek
1. Gunakan  kurleb 4 cm lengkuas
1. Sediakan  toping (rebus dan tiriskan)
1. Gunakan  cengek (kalo mau makan ulek di mangkok)
1. Gunakan  soun
1. Sediakan  toge
1. Gunakan  kol
1. Siapkan  taburan
1. Siapkan  daun seledri
1. Sediakan  bawang goreng sumenep
1. Gunakan  jeruk nipis




<!--inarticleads2-->

##### Cara membuat Soto Ayam Simpel:

1. Rebus ayam sampai mendidih
1. Sambil tunggu ayam mendidih tumis bumbu halus dan humbu tambahan tumisan hingga layu dan wangi dan menyusut
1. Setelah itu masukan ke dalam kuah kaldu ayam
1. Rebus hingga mendidih masukkan daun bawang yg sudah di potong dan tomat
1. Setelah mendidih masukan royco garam dan gula lalu tes rasa
1. Goreng ayam yg ada di dalam panci soto lalu suwir2
1. Siapkan mangkok isi soun yg sudah d rebus
1. Masukkan kol yg sudah d rebus toge dan ayam
1. Isi dengan kuah dan potongan tahu bacem dajikan dengan nasi terpisah atau bisa juga di campur




Bagaimana? Mudah bukan? Itulah cara menyiapkan soto ayam simpel yang bisa Anda lakukan di rumah. Semoga bermanfaat dan selamat mencoba!
