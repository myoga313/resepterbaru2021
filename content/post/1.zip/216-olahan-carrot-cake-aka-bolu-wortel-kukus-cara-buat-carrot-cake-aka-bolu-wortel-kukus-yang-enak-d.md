---
description: "Olahan Carrot Cake aka. Bolu Wortel (kukus) | Cara Buat Carrot Cake aka. Bolu Wortel (kukus) Yang Enak Dan Lezat"
title: "Olahan Carrot Cake aka. Bolu Wortel (kukus) | Cara Buat Carrot Cake aka. Bolu Wortel (kukus) Yang Enak Dan Lezat"
slug: 216-olahan-carrot-cake-aka-bolu-wortel-kukus-cara-buat-carrot-cake-aka-bolu-wortel-kukus-yang-enak-dan-lezat
date: 2021-01-12T02:30:28.713Z
image: https://img-global.cpcdn.com/recipes/e9f48b3fcee432d0/751x532cq70/carrot-cake-aka-bolu-wortel-kukus-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/e9f48b3fcee432d0/751x532cq70/carrot-cake-aka-bolu-wortel-kukus-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/e9f48b3fcee432d0/751x532cq70/carrot-cake-aka-bolu-wortel-kukus-foto-resep-utama.jpg
author: Lula Zimmerman
ratingvalue: 3.1
reviewcount: 4
recipeingredient:
- " wortel kupas dan parut"
- " Bahan A lelehkan"
- " coklat putih batangan"
- " minyak sayur"
- " susu kental manis"
- " Bahan B tepung"
- " tepung terigu pro sedang"
- " tepung maizena"
- " susu bubuk"
- " vanili bubuk"
- " garam"
- " baking powder"
- " Bahan C mixer"
- " telur"
- " ovalet"
- " gula pasir"
recipeinstructions:
- "Siapkan bahan A Lelehkan coklat putih dan minyak dengan cara di-team (di atas didihan air dalam wajan yang ditaruh dalam wadah terpisah). Setelah larut, tuangkan 1 sdm susu kental manis, aduk rata. Sisihkan, kalau bisa dekat kipas angin supaya cepat dingin."
- "Sambil menunggu larutan coklat mendingin, parut wortel. Siapkan dan panaskan kukusan. Alasi loyang dengan kertas baking dan olesi dengan margarin."
- "Siapkan Bahan B (tepung dll.). Campur semua dalam satu wadah sambil disaring/ayak."
- "Siapkan Bahan C. Mixer dengan kecepatan sedang ke tinggi sampai kental mengembang, kira2 15 menit."
- "Masukkan Bahan B (tepung2an) ke Bahan C (hasil mixer), aduk rata dengan spatula."
- "Tuang Bahan A (larutan coklat/minyak/susu) ke dalam wadah sambil disaring, aduk rata dengan spatula."
- "Masukkan parutan wortel, aduk rata dengan spatula. Tuang ke dalam cetakan. Beri sedikit parutan wortel di atasnya sebagai topping pemanis."
- "Kukus selama 40-45 menit. Biarkan mendingin di luar kukusan sebelum dipotong2 untuk dinikmati :)"
categories:
- Resep
tags:
- carrot
- cake
- aka

katakunci: carrot cake aka 
nutrition: 133 calories
recipecuisine: Indonesian
preptime: "PT18M"
cooktime: "PT58M"
recipeyield: "1"
recipecategory: Lunch

---


![Carrot Cake aka. Bolu Wortel (kukus)](https://img-global.cpcdn.com/recipes/e9f48b3fcee432d0/751x532cq70/carrot-cake-aka-bolu-wortel-kukus-foto-resep-utama.jpg)


carrot cake aka. bolu wortel (kukus) ini ialah santapan tanah air yang istimewa dan wajib untuk kita coba. Cita rasanya yang nikmat membuat siapa pun menantikan kehadirannya di meja makan.
Lagi mencari ide resep carrot cake aka. bolu wortel (kukus) untuk jualan atau dikonsumsi sendiri yang Sedap? Cara Memasaknya memang tidak terlalu sulit namun tidak gampang juga. andaikan salah mengolah maka hasilnya akan hambar dan bahkan tidak sedap. Padahal carrot cake aka. bolu wortel (kukus) yang enak seharusnya memiliki aroma dan cita rasa yang mampu memancing selera kita.



Banyak hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari carrot cake aka. bolu wortel (kukus), pertama dari jenis bahan, kedua pemilihan bahan segar sampai cara membuat dan menyajikannya. Tak perlu pusing jika hendak menyiapkan carrot cake aka. bolu wortel (kukus) enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini bisa jadi sajian istimewa.


Nah, kali ini kita coba, yuk, buat carrot cake aka. bolu wortel (kukus) sendiri di rumah. Tetap berbahan sederhana, hidangan ini bisa memberi manfaat dalam membantu menjaga kesehatan tubuhmu sekeluarga. Anda bisa menyiapkan Carrot Cake aka. Bolu Wortel (kukus) memakai 16 jenis bahan dan 8 langkah pembuatan. Berikut ini cara dalam membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam pembuatan Carrot Cake aka. Bolu Wortel (kukus):

1. Ambil  wortel, kupas dan parut
1. Ambil  Bahan A (lelehkan)
1. Siapkan  coklat putih batangan
1. Siapkan  minyak sayur
1. Ambil  susu kental manis
1. Siapkan  Bahan B (tepung)
1. Sediakan  tepung terigu pro sedang
1. Gunakan  tepung maizena
1. Gunakan  susu bubuk
1. Sediakan  vanili bubuk
1. Ambil  garam
1. Gunakan  baking powder
1. Siapkan  Bahan C (mixer)
1. Siapkan  telur
1. Ambil  ovalet
1. Ambil  gula pasir




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Carrot Cake aka. Bolu Wortel (kukus):

1. Siapkan bahan A Lelehkan coklat putih dan minyak dengan cara di-team (di atas didihan air dalam wajan yang ditaruh dalam wadah terpisah). Setelah larut, tuangkan 1 sdm susu kental manis, aduk rata. Sisihkan, kalau bisa dekat kipas angin supaya cepat dingin.
1. Sambil menunggu larutan coklat mendingin, parut wortel. Siapkan dan panaskan kukusan. Alasi loyang dengan kertas baking dan olesi dengan margarin.
1. Siapkan Bahan B (tepung dll.). Campur semua dalam satu wadah sambil disaring/ayak.
1. Siapkan Bahan C. Mixer dengan kecepatan sedang ke tinggi sampai kental mengembang, kira2 15 menit.
1. Masukkan Bahan B (tepung2an) ke Bahan C (hasil mixer), aduk rata dengan spatula.
1. Tuang Bahan A (larutan coklat/minyak/susu) ke dalam wadah sambil disaring, aduk rata dengan spatula.
1. Masukkan parutan wortel, aduk rata dengan spatula. Tuang ke dalam cetakan. Beri sedikit parutan wortel di atasnya sebagai topping pemanis.
1. Kukus selama 40-45 menit. Biarkan mendingin di luar kukusan sebelum dipotong2 untuk dinikmati :)




Gimana nih? Mudah bukan? Itulah cara membuat carrot cake aka. bolu wortel (kukus) yang bisa Anda lakukan di rumah. Selamat mencoba!
