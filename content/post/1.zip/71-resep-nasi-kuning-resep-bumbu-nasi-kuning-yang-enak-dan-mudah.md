---
description: "Resep Nasi Kuning | Resep Bumbu Nasi Kuning Yang Enak Dan Mudah"
title: "Resep Nasi Kuning | Resep Bumbu Nasi Kuning Yang Enak Dan Mudah"
slug: 71-resep-nasi-kuning-resep-bumbu-nasi-kuning-yang-enak-dan-mudah
date: 2020-08-26T09:53:21.600Z
image: https://img-global.cpcdn.com/recipes/39f9ccb7f391f412/751x532cq70/nasi-kuning-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/39f9ccb7f391f412/751x532cq70/nasi-kuning-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/39f9ccb7f391f412/751x532cq70/nasi-kuning-foto-resep-utama.jpg
author: Hester French
ratingvalue: 4.7
reviewcount: 10
recipeingredient:
- "4 cup beras"
- "150 gr santan instan"
- "Secukupnya air"
- "7 cm kunyit tua parut peras airnya"
- "3 lbr daun jeruk"
- "1 btg sereh geprek"
- "1 lbr daun pandan tambahan sy"
- "2 cm lengkuas tambahan sy"
- "2 lbr daun salam tambahan sy"
- "Secukupnya garam"
recipeinstructions:
- "Cuci bersih beras, tiriskan. Masukan beras ke dalam panci magiccom. Tuang santan, tambahkan air hingga mencukupi air seperti memasak nasi biasa. Masukan semua bahan daun dan garam. Tuang perasan kunyit sambil disaring. Aduk rata."
- "Tekan tombol cook pada magiccom, biarkan hingga matang dan tombol berpindah ke warm."
- "Aduk² nasi setelah matang. Dan nasi kuning siap disajikan dengan lauk kesukaan."
categories:
- Resep
tags:
- nasi
- kuning

katakunci: nasi kuning 
nutrition: 212 calories
recipecuisine: Indonesian
preptime: "PT35M"
cooktime: "PT32M"
recipeyield: "3"
recipecategory: Dessert

---


![Nasi Kuning](https://img-global.cpcdn.com/recipes/39f9ccb7f391f412/751x532cq70/nasi-kuning-foto-resep-utama.jpg)


nasi kuning ini ialah suguhan nusantara yang istimewa dan wajib untuk kita coba. Cita rasanya yang lezat membuat siapa pun menantikan kehadirannya di meja makan.
Kamu Sedang mencari ide resep nasi kuning untuk jualan atau dikonsumsi sendiri yang Menggugah Selera? Cara Memasaknya memang susah-susah gampang. seandainya keliru mengolah maka hasilnya tidak akan memuaskan dan bahkan tidak sedap. Padahal nasi kuning yang enak harusnya sih memiliki aroma dan rasa yang dapat memancing selera kita.



Banyak hal yang sedikit banyak mempengaruhi kualitas rasa dari nasi kuning, mulai dari jenis bahan, kedua pemilihan bahan segar hingga cara mengolah dan menghidangkannya. Tak perlu pusing jika hendak menyiapkan nasi kuning enak di rumah, karena asal sudah tahu triknya maka hidangan ini bisa jadi sajian spesial.


Berikut ini ada beberapa tips dan trik praktis untuk membuat nasi kuning yang siap dikreasikan. Anda bisa membuat Nasi Kuning memakai 10 bahan dan 3 tahap pembuatan. Berikut ini langkah-langkah dalam membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk menyiapkan Nasi Kuning:

1. Gunakan 4 cup beras
1. Sediakan 150 gr santan instan
1. Siapkan Secukupnya air
1. Sediakan 7 cm kunyit tua, parut, peras airnya
1. Sediakan 3 lbr daun jeruk
1. Sediakan 1 btg sereh, geprek
1. Sediakan 1 lbr daun pandan (tambahan sy)
1. Siapkan 2 cm lengkuas (tambahan sy)
1. Gunakan 2 lbr daun salam (tambahan sy)
1. Sediakan Secukupnya garam




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Nasi Kuning:

1. Cuci bersih beras, tiriskan. Masukan beras ke dalam panci magiccom. Tuang santan, tambahkan air hingga mencukupi air seperti memasak nasi biasa. Masukan semua bahan daun dan garam. Tuang perasan kunyit sambil disaring. Aduk rata.
1. Tekan tombol cook pada magiccom, biarkan hingga matang dan tombol berpindah ke warm.
1. Aduk² nasi setelah matang. Dan nasi kuning siap disajikan dengan lauk kesukaan.




Gimana nih? Mudah bukan? Itulah cara membuat nasi kuning yang bisa Anda lakukan di rumah. Selamat mencoba!
