---
description: "Resep Ayam Goreng Serundeng | Resep Membuat Ayam Goreng Serundeng Yang Enak Banget"
title: "Resep Ayam Goreng Serundeng | Resep Membuat Ayam Goreng Serundeng Yang Enak Banget"
slug: 272-resep-ayam-goreng-serundeng-resep-membuat-ayam-goreng-serundeng-yang-enak-banget
date: 2020-12-04T17:46:53.476Z
image: https://img-global.cpcdn.com/recipes/fe5712e12febab5c/751x532cq70/ayam-goreng-serundeng-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/fe5712e12febab5c/751x532cq70/ayam-goreng-serundeng-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/fe5712e12febab5c/751x532cq70/ayam-goreng-serundeng-foto-resep-utama.jpg
author: Steven Lambert
ratingvalue: 4.8
reviewcount: 13
recipeingredient:
- "500 gr ayam bagian paha marinasi dengan jeruk nipis dan garam secukupnya selama 10 menit kemudian bilas kembali"
- "100 gr kelapa parut"
- "1 batang serai digeprek"
- "2 lembar daun jeruk"
- "2 ruas lengkuas digeprek"
- "2 lembar daun salam"
- "1/4 sdt lada bubuk"
- "1/2 sdt kaldu bubuk"
- "Secukupnya garam"
- "Secukupnya minyak goreng untuk menumis"
- "Secukupnya air"
- " Bumbu Halus"
- "5 siung bawang merah"
- "3 siung bawang putih"
- "2 ruas kunyit"
- "2 ruas Jahe"
- "1 sdt ketumbar"
- "2 buah kemiri"
- " Pelengkap"
- " Lalapan optional"
- " Sambal tomat optional"
recipeinstructions:
- "Siapkan bahan yang akan digunakan"
- "Tumis bumbu halus, lengkuas, serai, daun salam dan daun jeruk sampai harum. Kemudian masukkan ayam, aduk rata, masak sebentar sampai daging ayam berubah warna agak putih"
- "Kemudian tambahkan lada bubuk, kaldu bubuk, secukupnya air dan garam, aduk rata, koreksi rasa. Jika sudah pas masukkan kelapa parut"
- "Masak sampai ayam matang dan kuahnya habis, sesekali diaduk. Kemudian pisahkan ayam dari bumbunya"
- "Goreng ayam sampai berwarna golden brown, angkat dan tiriskan"
- "Kemudian goreng bumbu sampai berwarna golden brown, sambil diaduk-aduk agar tidak gosong dan matangnya merata. Angkat dan tiriskan"
- "Penyajian: Tata ayam goreng di piring saji, kemudian taburkan serundeng yang sudah digoreng. Ayam Goreng Serundeng siap disajikan dengan sambal dan lalapan"
categories:
- Resep
tags:
- ayam
- goreng
- serundeng

katakunci: ayam goreng serundeng 
nutrition: 192 calories
recipecuisine: Indonesian
preptime: "PT38M"
cooktime: "PT36M"
recipeyield: "2"
recipecategory: Dessert

---


![Ayam Goreng Serundeng](https://img-global.cpcdn.com/recipes/fe5712e12febab5c/751x532cq70/ayam-goreng-serundeng-foto-resep-utama.jpg)


ayam goreng serundeng ini ialah makanan nusantara yang spesial dan harus untuk kita coba. Cita rasanya yang mantap membuat siapa pun menantikan kehadirannya di meja makan.
Anda sedang mencari ide resep ayam goreng serundeng untuk jualan atau dikonsumsi sendiri yang Enak dan Simpel? Cara Buatnya memang tidak terlalu sulit namun tidak gampang juga. misalnya salah mengolah maka hasilnya akan hambar dan justru cenderung tidak enak. Padahal ayam goreng serundeng yang enak seharusnya mempunyai aroma dan rasa yang mampu memancing selera kita.



Banyak hal yang sedikit banyak mempengaruhi kualitas rasa dari ayam goreng serundeng, mulai dari jenis bahan, kemudian pemilihan bahan segar sampai cara mengolah dan menghidangkannya. Tidak usah pusing kalau mau menyiapkan ayam goreng serundeng yang enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini dapat menjadi suguhan spesial.


Nah, kali ini kita coba, yuk, siapkan ayam goreng serundeng sendiri di rumah. Tetap berbahan yang sederhana, hidangan ini dapat memberi manfaat dalam membantu menjaga kesehatan tubuhmu sekeluarga. Anda bisa menyiapkan Ayam Goreng Serundeng menggunakan 21 bahan dan 7 tahap pembuatan. Berikut ini langkah-langkah untuk menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam pembuatan Ayam Goreng Serundeng:

1. Gunakan 500 gr ayam bagian paha, (marinasi dengan jeruk nipis dan garam secukupnya selama 10 menit, kemudian bilas kembali)
1. Sediakan 100 gr kelapa parut
1. Gunakan 1 batang serai, digeprek
1. Ambil 2 lembar daun jeruk
1. Gunakan 2 ruas lengkuas, digeprek
1. Sediakan 2 lembar daun salam
1. Sediakan 1/4 sdt lada bubuk
1. Sediakan 1/2 sdt kaldu bubuk
1. Siapkan Secukupnya garam
1. Siapkan Secukupnya minyak goreng untuk menumis
1. Gunakan Secukupnya air
1. Sediakan  Bumbu Halus:
1. Sediakan 5 siung bawang merah
1. Gunakan 3 siung bawang putih
1. Sediakan 2 ruas kunyit
1. Ambil 2 ruas Jahe
1. Gunakan 1 sdt ketumbar
1. Siapkan 2 buah kemiri
1. Sediakan  Pelengkap
1. Ambil  Lalapan (optional)
1. Siapkan  Sambal tomat (optional)




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Ayam Goreng Serundeng:

1. Siapkan bahan yang akan digunakan
1. Tumis bumbu halus, lengkuas, serai, daun salam dan daun jeruk sampai harum. Kemudian masukkan ayam, aduk rata, masak sebentar sampai daging ayam berubah warna agak putih
1. Kemudian tambahkan lada bubuk, kaldu bubuk, secukupnya air dan garam, aduk rata, koreksi rasa. Jika sudah pas masukkan kelapa parut
1. Masak sampai ayam matang dan kuahnya habis, sesekali diaduk. Kemudian pisahkan ayam dari bumbunya
1. Goreng ayam sampai berwarna golden brown, angkat dan tiriskan
1. Kemudian goreng bumbu sampai berwarna golden brown, sambil diaduk-aduk agar tidak gosong dan matangnya merata. Angkat dan tiriskan
1. Penyajian: Tata ayam goreng di piring saji, kemudian taburkan serundeng yang sudah digoreng. Ayam Goreng Serundeng siap disajikan dengan sambal dan lalapan




Terima kasih telah menggunakan resep yang tim kami tampilkan di halaman ini. Harapan kami, olahan Ayam Goreng Serundeng yang mudah di atas dapat membantu Anda menyiapkan hidangan yang sedap untuk keluarga/teman maupun menjadi ide dalam berbisnis kuliner. Semoga bermanfaat dan selamat mencoba!
