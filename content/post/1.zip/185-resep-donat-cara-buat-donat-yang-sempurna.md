---
description: "Resep Donat | Cara Buat Donat Yang Sempurna"
title: "Resep Donat | Cara Buat Donat Yang Sempurna"
slug: 185-resep-donat-cara-buat-donat-yang-sempurna
date: 2020-08-28T15:33:59.794Z
image: https://img-global.cpcdn.com/recipes/9b98984ccad7f2ea/751x532cq70/donat-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/9b98984ccad7f2ea/751x532cq70/donat-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/9b98984ccad7f2ea/751x532cq70/donat-foto-resep-utama.jpg
author: Claudia Kelly
ratingvalue: 4.5
reviewcount: 5
recipeingredient:
- "250 gr tepung terigu"
- "2,5 sdm gula pasir"
- "100 ml air hangat"
- "1 sdm susu bubuk aku pake milo"
- "1 butir kuning telur"
- "3 gr baking powder"
- "50 gr mentega cair"
recipeinstructions:
- "Masukan tepung terigu, gula, baking powder, kuning telur dan tambahkan air sedikit demi sedikit kedalam wadah"
- "Lalu masukan susu bubuk, dan mentega cair, aduk dan uleni adonan sampai kalis. Tutup adonan dengan kain selama 15 menit."
- "Setelah adonan mengembang, bentuk bulat adonan, dan tutup dengan kain sampai 45 menit."
- "Panaskan minyak, lalu lubangi adonan yang sudah dibentuk bulat, goreng dengan api sedang, balik donat 1x saja agar tidak menyerap banyak minyak, lakukan sampai adonan habis. Angkat dan tiriskan, tunggu sampai dingin. Beri topping sesuai selera😍"
categories:
- Resep
tags:
- donat

katakunci: donat 
nutrition: 249 calories
recipecuisine: Indonesian
preptime: "PT28M"
cooktime: "PT48M"
recipeyield: "3"
recipecategory: Lunch

---


![Donat](https://img-global.cpcdn.com/recipes/9b98984ccad7f2ea/751x532cq70/donat-foto-resep-utama.jpg)


donat ini ialah kuliner nusantara yang istimewa dan wajib untuk kita coba. Cita rasanya yang mantap membuat siapa pun menantikan kehadirannya di meja makan.
Sedang mencari ide resep donat untuk jualan atau dikonsumsi sendiri yang Enak Dan Lezat? Cara membuatnya memang tidak susah dan tidak juga mudah. apabila salah mengolah maka hasilnya tidak akan memuaskan dan justru cenderung tidak enak. Padahal donat yang enak seharusnya punya aroma dan rasa yang mampu memancing selera kita.

Banyak hal yang sedikit banyak mempengaruhi kualitas rasa dari donat, pertama dari jenis bahan, lalu pemilihan bahan segar, hingga cara mengolah dan menyajikannya. Tak perlu pusing jika hendak menyiapkan donat enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini bisa jadi suguhan spesial.




Nah, kali ini kita coba, yuk, buat donat sendiri di rumah. Tetap berbahan yang sederhana, sajian ini bisa memberi manfaat untuk membantu menjaga kesehatan tubuh kita. Anda dapat menyiapkan Donat menggunakan 7 bahan dan 4 langkah pembuatan. Berikut ini cara dalam membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam menyiapkan Donat:

1. Sediakan 250 gr tepung terigu
1. Ambil 2,5 sdm gula pasir
1. Siapkan 100 ml air hangat
1. Siapkan 1 sdm susu bubuk (aku pake milo)
1. Gunakan 1 butir kuning telur
1. Ambil 3 gr baking powder
1. Gunakan 50 gr mentega cair




<!--inarticleads2-->

##### Cara membuat Donat:

1. Masukan tepung terigu, gula, baking powder, kuning telur dan tambahkan air sedikit demi sedikit kedalam wadah
1. Lalu masukan susu bubuk, dan mentega cair, aduk dan uleni adonan sampai kalis. Tutup adonan dengan kain selama 15 menit.
1. Setelah adonan mengembang, bentuk bulat adonan, dan tutup dengan kain sampai 45 menit.
1. Panaskan minyak, lalu lubangi adonan yang sudah dibentuk bulat, goreng dengan api sedang, balik donat 1x saja agar tidak menyerap banyak minyak, lakukan sampai adonan habis. Angkat dan tiriskan, tunggu sampai dingin. Beri topping sesuai selera😍




Terima kasih telah menggunakan resep yang kami tampilkan di sini. Harapan kami, olahan Donat yang mudah di atas dapat membantu Anda menyiapkan makanan yang sedap untuk keluarga/teman maupun menjadi ide dalam berbisnis kuliner. Semoga bermanfaat dan selamat mencoba!
