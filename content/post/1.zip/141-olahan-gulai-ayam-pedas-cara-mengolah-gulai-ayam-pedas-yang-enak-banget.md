---
description: "Olahan Gulai Ayam Pedas | Cara Mengolah Gulai Ayam Pedas Yang Enak Banget"
title: "Olahan Gulai Ayam Pedas | Cara Mengolah Gulai Ayam Pedas Yang Enak Banget"
slug: 141-olahan-gulai-ayam-pedas-cara-mengolah-gulai-ayam-pedas-yang-enak-banget
date: 2020-12-31T07:41:36.791Z
image: https://img-global.cpcdn.com/recipes/8c1a670c653e168e/751x532cq70/gulai-ayam-pedas-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/8c1a670c653e168e/751x532cq70/gulai-ayam-pedas-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/8c1a670c653e168e/751x532cq70/gulai-ayam-pedas-foto-resep-utama.jpg
author: Derrick French
ratingvalue: 3.2
reviewcount: 11
recipeingredient:
- " Ayam Me Bagian Paha Cincang Kecil"
- " Jeruk Nipis"
- " Bumbu halus"
- " Bawang Merah"
- " Bawang Putih"
- " Cabe Merah Keriting"
- " Cabe Rawit Merah"
- " Kunyit"
- " Jahe"
- " Ketumbar Sangrai"
- " Kemiri Sangrai"
- " Jintan"
- " Bumbum Utuh"
- " Daun Salam"
- " Daun Jeruk buang tulangnya"
- " Serai Geprek"
- " Lengkuas Geprek"
- " Asam Kandis ukuran Sedang"
- " Air"
- " Santan Kara 65ml"
- " Minyak secukupnya untuk menumis"
- " Garam"
- " Gula"
- " Kaldu Ayam Sesuai Selera"
recipeinstructions:
- "Cuci ayam sampai bersih, lalu kucuri dengan air perasan jeruk nipis. Diamkan selama 10 menit, lalu bilas kembali hingga bersih. Sisihkan"
- "Siapkan bumbu - bumbu. Baik yg dihaluskan dan yg utuh"
- "Tumis terlebih dahulu bumbu halus hingga harum, kemudian masukkan bumbu utuh dan masak hingga matang"
- "Setelah itu masukkan ayam yg sudah dibersihka. Tumis hingga bumbu tercampur rata dengan ayam. Kemudian tambahkan air + santan, aduk rata"
- "Kemudian masukkan garam + gula + kaldu ayam. Masak ayam hingga matang dan air sedikit menyusut."
- "Jika sudah matang, angkat dan siap disajikan. Selesai"
categories:
- Resep
tags:
- gulai
- ayam
- pedas

katakunci: gulai ayam pedas 
nutrition: 200 calories
recipecuisine: Indonesian
preptime: "PT34M"
cooktime: "PT56M"
recipeyield: "4"
recipecategory: Dinner

---


![Gulai Ayam Pedas](https://img-global.cpcdn.com/recipes/8c1a670c653e168e/751x532cq70/gulai-ayam-pedas-foto-resep-utama.jpg)


gulai ayam pedas ini ialah hidangan nusantara yang ekslusif dan harus untuk kita coba. Cita rasanya yang mantap membuat siapa pun menantikan kehadirannya di meja makan.
Bunda lagi mencari ide resep gulai ayam pedas untuk jualan atau dikonsumsi sendiri yang Mudah Dan Praktis? Cara membuatnya memang tidak terlalu sulit namun tidak gampang juga. misalnya keliru mengolah maka hasilnya akan hambar dan bahkan tidak sedap. Padahal gulai ayam pedas yang enak seharusnya memiliki aroma dan cita rasa yang bisa memancing selera kita.



Ada beberapa hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari gulai ayam pedas, mulai dari jenis bahan, lalu pemilihan bahan segar sampai cara membuat dan menghidangkannya. Tak perlu pusing jika ingin menyiapkan gulai ayam pedas enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini mampu jadi suguhan spesial.


Di bawah ini ada beberapa cara mudah dan praktis dalam mengolah gulai ayam pedas yang siap dikreasikan. Anda bisa menyiapkan Gulai Ayam Pedas menggunakan 24 jenis bahan dan 6 langkah pembuatan. Berikut ini langkah-langkah dalam membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk pembuatan Gulai Ayam Pedas:

1. Sediakan  Ayam (Me Bagian Paha) Cincang Kecil
1. Siapkan  Jeruk Nipis
1. Siapkan  Bumbu halus
1. Ambil  Bawang Merah
1. Gunakan  Bawang Putih
1. Siapkan  Cabe Merah Keriting
1. Siapkan  Cabe Rawit Merah
1. Siapkan  Kunyit
1. Gunakan  Jahe
1. Ambil  Ketumbar Sangrai
1. Sediakan  Kemiri Sangrai
1. Gunakan  Jintan
1. Ambil  Bumbum Utuh
1. Gunakan  Daun Salam
1. Ambil  Daun Jeruk buang tulangnya
1. Sediakan  Serai Geprek
1. Ambil  Lengkuas Geprek
1. Siapkan  Asam Kandis ukuran Sedang
1. Sediakan  Air
1. Ambil  Santan Kara 65ml
1. Ambil  Minyak secukupnya untuk menumis
1. Gunakan  Garam
1. Sediakan  Gula
1. Ambil  Kaldu Ayam (Sesuai Selera)




<!--inarticleads2-->

##### Langkah-langkah membuat Gulai Ayam Pedas:

1. Cuci ayam sampai bersih, lalu kucuri dengan air perasan jeruk nipis. Diamkan selama 10 menit, lalu bilas kembali hingga bersih. Sisihkan
1. Siapkan bumbu - bumbu. Baik yg dihaluskan dan yg utuh
1. Tumis terlebih dahulu bumbu halus hingga harum, kemudian masukkan bumbu utuh dan masak hingga matang
1. Setelah itu masukkan ayam yg sudah dibersihka. Tumis hingga bumbu tercampur rata dengan ayam. Kemudian tambahkan air + santan, aduk rata
1. Kemudian masukkan garam + gula + kaldu ayam. Masak ayam hingga matang dan air sedikit menyusut.
1. Jika sudah matang, angkat dan siap disajikan. Selesai




Bagaimana? Mudah bukan? Itulah cara membuat gulai ayam pedas yang bisa Anda praktikkan di rumah. Semoga bermanfaat dan selamat mencoba!
