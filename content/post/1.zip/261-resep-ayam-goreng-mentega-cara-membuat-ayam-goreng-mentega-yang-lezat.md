---
description: "Resep Ayam goreng mentega | Cara Membuat Ayam goreng mentega Yang Lezat"
title: "Resep Ayam goreng mentega | Cara Membuat Ayam goreng mentega Yang Lezat"
slug: 261-resep-ayam-goreng-mentega-cara-membuat-ayam-goreng-mentega-yang-lezat
date: 2020-10-20T19:02:56.546Z
image: https://img-global.cpcdn.com/recipes/c258f58626b3a8c4/751x532cq70/ayam-goreng-mentega-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/c258f58626b3a8c4/751x532cq70/ayam-goreng-mentega-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/c258f58626b3a8c4/751x532cq70/ayam-goreng-mentega-foto-resep-utama.jpg
author: Tom Williams
ratingvalue: 3.8
reviewcount: 8
recipeingredient:
- " ayam ukuran sedang"
- " kecap manis"
- " saus tiram"
- " kecap inggris"
- " gula pasir"
- " kecap asin"
- " bawang bombay ukuran sedang potong tebal memanjang"
- " daun bawang irisiris"
- " air"
- " Minyak sayur"
- " Bumbu marinasi haluskan"
- " bawang putih"
- " lada"
- " garam"
- " Bumbu tumis"
- " minyak sayur"
- " mentega"
- " bawang putih cincang kasar"
- " jahe geprek"
recipeinstructions:
- "Potong ayam sesuai selera, cuci bersih ayam beri perasan jeruk nipis diamkan selama 10 min lalu cuci bersih lagi, tiriskan. Marinasi ayam dgn bumbu marinasi dan diamkan di chiller selama 1 jam"
- "Setelah 1 jam, goreng ayam sampai matang, angkat dan tiriskan"
- "Panaskan 1 sdm minyak sayur berasama 2 sdm mentega lalu tumis bawang putih dan jahe setelah harum beri air, kemudian beri kecap manis, asin, kecap inggris, saus tiram &amp; garam, cek rasa lalu masukkan ayam yg sudah digoreng rebus sampai air surut (kuahnya sesuai selera ya), sy tdk tambah garam lagi krn asinnya sudah pas"
- "Masukkan irisan bawang bombay aduk-aduk smp stgh layu lalu matikan kompor dan masukkan daun bawang"
- "Ayam goreng mentega siap dihidangkan bersama nasi hangat ❤️"
categories:
- Resep
tags:
- ayam
- goreng
- mentega

katakunci: ayam goreng mentega 
nutrition: 160 calories
recipecuisine: Indonesian
preptime: "PT16M"
cooktime: "PT30M"
recipeyield: "2"
recipecategory: Dinner

---


![Ayam goreng mentega](https://img-global.cpcdn.com/recipes/c258f58626b3a8c4/751x532cq70/ayam-goreng-mentega-foto-resep-utama.jpg)


ayam goreng mentega ini ialah santapan tanah air yang spesial dan harus untuk kita coba. Cita rasanya yang enak membuat siapa pun menantikan kehadirannya di meja makan.
Bunda lagi mencari ide resep ayam goreng mentega untuk jualan atau dikonsumsi sendiri yang Bikin Ngiler? Cara Buatnya memang susah-susah gampang. misalnya salah mengolah maka hasilnya Tidak Memuaskan dan justru cenderung tidak enak. Padahal ayam goreng mentega yang enak selayaknya mempunyai aroma dan cita rasa yang mampu memancing selera kita.



Ada beberapa hal yang sedikit banyak mempengaruhi kualitas rasa dari ayam goreng mentega, pertama dari jenis bahan, lalu pemilihan bahan segar hingga cara membuat dan menghidangkannya. Tidak usah pusing jika mau menyiapkan ayam goreng mentega yang enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini bisa jadi sajian istimewa.


Nah, kali ini kita coba, yuk, variasikan ayam goreng mentega sendiri di rumah. Tetap berbahan yang sederhana, hidangan ini bisa memberi manfaat untuk membantu menjaga kesehatan tubuhmu sekeluarga. Anda bisa membuat Ayam goreng mentega memakai 19 jenis bahan dan 5 tahap pembuatan. Berikut ini langkah-langkah untuk membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan dalam pembuatan Ayam goreng mentega:

1. Siapkan  ayam ukuran sedang
1. Gunakan  kecap manis
1. Ambil  saus tiram
1. Sediakan  kecap inggris
1. Siapkan  gula pasir
1. Gunakan  kecap asin
1. Ambil  bawang bombay ukuran sedang (potong tebal memanjang)
1. Ambil  daun bawang iris-iris
1. Gunakan  air
1. Sediakan  Minyak sayur
1. Sediakan  Bumbu marinasi (haluskan)
1. Siapkan  bawang putih
1. Siapkan  lada
1. Gunakan  garam
1. Gunakan  Bumbu tumis
1. Sediakan  minyak sayur
1. Ambil  mentega
1. Siapkan  bawang putih (cincang kasar)
1. Gunakan  jahe (geprek)




<!--inarticleads2-->

##### Langkah-langkah membuat Ayam goreng mentega:

1. Potong ayam sesuai selera, cuci bersih ayam beri perasan jeruk nipis diamkan selama 10 min lalu cuci bersih lagi, tiriskan. Marinasi ayam dgn bumbu marinasi dan diamkan di chiller selama 1 jam
1. Setelah 1 jam, goreng ayam sampai matang, angkat dan tiriskan
1. Panaskan 1 sdm minyak sayur berasama 2 sdm mentega lalu tumis bawang putih dan jahe setelah harum beri air, kemudian beri kecap manis, asin, kecap inggris, saus tiram &amp; garam, cek rasa lalu masukkan ayam yg sudah digoreng rebus sampai air surut (kuahnya sesuai selera ya), sy tdk tambah garam lagi krn asinnya sudah pas
1. Masukkan irisan bawang bombay aduk-aduk smp stgh layu lalu matikan kompor dan masukkan daun bawang
1. Ayam goreng mentega siap dihidangkan bersama nasi hangat ❤️




Bagaimana? Mudah bukan? Itulah cara menyiapkan ayam goreng mentega yang bisa Anda lakukan di rumah. Selamat mencoba!
