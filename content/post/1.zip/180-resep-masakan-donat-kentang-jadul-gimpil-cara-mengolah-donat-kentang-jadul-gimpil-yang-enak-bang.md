---
description: "Resep masakan Donat Kentang Jadul Gimpil | Cara Mengolah Donat Kentang Jadul Gimpil Yang Enak Banget"
title: "Resep masakan Donat Kentang Jadul Gimpil | Cara Mengolah Donat Kentang Jadul Gimpil Yang Enak Banget"
slug: 180-resep-masakan-donat-kentang-jadul-gimpil-cara-mengolah-donat-kentang-jadul-gimpil-yang-enak-banget
date: 2020-10-24T07:16:42.955Z
image: https://img-global.cpcdn.com/recipes/2a962f296ab088b1/751x532cq70/donat-kentang-jadul-gimpil-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/2a962f296ab088b1/751x532cq70/donat-kentang-jadul-gimpil-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/2a962f296ab088b1/751x532cq70/donat-kentang-jadul-gimpil-foto-resep-utama.jpg
author: Cameron Blake
ratingvalue: 4.3
reviewcount: 11
recipeingredient:
- " kentang"
- " tepung terigu"
- " fiber creme atau susu bubuk optional"
- " garam"
- " gula pasir"
- " ragi fermipan"
- " Air bisa diganti susu cair jika tidak menggunakan susu bubuk"
- " Topping bebas saya pake gula halus"
- " margarin"
recipeinstructions:
- "Kukus kentang, haluskan."
- "Campur semua bahan kering, masukan kentang halus, ratakan."
- "Masukan mentega cair, ulenin. Tambahkan air sedikit demi sedikit, sampai adonan kalis."
- "Diamkan adonan 1/2 jam hingga mengembang."
- "Bagi adonan (saya 70gr) bulatkan, diamkan lagi 1/2 jam."
- "Siapkan minyak, panaskan. Goreng donat yg sudah dibentuk dengan api sedang-kecil. Jangan dibolakbalik. Tunggu sampe sisi bawah keemasan, lalu balik sekali saja. Angkat jika sudah berwarna keemasan."
- "Taburi dengan topping."
- "Untuk simpan di frezer, cukup goreng donat setengah matang."
categories:
- Resep
tags:
- donat
- kentang
- jadul

katakunci: donat kentang jadul 
nutrition: 186 calories
recipecuisine: Indonesian
preptime: "PT14M"
cooktime: "PT51M"
recipeyield: "1"
recipecategory: Dessert

---


![Donat Kentang Jadul Gimpil](https://img-global.cpcdn.com/recipes/2a962f296ab088b1/751x532cq70/donat-kentang-jadul-gimpil-foto-resep-utama.jpg)


donat kentang jadul gimpil ini yakni hidangan tanah air yang istimewa dan wajib untuk kita coba. Cita rasanya yang lezat membuat siapa pun menantikan kehadirannya di meja makan.
Anda sedang mencari ide resep donat kentang jadul gimpil untuk jualan atau dikonsumsi sendiri yang Sedap? Cara membuatnya memang susah-susah gampang. Jika salah mengolah maka hasilnya tidak akan memuaskan dan justru cenderung tidak enak. Padahal donat kentang jadul gimpil yang enak harusnya sih punya aroma dan cita rasa yang bisa memancing selera kita.



Ada beberapa hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari donat kentang jadul gimpil, mulai dari jenis bahan, kemudian pemilihan bahan segar hingga cara mengolah dan menghidangkannya. Tak perlu pusing kalau hendak menyiapkan donat kentang jadul gimpil yang enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini dapat jadi suguhan istimewa.


Nah, kali ini kita coba, yuk, buat donat kentang jadul gimpil sendiri di rumah. Tetap berbahan yang sederhana, hidangan ini bisa memberi manfaat dalam membantu menjaga kesehatan tubuh kita. Anda dapat menyiapkan Donat Kentang Jadul Gimpil menggunakan 9 jenis bahan dan 8 langkah pembuatan. Berikut ini cara dalam menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk menyiapkan Donat Kentang Jadul Gimpil:

1. Gunakan  kentang
1. Ambil  tepung terigu
1. Siapkan  fiber creme atau susu bubuk (optional)
1. Ambil  garam
1. Siapkan  gula pasir
1. Sediakan  ragi fermipan
1. Ambil  Air (bisa diganti susu cair jika tidak menggunakan susu bubuk)
1. Gunakan  Topping bebas, saya pake gula halus
1. Ambil  margarin




<!--inarticleads2-->

##### Cara membuat Donat Kentang Jadul Gimpil:

1. Kukus kentang, haluskan.
1. Campur semua bahan kering, masukan kentang halus, ratakan.
1. Masukan mentega cair, ulenin. Tambahkan air sedikit demi sedikit, sampai adonan kalis.
1. Diamkan adonan 1/2 jam hingga mengembang.
1. Bagi adonan (saya 70gr) bulatkan, diamkan lagi 1/2 jam.
1. Siapkan minyak, panaskan. Goreng donat yg sudah dibentuk dengan api sedang-kecil. Jangan dibolakbalik. Tunggu sampe sisi bawah keemasan, lalu balik sekali saja. Angkat jika sudah berwarna keemasan.
1. Taburi dengan topping.
1. Untuk simpan di frezer, cukup goreng donat setengah matang.




Gimana nih? Gampang kan? Itulah cara membuat donat kentang jadul gimpil yang bisa Anda praktikkan di rumah. Semoga bermanfaat dan selamat mencoba!
