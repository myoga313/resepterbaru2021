---
description: "Resep masakan Sambal kacang cilok | Bahan Membuat Sambal kacang cilok Yang Enak Dan Mudah"
title: "Resep masakan Sambal kacang cilok | Bahan Membuat Sambal kacang cilok Yang Enak Dan Mudah"
slug: 485-resep-masakan-sambal-kacang-cilok-bahan-membuat-sambal-kacang-cilok-yang-enak-dan-mudah
date: 2020-09-14T13:56:30.890Z
image: https://img-global.cpcdn.com/recipes/28c68e0e496f5725/751x532cq70/sambal-kacang-cilok-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/28c68e0e496f5725/751x532cq70/sambal-kacang-cilok-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/28c68e0e496f5725/751x532cq70/sambal-kacang-cilok-foto-resep-utama.jpg
author: Marvin Williamson
ratingvalue: 4.9
reviewcount: 8
recipeingredient:
- "1.5 ons kacang tanah"
- "3 biji bawang putih"
- "1 biji cabe merah"
- "2 sdt royko ayam"
- "1 sdt garem"
- "2 sdm gula merah"
- "1 sdm gula pasir"
- "1 lembar daun jeruk"
- "100 ml air asam jawa"
- " minyak untuk menumis"
recipeinstructions:
- "Goreng cabe n bawang putih sampai layu saja, lanjutkan menggoreng kacangnya ya(tips: minyaknya sedikit saja seperti disangrai aza gorengnya menghemat minyak karna minyak bekas kacang langsung kotor), goreng sampai kecoklatan angkat n tiriskan"
- "Masukkan kacang diplastik n tumbuk kasar, kemudian chopper kacang barengan dengan cabe n bawang putih, beri sedikit minyak goreng atau air untuk mempermudah kinerja choppernya😁, chopper sesuai selera aza mau kasar ato halus"
- "Panaskan sedikit minyak n masukkan kacang yang sudah dihaluskan tadi bersama daun jeruk tumis hingga daun jeruk layu"
- "Masukkan air asam jawa n bumbu lainnya, tumis sampai mengental atau asad"
- "Koreksi rasa ya, jika sudah dirasa asem manis asinnya pas matikan kompor"
categories:
- Resep
tags:
- sambal
- kacang
- cilok

katakunci: sambal kacang cilok 
nutrition: 150 calories
recipecuisine: Indonesian
preptime: "PT34M"
cooktime: "PT41M"
recipeyield: "3"
recipecategory: Lunch

---


![Sambal kacang cilok](https://img-global.cpcdn.com/recipes/28c68e0e496f5725/751x532cq70/sambal-kacang-cilok-foto-resep-utama.jpg)


sambal kacang cilok ini yakni suguhan tanah air yang enak dan harus untuk kita coba. Cita rasanya yang sedap membuat siapa pun menantikan kehadirannya di meja makan.
Lagi mencari ide resep sambal kacang cilok untuk jualan atau dikonsumsi sendiri yang Paling Enak? Cara Memasaknya memang tidak susah dan tidak juga mudah. apabila keliru mengolah maka hasilnya akan hambar dan bahkan tidak sedap. Padahal sambal kacang cilok yang enak seharusnya memiliki aroma dan rasa yang mampu memancing selera kita.



Ada beberapa hal yang sedikit banyak mempengaruhi kualitas rasa dari sambal kacang cilok, pertama dari jenis bahan, kemudian pemilihan bahan segar hingga cara mengolah dan menyajikannya. Tak perlu pusing kalau ingin menyiapkan sambal kacang cilok yang enak di rumah, karena asal sudah tahu triknya maka hidangan ini mampu jadi sajian spesial.


Berikut ini ada beberapa cara mudah dan praktis dalam mengolah sambal kacang cilok yang siap dikreasikan. Anda dapat membuat Sambal kacang cilok menggunakan 10 jenis bahan dan 5 tahap pembuatan. Berikut ini langkah-langkah dalam menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan untuk pembuatan Sambal kacang cilok:

1. Sediakan 1.5 ons kacang tanah
1. Sediakan 3 biji bawang putih
1. Gunakan 1 biji cabe merah
1. Gunakan 2 sdt royko ayam
1. Siapkan 1 sdt garem
1. Ambil 2 sdm gula merah
1. Sediakan 1 sdm gula pasir
1. Ambil 1 lembar daun jeruk
1. Ambil 100 ml air asam jawa
1. Gunakan  minyak untuk menumis




<!--inarticleads2-->

##### Cara menyiapkan Sambal kacang cilok:

1. Goreng cabe n bawang putih sampai layu saja, lanjutkan menggoreng kacangnya ya(tips: minyaknya sedikit saja seperti disangrai aza gorengnya menghemat minyak karna minyak bekas kacang langsung kotor), goreng sampai kecoklatan angkat n tiriskan
1. Masukkan kacang diplastik n tumbuk kasar, kemudian chopper kacang barengan dengan cabe n bawang putih, beri sedikit minyak goreng atau air untuk mempermudah kinerja choppernya😁, chopper sesuai selera aza mau kasar ato halus
1. Panaskan sedikit minyak n masukkan kacang yang sudah dihaluskan tadi bersama daun jeruk tumis hingga daun jeruk layu
1. Masukkan air asam jawa n bumbu lainnya, tumis sampai mengental atau asad
1. Koreksi rasa ya, jika sudah dirasa asem manis asinnya pas matikan kompor




Bagaimana? Mudah bukan? Itulah cara membuat sambal kacang cilok yang bisa Anda lakukan di rumah. Selamat mencoba!
