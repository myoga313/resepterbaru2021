---
description: "Resep Donat Lembut | Cara Masak Donat Lembut Yang Sedap"
title: "Resep Donat Lembut | Cara Masak Donat Lembut Yang Sedap"
slug: 168-resep-donat-lembut-cara-masak-donat-lembut-yang-sedap
date: 2020-12-12T00:25:03.591Z
image: https://img-global.cpcdn.com/recipes/6ae50caf412dcb1a/751x532cq70/donat-lembut-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/6ae50caf412dcb1a/751x532cq70/donat-lembut-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/6ae50caf412dcb1a/751x532cq70/donat-lembut-foto-resep-utama.jpg
author: Richard Richardson
ratingvalue: 4.6
reviewcount: 5
recipeingredient:
- "300 gram Tepung Protein Tinggi"
- "150 gram Tepung Protein Sedang"
- "50 gram Tepung Maizena"
- "2 Buah Kuning Telur"
- "1 sachet Susu Bubuk Dancow"
- "1 sdt Ovalet"
- "5 SDM Gula Pasir 2 SDM dilarutkan dengan air"
- "1 Sdt Garam"
- "75 Gram Margarin"
- "1 SDM Bibit Roti  ragi"
- "210 ml Air Hangat"
- "secukupnya Minyak untuk menggoreng"
- " Gula Halus untuk Topping"
recipeinstructions:
- "Larutkan 2 SDM Gula pasir dengan air hangat, masukkan bibit roti aduk dan diamkan ±10 menit (jika berbuih berarti ragi aktif)"
- "Campuran semua tepung, susu bubuk, gula pasir (3 SDM), Ovalet &amp; telur aduk rata"
- "Masukkan larutan ragi sedikit demi sedikit hingga tercampur"
- "Masukkan garam &amp; margarin uleni hingga kalis, cirinya adonan sudah halus dan lentur"
- "Diamkan adonan hingga mengembang, tutup wadah dengan plastik/kain (1 jam sudah cukup sebetulnya tapi tadi saya tinggal sekitar 5 jam)"
- "Buang anginnya dengan menekan adonan perlahan, timbang sekitar 30 gram dan bulatkan. Diamkan 30 menit"
- "Pipihkan lalu cetak sesuai selera, saya pakai cetakan donat. Diamkan lagi sekitar 30 menit sambil menyiapkan minyak untuk menggoreng"
- "Goreng dalam minyak panas dengan api kecil sampai matang. Cukup satu kali balik agar tidak terlalu menyerap minyak"
- "Sajikan dengan topping sesuai selera. Hasil donat lembut namun tidak kempes, pas sesuai selera keluarga."
categories:
- Resep
tags:
- donat
- lembut

katakunci: donat lembut 
nutrition: 121 calories
recipecuisine: Indonesian
preptime: "PT28M"
cooktime: "PT50M"
recipeyield: "4"
recipecategory: Dessert

---


![Donat Lembut](https://img-global.cpcdn.com/recipes/6ae50caf412dcb1a/751x532cq70/donat-lembut-foto-resep-utama.jpg)


donat lembut ini ialah sajian nusantara yang khas dan wajib untuk kita coba. Cita rasanya yang mantap membuat siapa pun menantikan kehadirannya di meja makan.
Bunda Sedang mencari inspirasi resep donat lembut untuk jualan atau dikonsumsi sendiri yang Enak Dan Mudah? Cara Memasaknya memang susah-susah gampang. semisal keliru mengolah maka hasilnya tidak akan memuaskan dan bahkan tidak sedap. Padahal donat lembut yang enak seharusnya memiliki aroma dan cita rasa yang bisa memancing selera kita.

Ada beberapa hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari donat lembut, mulai dari jenis bahan, lalu pemilihan bahan segar, hingga cara mengolah dan menyajikannya. Tidak usah pusing jika hendak menyiapkan donat lembut yang enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini mampu jadi sajian istimewa.




Nah, kali ini kita coba, yuk, variasikan donat lembut sendiri di rumah. Tetap dengan bahan yang sederhana, hidangan ini bisa memberi manfaat untuk membantu menjaga kesehatan tubuh kita. Anda bisa menyiapkan Donat Lembut memakai 13 bahan dan 9 tahap pembuatan. Berikut ini cara dalam menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam menyiapkan Donat Lembut:

1. Gunakan 300 gram Tepung Protein Tinggi
1. Gunakan 150 gram Tepung Protein Sedang
1. Sediakan 50 gram Tepung Maizena
1. Sediakan 2 Buah Kuning Telur
1. Sediakan 1 sachet Susu Bubuk Dancow
1. Ambil 1 sdt Ovalet
1. Siapkan 5 SDM Gula Pasir (2 SDM dilarutkan dengan air)
1. Sediakan 1 Sdt Garam
1. Siapkan 75 Gram Margarin
1. Sediakan 1 SDM Bibit Roti / ragi
1. Siapkan 210 ml Air Hangat
1. Siapkan secukupnya Minyak untuk menggoreng
1. Gunakan  Gula Halus untuk Topping




<!--inarticleads2-->

##### Langkah-langkah membuat Donat Lembut:

1. Larutkan 2 SDM Gula pasir dengan air hangat, masukkan bibit roti aduk dan diamkan ±10 menit (jika berbuih berarti ragi aktif)
1. Campuran semua tepung, susu bubuk, gula pasir (3 SDM), Ovalet &amp; telur aduk rata
1. Masukkan larutan ragi sedikit demi sedikit hingga tercampur
1. Masukkan garam &amp; margarin uleni hingga kalis, cirinya adonan sudah halus dan lentur
1. Diamkan adonan hingga mengembang, tutup wadah dengan plastik/kain (1 jam sudah cukup sebetulnya tapi tadi saya tinggal sekitar 5 jam)
1. Buang anginnya dengan menekan adonan perlahan, timbang sekitar 30 gram dan bulatkan. Diamkan 30 menit
1. Pipihkan lalu cetak sesuai selera, saya pakai cetakan donat. Diamkan lagi sekitar 30 menit sambil menyiapkan minyak untuk menggoreng
1. Goreng dalam minyak panas dengan api kecil sampai matang. Cukup satu kali balik agar tidak terlalu menyerap minyak
1. Sajikan dengan topping sesuai selera. Hasil donat lembut namun tidak kempes, pas sesuai selera keluarga.




Gimana nih? Gampang kan? Itulah cara membuat donat lembut yang bisa Anda lakukan di rumah. Selamat mencoba!
