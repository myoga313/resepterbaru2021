---
description: "Bumbu Nasi Kuning | Bahan Membuat Nasi Kuning Yang Bisa Manjain Lidah"
title: "Bumbu Nasi Kuning | Bahan Membuat Nasi Kuning Yang Bisa Manjain Lidah"
slug: 93-bumbu-nasi-kuning-bahan-membuat-nasi-kuning-yang-bisa-manjain-lidah
date: 2020-07-30T17:41:49.705Z
image: https://img-global.cpcdn.com/recipes/982e9be37c02b6ed/751x532cq70/nasi-kuning-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/982e9be37c02b6ed/751x532cq70/nasi-kuning-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/982e9be37c02b6ed/751x532cq70/nasi-kuning-foto-resep-utama.jpg
author: Lettie Ryan
ratingvalue: 3.3
reviewcount: 10
recipeingredient:
- " beras"
- " santan instant 200ml  air"
- " salam"
- " daun jeruk"
- " daun pandan"
- " serai"
- " lengkuas"
- " kunyit"
- " air jeruk nipis"
- " Garam"
recipeinstructions:
- "Cuci bersih beras"
- "Blender kunyit, saring, ambil airnya. Geprek serai dan lengkuas"
- "Didihkan santan+air (secukupnya, kira-kira setengah takaran air untuk memasak nasi) tambahkan air kunyit, jeruk nipis, lengkuas dan daun-daunan dan garam"
- "Setelah mendidih, masukkan beras. Masak sampai air terserap habis."
- "Pindahkan ke dandang, kukus sampai empuk."
categories:
- Resep
tags:
- nasi
- kuning

katakunci: nasi kuning 
nutrition: 105 calories
recipecuisine: Indonesian
preptime: "PT33M"
cooktime: "PT55M"
recipeyield: "4"
recipecategory: Lunch

---


![Nasi Kuning](https://img-global.cpcdn.com/recipes/982e9be37c02b6ed/751x532cq70/nasi-kuning-foto-resep-utama.jpg)


nasi kuning ini yakni sajian nusantara yang khas dan wajib untuk kita coba. Cita rasanya yang lezat membuat siapa pun menantikan kehadirannya di meja makan.
Kamu Lagi mencari inspirasi resep nasi kuning untuk jualan atau dikonsumsi sendiri yang Lezat? Cara Bikinnya memang tidak susah dan tidak juga mudah. andaikan keliru mengolah maka hasilnya tidak akan memuaskan dan justru cenderung tidak enak. Padahal nasi kuning yang enak seharusnya mempunyai aroma dan rasa yang bisa memancing selera kita.



Ada beberapa hal yang sedikit banyak mempengaruhi kualitas rasa dari nasi kuning, pertama dari jenis bahan, kedua pemilihan bahan segar sampai cara membuat dan menyajikannya. Tidak usah pusing jika hendak menyiapkan nasi kuning yang enak di rumah, karena asal sudah tahu triknya maka hidangan ini bisa jadi suguhan spesial.


Di bawah ini ada beberapa cara mudah dan praktis untuk membuat nasi kuning yang siap dikreasikan. Anda bisa menyiapkan Nasi Kuning memakai 10 jenis bahan dan 5 tahap pembuatan. Berikut ini langkah-langkah dalam membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang digunakan dalam menyiapkan Nasi Kuning:

1. Ambil  beras
1. Siapkan  santan instant 200ml + air
1. Ambil  salam
1. Ambil  daun jeruk
1. Siapkan  daun pandan
1. Ambil  serai
1. Gunakan  lengkuas
1. Sediakan  kunyit
1. Sediakan  air jeruk nipis
1. Sediakan  Garam




<!--inarticleads2-->

##### Langkah-langkah menyiapkan Nasi Kuning:

1. Cuci bersih beras
1. Blender kunyit, saring, ambil airnya. Geprek serai dan lengkuas
1. Didihkan santan+air (secukupnya, kira-kira setengah takaran air untuk memasak nasi) tambahkan air kunyit, jeruk nipis, lengkuas dan daun-daunan dan garam
1. Setelah mendidih, masukkan beras. Masak sampai air terserap habis.
1. Pindahkan ke dandang, kukus sampai empuk.




Gimana nih? Gampang kan? Itulah cara membuat nasi kuning yang bisa Anda lakukan di rumah. Selamat mencoba!
