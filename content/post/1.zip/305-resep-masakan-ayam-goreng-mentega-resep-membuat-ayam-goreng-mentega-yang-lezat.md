---
description: "Resep masakan Ayam Goreng Mentega | Resep Membuat Ayam Goreng Mentega Yang Lezat"
title: "Resep masakan Ayam Goreng Mentega | Resep Membuat Ayam Goreng Mentega Yang Lezat"
slug: 305-resep-masakan-ayam-goreng-mentega-resep-membuat-ayam-goreng-mentega-yang-lezat
date: 2021-01-20T13:32:36.561Z
image: https://img-global.cpcdn.com/recipes/4780b90c80a09138/751x532cq70/ayam-goreng-mentega-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/4780b90c80a09138/751x532cq70/ayam-goreng-mentega-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/4780b90c80a09138/751x532cq70/ayam-goreng-mentega-foto-resep-utama.jpg
author: Gussie Lawson
ratingvalue: 3.4
reviewcount: 10
recipeingredient:
- " ayam potong sesuai selera"
- " mentegamargarine"
- " bawang putih cincang halus"
- "  Bumbu marinasi"
- " bawang putih parut"
- " lada bubuk"
- " garam"
- "  Bahan pelapis"
- " tepung bumbu"
- "  Bahan saus"
- " kecap inggris saya skip"
- " saus tiram"
- " kecap asin"
- " kecap manis"
- " saos tomat"
- " gula pasir"
- " kaldu bubuk dan merica bubuk"
- " air"
- " maizena larutkan dengan sedikit air"
recipeinstructions:
- "Lumuri ayam dengan bumbu marinasi. Diamkan minimal 10 menit. Sisihkan."
- "Lumuri ayam dengan tepung bumbu hingga ayam rata tertutup tepung. Tidak perlu terlalu tebal tepungnya. Goreng dalam minyak banyak dan panas hingga matang, kuning keemasan."
- "Tumis 3 siung bawang putih hingga harum tambahkan semua saus dan air. Biarkan mendidih. Tambahkan larutan maizena, aduk hingga mengental, koreksi rasa."
- "Masukkan ayam goreng. Aduk hingga ayam tersalut saus. Taburi daun bawang. Angkat sajikan."
- "Tips: supaya lebih gurih pada saat menggoreng, tambahkan 1 sdm mentega pada minyak."
categories:
- Resep
tags:
- ayam
- goreng
- mentega

katakunci: ayam goreng mentega 
nutrition: 217 calories
recipecuisine: Indonesian
preptime: "PT14M"
cooktime: "PT49M"
recipeyield: "2"
recipecategory: Lunch

---


![Ayam Goreng Mentega](https://img-global.cpcdn.com/recipes/4780b90c80a09138/751x532cq70/ayam-goreng-mentega-foto-resep-utama.jpg)


ayam goreng mentega ini yakni santapan nusantara yang istimewa dan wajib untuk kita coba. Cita rasanya yang mantap membuat siapa pun menantikan kehadirannya di meja makan.
Lagi mencari ide resep ayam goreng mentega untuk jualan atau dikonsumsi sendiri yang Enak Dan Lezat? Cara membuatnya memang tidak susah dan tidak juga mudah. Jika keliru mengolah maka hasilnya akan hambar dan justru cenderung tidak enak. Padahal ayam goreng mentega yang enak harusnya sih memiliki aroma dan rasa yang bisa memancing selera kita.



Ada beberapa hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari ayam goreng mentega, mulai dari jenis bahan, lalu pemilihan bahan segar sampai cara membuat dan menghidangkannya. Tak perlu pusing jika ingin menyiapkan ayam goreng mentega yang enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini mampu menjadi suguhan spesial.


Nah, kali ini kita coba, yuk, siapkan ayam goreng mentega sendiri di rumah. Tetap dengan bahan yang sederhana, sajian ini dapat memberi manfaat untuk membantu menjaga kesehatan tubuhmu sekeluarga. Anda bisa membuat Ayam Goreng Mentega memakai 19 bahan dan 5 langkah pembuatan. Berikut ini cara untuk menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk menyiapkan Ayam Goreng Mentega:

1. Sediakan  ayam, potong sesuai selera
1. Ambil  mentega/margarine
1. Ambil  bawang putih, cincang halus
1. Siapkan  📌 Bumbu marinasi:
1. Ambil  bawang putih parut
1. Ambil  lada bubuk
1. Sediakan  garam
1. Siapkan  📌 Bahan pelapis:
1. Sediakan  tepung bumbu
1. Gunakan  📌 Bahan saus:
1. Siapkan  kecap inggris (saya skip)
1. Sediakan  saus tiram
1. Siapkan  kecap asin
1. Gunakan  kecap manis
1. Ambil  saos tomat
1. Siapkan  gula pasir
1. Ambil  kaldu bubuk dan merica bubuk
1. Siapkan  air
1. Ambil  maizena larutkan dengan sedikit air




<!--inarticleads2-->

##### Langkah-langkah membuat Ayam Goreng Mentega:

1. Lumuri ayam dengan bumbu marinasi. Diamkan minimal 10 menit. Sisihkan.
1. Lumuri ayam dengan tepung bumbu hingga ayam rata tertutup tepung. Tidak perlu terlalu tebal tepungnya. Goreng dalam minyak banyak dan panas hingga matang, kuning keemasan.
1. Tumis 3 siung bawang putih hingga harum tambahkan semua saus dan air. Biarkan mendidih. Tambahkan larutan maizena, aduk hingga mengental, koreksi rasa.
1. Masukkan ayam goreng. Aduk hingga ayam tersalut saus. Taburi daun bawang. Angkat sajikan.
1. Tips: supaya lebih gurih pada saat menggoreng, tambahkan 1 sdm mentega pada minyak.




Bagaimana? Gampang kan? Itulah cara menyiapkan ayam goreng mentega yang bisa Anda praktikkan di rumah. Selamat mencoba!
