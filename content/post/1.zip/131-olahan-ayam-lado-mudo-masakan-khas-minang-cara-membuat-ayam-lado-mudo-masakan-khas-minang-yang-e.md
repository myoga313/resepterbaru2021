---
description: "Olahan Ayam Lado Mudo (Masakan Khas Minang) | Cara Membuat Ayam Lado Mudo (Masakan Khas Minang) Yang Enak Banget"
title: "Olahan Ayam Lado Mudo (Masakan Khas Minang) | Cara Membuat Ayam Lado Mudo (Masakan Khas Minang) Yang Enak Banget"
slug: 131-olahan-ayam-lado-mudo-masakan-khas-minang-cara-membuat-ayam-lado-mudo-masakan-khas-minang-yang-enak-banget
date: 2021-01-13T13:28:31.682Z
image: https://img-global.cpcdn.com/recipes/9127859b61386aa2/751x532cq70/ayam-lado-mudo-masakan-khas-minang-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/9127859b61386aa2/751x532cq70/ayam-lado-mudo-masakan-khas-minang-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/9127859b61386aa2/751x532cq70/ayam-lado-mudo-masakan-khas-minang-foto-resep-utama.jpg
author: Bess Larson
ratingvalue: 3
reviewcount: 5
recipeingredient:
- " ayam kampung muda kurang lebih dengan berat 15 kg"
- " daun salam"
- " daun jeruk"
- " bawang putih iris tipis"
- " bawang merah iris tipis"
- " serai geprek"
- " daun kunyit"
- " asam kandis"
- " Air"
- " Kaldu bubuk"
- " Garam"
- " Bumbu halus "
- " cabe keriting hijau"
- " kunyit"
- " lengkuas"
- " jahe"
- " kemiri"
- " merica"
- " Cabe rawit hijau"
- " bawang putih"
- " bawang merah"
- " Garam"
recipeinstructions:
- "Kalau menggunakan ayam kampung, ungkap ayam terlebih dahulu dengan menambahkan 4 lembar daun salam &amp; 2 ruas jahe (iris-iris tipis). Tambahkan air secukupnya. Masak hingga ayam setengah matang. Kalau menggunakan ayam broiler, ayam tidak perlu diungkap."
- "Giling seluruh bumbu. Giling cabe hijau dengan kunyit, agar cabe tidak menghitam."
- "Tumis bawang merah dan bawang putih dengan sedikit minyak goreng yang tlh dipanaskan terlebih dahulu. Tambahkan daun salam, daun jeruk, daun kunyit, dan serai. Tumis hingga wangi."
- "Tambahkan bumbu halus. Aduk rata. Masukkan ayam, aduk-aduk sebentar."
- "Tambahkan air, lalu masak hingga matang. Tambahkan asam kandis. (Saya tuang agak banyak air)"
- "Masak hingga kuah menyusut, mengental, dan mengeluarkan minyak (kaldu). Gunakan api kecil aja ya."
- "Ketika kuah telah menyusut, masukkan sedikit kaldu bubuk dan sedikit garam. Koreksi rasa. Jika sudah matang dan kuah mengental, matikan api."
- "Sajikan ayam dengan sayuran dan lauk tambahan lainnya 😉"
categories:
- Resep
tags:
- ayam
- lado
- mudo

katakunci: ayam lado mudo 
nutrition: 281 calories
recipecuisine: Indonesian
preptime: "PT28M"
cooktime: "PT43M"
recipeyield: "4"
recipecategory: Dinner

---


![Ayam Lado Mudo (Masakan Khas Minang)](https://img-global.cpcdn.com/recipes/9127859b61386aa2/751x532cq70/ayam-lado-mudo-masakan-khas-minang-foto-resep-utama.jpg)


ayam lado mudo (masakan khas minang) ini yakni suguhan tanah air yang khas dan wajib untuk kita coba. Cita rasanya yang sedap membuat siapa pun menantikan kehadirannya di meja makan.
Bunda Sedang mencari ide resep ayam lado mudo (masakan khas minang) untuk jualan atau dikonsumsi sendiri yang Enak dan Simpel? Cara menyiapkannya memang tidak terlalu sulit namun tidak gampang juga. jikalau salah mengolah maka hasilnya akan hambar dan justru cenderung tidak enak. Padahal ayam lado mudo (masakan khas minang) yang enak selayaknya mempunyai aroma dan cita rasa yang bisa memancing selera kita.



Banyak hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari ayam lado mudo (masakan khas minang), pertama dari jenis bahan, kemudian pemilihan bahan segar sampai cara membuat dan menghidangkannya. Tak perlu pusing kalau hendak menyiapkan ayam lado mudo (masakan khas minang) yang enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini dapat menjadi sajian istimewa.


Nah, kali ini kita coba, yuk, buat ayam lado mudo (masakan khas minang) sendiri di rumah. Tetap berbahan sederhana, sajian ini dapat memberi manfaat dalam membantu menjaga kesehatan tubuh kita. Anda bisa menyiapkan Ayam Lado Mudo (Masakan Khas Minang) memakai 22 bahan dan 8 tahap pembuatan. Berikut ini cara untuk menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang diperlukan untuk menyiapkan Ayam Lado Mudo (Masakan Khas Minang):

1. Sediakan  ayam kampung muda (kurang lebih dengan berat 1,5 kg)
1. Siapkan  daun salam
1. Ambil  daun jeruk
1. Siapkan  bawang putih (iris tipis)
1. Ambil  bawang merah (iris tipis)
1. Gunakan  serai (geprek)
1. Siapkan  daun kunyit
1. Ambil  asam kandis
1. Ambil  Air
1. Sediakan  Kaldu bubuk
1. Siapkan  Garam
1. Ambil  Bumbu halus :
1. Ambil  cabe keriting hijau
1. Ambil  kunyit
1. Siapkan  lengkuas
1. Sediakan  jahe
1. Ambil  kemiri
1. Sediakan  merica
1. Siapkan  Cabe rawit hijau
1. Siapkan  bawang putih
1. Gunakan  bawang merah
1. Ambil  Garam




<!--inarticleads2-->

##### Cara membuat Ayam Lado Mudo (Masakan Khas Minang):

1. Kalau menggunakan ayam kampung, ungkap ayam terlebih dahulu dengan menambahkan 4 lembar daun salam &amp; 2 ruas jahe (iris-iris tipis). Tambahkan air secukupnya. Masak hingga ayam setengah matang. Kalau menggunakan ayam broiler, ayam tidak perlu diungkap.
1. Giling seluruh bumbu. Giling cabe hijau dengan kunyit, agar cabe tidak menghitam.
1. Tumis bawang merah dan bawang putih dengan sedikit minyak goreng yang tlh dipanaskan terlebih dahulu. Tambahkan daun salam, daun jeruk, daun kunyit, dan serai. Tumis hingga wangi.
1. Tambahkan bumbu halus. Aduk rata. Masukkan ayam, aduk-aduk sebentar.
1. Tambahkan air, lalu masak hingga matang. Tambahkan asam kandis. (Saya tuang agak banyak air)
1. Masak hingga kuah menyusut, mengental, dan mengeluarkan minyak (kaldu). Gunakan api kecil aja ya.
1. Ketika kuah telah menyusut, masukkan sedikit kaldu bubuk dan sedikit garam. Koreksi rasa. Jika sudah matang dan kuah mengental, matikan api.
1. Sajikan ayam dengan sayuran dan lauk tambahan lainnya 😉




Terima kasih telah menggunakan resep yang kami tampilkan di sini. Harapan kami, olahan Ayam Lado Mudo (Masakan Khas Minang) yang mudah di atas dapat membantu Anda menyiapkan makanan yang sedap untuk keluarga/teman maupun menjadi inspirasi bagi Anda yang berkeinginan untuk berjualan makanan. Semoga bermanfaat dan selamat mencoba!
