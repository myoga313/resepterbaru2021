---
description: "Resep masakan Soto Ayam Bening Berempah | Cara Membuat Soto Ayam Bening Berempah Yang Lezat Sekali"
title: "Resep masakan Soto Ayam Bening Berempah | Cara Membuat Soto Ayam Bening Berempah Yang Lezat Sekali"
slug: 415-resep-masakan-soto-ayam-bening-berempah-cara-membuat-soto-ayam-bening-berempah-yang-lezat-sekali
date: 2021-01-21T21:40:05.822Z
image: https://img-global.cpcdn.com/recipes/87d2441daa5625c6/751x532cq70/soto-ayam-bening-berempah-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/87d2441daa5625c6/751x532cq70/soto-ayam-bening-berempah-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/87d2441daa5625c6/751x532cq70/soto-ayam-bening-berempah-foto-resep-utama.jpg
author: Emma Fields
ratingvalue: 5
reviewcount: 9
recipeingredient:
- " Bahan utama"
- " ayam"
- " toge"
- " soun"
- " kol putih"
- " Air secukupnya untuk kuah"
- " Minyak goreng untuk menggoreng ayam"
- " Pelengkap"
- " daun bawang di iris"
- " bawang merah digoreng kering"
- " Kecap manis"
- " jeruk nipis di iris"
- " cabe rawit merah rebus dan diuleg"
- " Bumbu yg di haluskan"
- " ketumbar"
- " lada"
- " pala"
- " bawang merah"
- " bawang putih"
- " Garam"
- " Penyedap rasa"
- " Bahan tambahan yg dimasukkan ke kuah"
- " sereh geprek"
- " jahe geprek"
- " daun jeruk"
- " cengkeh"
- " kayu manis"
recipeinstructions:
- "Cuci bersih ayam, potong jd 12 bagian, lalu rebus dan masukkan bumbu cengkeh dan kayu manis"
- "Haluskan ketumbar, lada, pala, 6 siung bawang merah, 4 siung bawang putih, garam, tumis sampai harum dan masukkan ke rebusan ayam"
- "Masukkan ke dalam rebusan ayam, bumbu tambahan spt jahe geprek, sereh geprek, penyedap rasa dan daun jeruk. Rebus sampai ayam empuk. Masukkan irisan daun bawang saat terakhir."
- "Siapkan bahan pelengkap, rebus sebentar toge dan soun, iris2 kol putih"
- "Angkat ayam dari kuah nya, goreng dalam minyak secukupnya"
- "Hidangkan soto dengan bahan pelengkap bawang goreng, jeruk nipis peras, kecap manis dan cabe rawit rebus yg diuleg"
categories:
- Resep
tags:
- soto
- ayam
- bening

katakunci: soto ayam bening 
nutrition: 264 calories
recipecuisine: Indonesian
preptime: "PT36M"
cooktime: "PT58M"
recipeyield: "4"
recipecategory: Dinner

---


![Soto Ayam Bening Berempah](https://img-global.cpcdn.com/recipes/87d2441daa5625c6/751x532cq70/soto-ayam-bening-berempah-foto-resep-utama.jpg)


soto ayam bening berempah ini ialah makanan tanah air yang istimewa dan harus untuk kita coba. Cita rasanya yang lezat membuat siapa pun menantikan kehadirannya di meja makan.
Kamu Sedang mencari ide resep soto ayam bening berempah untuk jualan atau dikonsumsi sendiri yang Lezat? Cara membuatnya memang susah-susah gampang. seandainya salah mengolah maka hasilnya tidak akan memuaskan dan bahkan tidak sedap. Padahal soto ayam bening berempah yang enak harusnya sih mempunyai aroma dan cita rasa yang mampu memancing selera kita.

Banyak hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari soto ayam bening berempah, pertama dari jenis bahan, selanjutnya pemilihan bahan segar, sampai cara membuat dan menyajikannya. Tidak usah pusing kalau ingin menyiapkan soto ayam bening berempah yang enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini mampu menjadi sajian spesial.




Nah, kali ini kita coba, yuk, ciptakan soto ayam bening berempah sendiri di rumah. Tetap dengan bahan yang sederhana, sajian ini dapat memberi manfaat dalam membantu menjaga kesehatan tubuhmu sekeluarga. Anda dapat membuat Soto Ayam Bening Berempah memakai 27 bahan dan 6 langkah pembuatan. Berikut ini cara untuk menyiapkan hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan untuk pembuatan Soto Ayam Bening Berempah:

1. Siapkan  Bahan utama
1. Ambil  ayam
1. Siapkan  toge
1. Ambil  soun
1. Ambil  kol putih
1. Sediakan  Air secukupnya untuk kuah
1. Siapkan  Minyak goreng untuk menggoreng ayam
1. Siapkan  Pelengkap
1. Ambil  daun bawang, di iris
1. Gunakan  bawang merah, digoreng kering
1. Siapkan  Kecap manis
1. Sediakan  jeruk nipis, di iris
1. Sediakan  cabe rawit merah, rebus dan diuleg
1. Siapkan  Bumbu yg di haluskan
1. Sediakan  ketumbar
1. Siapkan  lada
1. Ambil  pala
1. Gunakan  bawang merah
1. Siapkan  bawang putih
1. Sediakan  Garam
1. Gunakan  Penyedap rasa
1. Ambil  Bahan tambahan yg dimasukkan ke kuah
1. Siapkan  sereh, geprek
1. Gunakan  jahe, geprek
1. Gunakan  daun jeruk
1. Siapkan  cengkeh
1. Ambil  kayu manis




<!--inarticleads2-->

##### Langkah-langkah membuat Soto Ayam Bening Berempah:

1. Cuci bersih ayam, potong jd 12 bagian, lalu rebus dan masukkan bumbu cengkeh dan kayu manis
1. Haluskan ketumbar, lada, pala, 6 siung bawang merah, 4 siung bawang putih, garam, tumis sampai harum dan masukkan ke rebusan ayam
1. Masukkan ke dalam rebusan ayam, bumbu tambahan spt jahe geprek, sereh geprek, penyedap rasa dan daun jeruk. Rebus sampai ayam empuk. Masukkan irisan daun bawang saat terakhir.
1. Siapkan bahan pelengkap, rebus sebentar toge dan soun, iris2 kol putih
1. Angkat ayam dari kuah nya, goreng dalam minyak secukupnya
1. Hidangkan soto dengan bahan pelengkap bawang goreng, jeruk nipis peras, kecap manis dan cabe rawit rebus yg diuleg




Terima kasih telah membaca resep yang kami tampilkan di sini. Harapan kami, olahan Soto Ayam Bening Berempah yang mudah di atas dapat membantu Anda menyiapkan makanan yang enak untuk keluarga/teman maupun menjadi inspirasi untuk berjualan makanan. Selamat mencoba!
