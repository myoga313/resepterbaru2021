---
description: "Olahan Bubur Sum Sum | Cara Bikin Bubur Sum Sum Yang Bikin Ngiler"
title: "Olahan Bubur Sum Sum | Cara Bikin Bubur Sum Sum Yang Bikin Ngiler"
slug: 38-olahan-bubur-sum-sum-cara-bikin-bubur-sum-sum-yang-bikin-ngiler
date: 2020-10-01T16:37:53.881Z
image: https://img-global.cpcdn.com/recipes/391b56ba7ed259a6/751x532cq70/bubur-sum-sum-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/391b56ba7ed259a6/751x532cq70/bubur-sum-sum-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/391b56ba7ed259a6/751x532cq70/bubur-sum-sum-foto-resep-utama.jpg
author: Matthew Sanchez
ratingvalue: 3.5
reviewcount: 9
recipeingredient:
- " Tepung beras saya pakai rose brand"
- " Santan instan saya pakai santan kara"
- " air untuk bubur"
- " air untuk saus manis"
- " garam"
- " gula merah"
- " gula pasir"
- " daun pandan wangi"
recipeinstructions:
- "Campurkan tepung beras, air, santan dan garam. Aduk sampai benar benar tercampur sebelum dimasak diatas kompor(ini bertujuan agar tekstur bubur lembut dan halus, tidak bergindil setelah matang)"
- "Masak dengan api sedang sambil diaduk perlahan"
- "Aduk sampai bubur mulai meletup letup dan teksturnya mulai mengental"
- "Pindah di piring saji, diamkan sampai suhu normal"
- "Lanjut untuk membuat saus manisnya.. iris iris gula merah"
- "Campur irisan gula merah dan gula pasir dengan 100ml air dan pandan wangi (pandannya bisa di skip, sperti saya kali ini tidak pakai karena tidak punya 😁)"
- "Panaskan dengan api kecil sambil diaduk hingga larut,dan agak mengental"
- "Setelah mendidih, saring agar saus manisnya bersih"
- "Diamkan hingga suhu normal"
- "Setelah itu, bubur sum sum siap dinikmati dengan saus manisnya.. lebih nikmat bila di masukkan ke dalam kulkas dulu, baru disajikan dingin."
categories:
- Resep
tags:
- bubur
- sum
- sum

katakunci: bubur sum sum 
nutrition: 236 calories
recipecuisine: Indonesian
preptime: "PT33M"
cooktime: "PT50M"
recipeyield: "1"
recipecategory: Dinner

---


![Bubur Sum Sum](https://img-global.cpcdn.com/recipes/391b56ba7ed259a6/751x532cq70/bubur-sum-sum-foto-resep-utama.jpg)


bubur sum sum ini merupakan hidangan tanah air yang istimewa dan harus untuk kita coba. Cita rasanya yang mantap membuat siapa pun menantikan kehadirannya di meja makan.
Bunda Sedang mencari inspirasi resep bubur sum sum untuk jualan atau dikonsumsi sendiri yang Menggugah Selera? Cara Buatnya memang tidak terlalu sulit namun tidak gampang juga. semisal keliru mengolah maka hasilnya akan hambar dan justru cenderung tidak enak. Padahal bubur sum sum yang enak seharusnya mempunyai aroma dan rasa yang mampu memancing selera kita.



Ada beberapa hal yang sedikit banyak mempengaruhi kualitas rasa dari bubur sum sum, mulai dari jenis bahan, kemudian pemilihan bahan segar hingga cara mengolah dan menyajikannya. Tak perlu pusing kalau mau menyiapkan bubur sum sum enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini bisa menjadi suguhan spesial.


Di bawah ini ada beberapa tips dan trik praktis yang dapat diterapkan untuk mengolah bubur sum sum yang siap dikreasikan. Anda dapat menyiapkan Bubur Sum Sum memakai 8 bahan dan 10 tahap pembuatan. Berikut ini cara untuk membuat hidangannya.

<!--inarticleads1-->

##### Bahan-bahan dan bumbu yang dibutuhkan dalam pembuatan Bubur Sum Sum:

1. Siapkan  Tepung beras (saya pakai rose brand)
1. Siapkan  Santan instan (saya pakai santan kara)
1. Gunakan  air untuk bubur
1. Sediakan  air untuk saus manis
1. Gunakan  garam
1. Siapkan  gula merah
1. Ambil  gula pasir
1. Siapkan  daun pandan wangi




<!--inarticleads2-->

##### Cara membuat Bubur Sum Sum:

1. Campurkan tepung beras, air, santan dan garam. Aduk sampai benar benar tercampur sebelum dimasak diatas kompor(ini bertujuan agar tekstur bubur lembut dan halus, tidak bergindil setelah matang)
1. Masak dengan api sedang sambil diaduk perlahan
1. Aduk sampai bubur mulai meletup letup dan teksturnya mulai mengental
1. Pindah di piring saji, diamkan sampai suhu normal
1. Lanjut untuk membuat saus manisnya.. iris iris gula merah
1. Campur irisan gula merah dan gula pasir dengan 100ml air dan pandan wangi (pandannya bisa di skip, sperti saya kali ini tidak pakai karena tidak punya 😁)
1. Panaskan dengan api kecil sambil diaduk hingga larut,dan agak mengental
1. Setelah mendidih, saring agar saus manisnya bersih
1. Diamkan hingga suhu normal
1. Setelah itu, bubur sum sum siap dinikmati dengan saus manisnya.. lebih nikmat bila di masukkan ke dalam kulkas dulu, baru disajikan dingin.




Bagaimana? Mudah bukan? Itulah cara membuat bubur sum sum yang bisa Anda lakukan di rumah. Semoga bermanfaat dan selamat mencoba!
